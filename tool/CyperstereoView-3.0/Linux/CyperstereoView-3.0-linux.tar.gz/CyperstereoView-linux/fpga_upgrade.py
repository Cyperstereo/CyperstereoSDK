#!/usr/bin/env python3
"""FPGA configuration update. Never erases unless program is explicitly requested.

Default operations never erase. `program` requires --accept-single-image-risk
and performs a full-region update without saving the previous firmware.
Close all video applications first. No automatic
retry of mutating commands; reconnect/re-run explicitly after a failure.
"""
import argparse
import binascii
import ctypes
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import time
import queue
import re
import threading

LIMIT = 0x80000
SECTOR = 4096
CHUNK = 16
FAST_CHUNK = 256
FAST_SIZE = 288
APP_VERSION = '3.0'

class UpgradeStatusError(RuntimeError):
    def __init__(self, op, status, response=b''):
        self.status = status
        detail=''
        if len(response)>=16 and response[8:10]==b'DI':
            phase={1:'rate setup',2:'I2C transmit',3:'I2C receive',4:'rate restore'}.get(response[10],'unknown')
            detail=f'; {phase}, {response[11]*100} kHz, FX3 SDK=0x{int.from_bytes(response[12:16],"little"):02x}'
        super().__init__(f'Upgrade command {op:#x} failed: status {status:#x}{detail}')

def helper_path():
    return Path(__file__).with_name('xu_transport.exe')

def device_address(device):
    return device.get('address') or ('winlink:'+device['link'])

def is_target_device(device):
    vid,pid=device.get('vid','').lower(),device.get('pid','').lower()
    if vid and pid:return vid=='04b4' and pid in ('00f8','00f9')
    return re.search(r'vid_04b4&pid_00f[89](?=[&#\\]|$)',device.get('link',''),re.I) is not None

def list_devices():
    if sys.platform=='linux':
        from linux_uvc import list_devices as linux_list
        return linux_list()
    if sys.platform!='win32': raise RuntimeError('Supported platforms: Windows / Linux')
    result = subprocess.run([str(helper_path()), '--list-json'], capture_output=True,
        text=True, encoding='utf-8', timeout=20,
        creationflags=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0)
    if result.returncode:
        raise RuntimeError(result.stdout.strip() or result.stderr.strip() or 'Device enumeration failed')
    return json.loads(result.stdout)

def crc16(data):
    return binascii.crc_hqx(data, 0xffff)

def make_packet(op, seq, address=0, count=0, data=b''):
    if not 0 <= address < 1 << 24 or not 0 <= count <= CHUNK or len(data) > CHUNK:
        raise ValueError('Invalid packet address/length')
    packet = bytes((0x46, op, seq, count)) + address.to_bytes(3, 'big') + b'\0' + data.ljust(22, b'\0')
    return packet + crc16(packet).to_bytes(2, 'big')

def make_fast_packet(op, seq, address=0, count=0, data=b'', hz=400000):
    if op not in (6, 0x22, 0x24) or not 0 <= address < LIMIT:
        raise ValueError('Invalid fast operation/address')
    if hz not in (100000, 400000): raise ValueError('Invalid I2C rate')
    if op == 6:
        if address or count or data: raise ValueError('Invalid capabilities request')
    elif not 1 <= count <= FAST_CHUNK or address + count > LIMIT:
        raise ValueError('Invalid fast transfer range')
    if op == 0x24 and (len(data) != count or address % 256 + count > 256):
        raise ValueError('Page write crosses boundary or has wrong length')
    if op != 0x24 and data: raise ValueError('Read request contains data')
    packet = bytes((0x46,op,seq,count & 255)) + address.to_bytes(3,'big') + bytes((hz==100000,)) + data.ljust(278,b'\0')
    return packet + crc16(packet).to_bytes(2,'big')

def bit_payload(path):
    raw = Path(path).read_bytes()
    if len(raw) < 16 or raw[:13] != bytes.fromhex('00090ff00ff00ff00ff0000001'):
        raise ValueError('Expected a Xilinx .bit container, not .mcs/.bin')
    pos, fields = 13, {}
    for expected in (b'a', b'b', b'c', b'd', b'e'):
        if raw[pos:pos+1] != expected:
            raise ValueError('Invalid .bit field order')
        pos += 1
        width = 4 if expected == b'e' else 2
        if pos + width > len(raw): raise ValueError('Truncated .bit header')
        size = int.from_bytes(raw[pos:pos+width], 'big'); pos += width
        if not size or pos + size > len(raw): raise ValueError('Truncated .bit field')
        fields[expected] = raw[pos:pos+size]; pos += size
    if pos != len(raw): raise ValueError('Trailing bytes after .bit payload')
    part = fields[b'b'].rstrip(b'\0').decode('ascii')
    if part not in ('6slx16ftg256', 'xc6slx16ftg256'):
        raise ValueError('Wrong FPGA part: ' + part)
    payload = fields[b'e']
    if not 0x10000 <= len(payload) <= LIMIT or b'\xaa\x99\x55\x66' not in payload[:64]:
        raise ValueError('Invalid Spartan-6 image size/sync word')
    return payload

class Transport:
    def __init__(self, device):
        self.device_address = device
        self.process = None
        self.fd = None
        self.linux = None
        if device.startswith(('win:', 'winlink:')):
            arguments = ['--device-link',device[8:]] if device.startswith('winlink:') else [device[4:]]
            self.process = subprocess.Popen([str(helper_path()), *arguments], stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding='utf-8', bufsize=1,
                creationflags=subprocess.CREATE_NO_WINDOW)
            self.lines = queue.Queue()
            def reader(pipe, lines):
                try:
                    for line in pipe: lines.put(line.strip())
                finally: lines.put(None)
            threading.Thread(target=reader,args=(self.process.stdout,self.lines),daemon=True).start()
            try:
                result = self._line()
                if result != 'READY': raise RuntimeError(result or 'Cannot open Windows XU; check FX3 firmware')
            except Exception:
                self.close(); raise
        else:
            if sys.platform != 'linux': raise ValueError('Windows devices use win:N; run list first')
            from linux_uvc import LinuxTransport
            self.linux = LinuxTransport(device)

    def _line(self):
        try: line=self.lines.get(timeout=20)
        except queue.Empty:
            self.process.kill()
            raise TimeoutError('Windows camera operation timed out; no automatic write retry')
        if line is None: raise RuntimeError('Camera transport disconnected')
        return line

    def query(self, set_data=None, fast=False, selector=None):
        if selector not in (None,7): raise ValueError("Unsupported selector")
        self_upgrade = selector == 7
        size = FAST_SIZE if fast or self_upgrade else 32
        if set_data is not None and len(set_data) != size: raise ValueError('Invalid USB packet length')
        if self.process:
            command = ('U' if self_upgrade else 's' if fast else 'S') + set_data.hex() if set_data is not None else ('u' if self_upgrade else 'g' if fast else 'G')
            self.process.stdin.write(command + '\n'); self.process.stdin.flush()
            line = self._line()
            if set_data is not None:
                if line != 'OK': raise RuntimeError('XU SET failed: ' + line)
                return
            if len(line) != size*2: raise RuntimeError('XU GET failed: ' + line)
            return bytes.fromhex(line)
        if self.linux is None: raise RuntimeError('Device transport is closed')
        return self.linux.query(set_data,fast,selector)

    def read_serial(self):
        from fx3_serial import read_device_serial
        if self.linux is not None:
            self.linux._check_identity()
        return read_device_serial(self.device_address)

    def supports_fast(self):
        try:
            response = self.query(fast=True) # GET only, safe on older FX3 firmware.
            return len(response)==FAST_SIZE and response[:2]==b'F\x02' and crc16(response)==0
        except (RuntimeError,OSError):
            return False

    def close(self):
        if self.linux is not None:
            self.linux.close(); self.linux=None
        if self.process:
            try: self.process.stdin.close()
            except (BrokenPipeError,OSError): pass
            try: self.process.wait(timeout=3)
            except subprocess.TimeoutExpired: self.process.kill(); self.process.wait()
            self.process.stdout.close()
            self.process = None
        if self.fd is not None: os.close(self.fd); self.fd = None

class Programmer:
    def __init__(self, transport):
        self.transport, self.seq = transport, 0
        self.fast=False; self.i2c_hz=100000
        # Keep bulk reads fast; avoid rate switching between page programming
        # and legacy status polls, which always run at 100 kHz in FX3.
        self.write_i2c_hz=100000
        self.command_gap_seconds=0
        self.journal=lambda record: None
        self.last_command=None
        self.flash_context={}
        self.mode_detail='兼容模式'

    def command(self, op, address=0, count=0, data=b'', fast=False):
        fast = fast or op in (0x22,0x24)
        self.seq = (self.seq + 1) & 255
        hz=(self.write_i2c_hz if op==0x24 else self.i2c_hz) if fast else 100000
        packet = make_fast_packet(op,self.seq,address,count,data,hz) if fast else make_packet(op,self.seq,address,count,data)
        context={'op':f'0x{op:02x}','address':f'0x{address:06x}','count':count,
                 'sequence':self.seq,'selector':6 if fast else 5,'i2c_hz':hz,
                 'phase':'SET','flash':dict(self.flash_context)}
        started=time.monotonic()
        def record(event, **extra):
            self.last_command=dict(context,event=event,elapsed_seconds=round(time.monotonic()-started,6),**extra)
            self.journal(dict(self.last_command))
        # Persist intent before issuing a command. Failed writes are NEVER
        # replayed or resumed automatically, even after reopening a camera.
        record('start')
        try:
            if self.command_gap_seconds: time.sleep(self.command_gap_seconds)
            if fast: self.transport.query(packet,fast=True)
            else: self.transport.query(packet)
            context['phase']='GET';record('set_accepted')
            # SET acknowledgement is not proof that FPGA/Flash work completed.
            deadline = time.monotonic() + 2
            while time.monotonic() < deadline:
                response = self.transport.query(fast=True) if fast else self.transport.query()
                context['phase']='response'
                if len(response) != (FAST_SIZE if fast else 32) or response[:2] != (b'F\x02' if fast else b'F\x01') or crc16(response):
                    raise RuntimeError('Corrupt/unsupported upgrade response')
                if response[3] != self.seq or response[5] != op or response[2] == 1:
                    time.sleep(.001 if fast else .01);context['phase']='GET';continue
                if response[2]: raise UpgradeStatusError(op,response[2],response)
                expected = {1:3,2:count,3:0,4:count,5:1,6:4,0x10:0,0x11:0,0x22:count,0x24:count}[op]
                if response[4] != (expected & 255): raise RuntimeError('Invalid response length')
                record('complete')
                return response[8:8+expected]
            raise TimeoutError('Upgrade response sequence/command timeout')
        except Exception as error:
            error.command_context=dict(context)
            try: record('error',error=str(error))
            except Exception: pass # Preserve the transport failure if disk logging also fails.
            raise

    def begin(self):
        self.command(0x10)
        ident = self.command(1)
        if ident != bytes.fromhex('ef4015'):
            raise RuntimeError('Expected FPGA configuration memory EF4015; got ' + ident.hex())
        self.wait_ready()
        status = self.command(5)[0]
        if status & 0x7c: raise RuntimeError(f'Flash protection bits set: {status:#x}; no automatic unlock')
        self.negotiate()
        return ident

    def negotiate(self):
        self.fast=False;self.i2c_hz=100000
        if not getattr(self.transport,'supports_fast',lambda:False)(): return
        try:
            caps=self.command(6,fast=True)
        except UpgradeStatusError as error:
            if error.status==0x82:
                self.mode_detail='兼容模式：当前 FPGA 固件使用兼容传输，本次可安装新版 FPGA 固件'
                return
            raise
        if caps!=b'F2\x01\x00': raise RuntimeError('Unsupported FPGA capabilities')
        baseline=self.command(2,0,16)
        def preflight():
            first=self.command(0x22,0,256)
            second=self.command(0x22,0,256)
            if first!=second or first[:16]!=baseline:
                raise RuntimeError('Fast read preflight differs from legacy read; no erase performed')
        self.i2c_hz=400000
        try:
            preflight()
            self.mode_detail='批量模式：两次只读预检通过'
        except (RuntimeError,TimeoutError,OSError) as error:
            if isinstance(error,UpgradeStatusError) and error.status==0x88: raise
            # Only read-only preflight may fall back. Never replay a write.
            self.i2c_hz=100000
            try:
                preflight()
            except (RuntimeError,TimeoutError,OSError) as slow_error:
                raise RuntimeError(f'V2 read-only preflight failed at both rates. 400 kHz: {error}; 100 kHz: {slow_error}') from slow_error
            self.mode_detail='批量模式：高速预检未通过，已降速：'+str(error)
        if self.i2c_hz!=self.write_i2c_hz:
            read_hz=self.i2c_hz
            self.i2c_hz=self.write_i2c_hz
            try:
                preflight()
            finally:
                self.i2c_hz=read_hz
            self.mode_detail+='；降速后的只读预检通过（未测试实际编程）'
        self.fast=True

    def wait_ready(self, timeout=3):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if not self.command(5)[0] & 1: return
            time.sleep(.005)
        raise TimeoutError('NOR WIP did not clear')

    def read(self, size=LIMIT, progress=lambda *_: None, stage='read'):
        data = bytearray()
        progress(stage,0,size)
        chunk = FAST_CHUNK if self.fast else CHUNK
        for addr in range(0, size, chunk):
            data.extend(self.command(0x22 if self.fast else 2, addr, min(chunk, size-addr)))
            if addr % SECTOR == 0: progress(stage, addr, size)
        progress(stage,size,size)
        return bytes(data)

    def program(self, payload, progress=lambda *_: None):
        if not 0 < len(payload) <= LIMIT: raise ValueError('Image exceeds allowed configuration region')
        start=time.monotonic();timings={};pages=0
        def timed_read(stage):
            before=time.monotonic()
            data=self.read(size=LIMIT,progress=progress,stage=stage)
            timings[stage]=round(time.monotonic()-before,3)
            return data
        expected = payload.ljust(LIMIT, b'\xff')
        write_start=time.monotonic()
        # V3 never reads the old image for backup or comparison. Erase every
        # sector, including the tail beyond a shorter replacement payload.
        # Keep the cancellation boundary immediately before the first erase.
        chunk_size=FAST_CHUNK if self.fast else CHUNK
        self.command_gap_seconds=.002
        try:
            for sector in range(0,LIMIT,SECTOR):
                self.flash_context.update(sector=f'0x{sector:06x}',page=None,operation='erase')
                progress('program',sector,LIMIT)
                chunk = expected[sector:sector+SECTOR]
                self.command(3, sector); self.wait_ready()
                for offset in range(0, SECTOR, chunk_size):
                    part = chunk[offset:offset+chunk_size]
                    if part == b'\xff'*chunk_size: continue
                    self.flash_context.update(page=f'0x{sector+offset:06x}',operation='program')
                    self.command(0x24 if self.fast else 4, sector+offset, len(part), part)
                    pages+=1
                    self.wait_ready()
                    self.flash_context['last_completed_page']=f'0x{sector+offset:06x}'
                self.flash_context['last_completed_sector']=f'0x{sector:06x}'
                progress('program', sector+SECTOR, LIMIT)
        finally:
            self.command_gap_seconds=0
        timings['program']=round(time.monotonic()-write_start,3)
        progress('program',LIMIT,LIMIT)
        self.flash_context['operation']='verify'
        actual = timed_read('verify')
        if actual != expected:
            first = next(i for i,(a,b) in enumerate(zip(actual,expected)) if a != b)
            raise RuntimeError(f'Full readback mismatch at {first:#x}; DO NOT power-cycle; recover via JTAG or retry')
        return {'application_version':APP_VERSION,'payload_bytes':len(payload), 'payload_sha256':hashlib.sha256(payload).hexdigest(),
            'protocol':2 if self.fast else 1,'i2c_hz':self.i2c_hz,'write_i2c_hz':self.write_i2c_hz if self.fast else 100000,'erased_sectors':LIMIT//SECTOR,
            'program_commands':pages,'stage_seconds':timings,
            'elapsed_seconds':round(time.monotonic()-start,3),
            'verified_region_sha256':hashlib.sha256(actual).hexdigest()}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='action',required=True)
    sub.add_parser('list')
    inspect=sub.add_parser('inspect');inspect.add_argument('bit')
    for action in ('info','program'):
        p=sub.add_parser(action);p.add_argument('--device',required=True)
        if action=='program':
            p.add_argument('bit');p.add_argument('--report',help='Optional JSON result file')
            p.add_argument('--accept-single-image-risk',action='store_true',required=True)
    args=parser.parse_args()
    if args.action=='list':
        if sys.platform=='win32': return subprocess.call([str(Path(__file__).with_name('xu_transport.exe')), '--list'])
        print(json.dumps(list_devices(),ensure_ascii=False,indent=2));return 0
    if args.action=='inspect':
        image=bit_payload(args.bit);print(json.dumps({'bytes':len(image),'sha256':hashlib.sha256(image).hexdigest()},indent=2));return 0
    image=bit_payload(args.bit) if args.action=='program' else None
    def progress(stage,n,total): print(f'\r{stage}: {n}/{total} ({100*n/total:.1f}%)',end='',flush=True)
    transport=Transport(args.device);programmer=Programmer(transport)
    try:
        ident=programmer.begin();print('FPGA memory:',ident.hex());print(programmer.mode_detail)
        if args.action=='program':
            result=programmer.program(image,progress)
            if args.report: Path(args.report).write_text(json.dumps(result,indent=2),encoding='utf-8')
            print('\n'+json.dumps(result,indent=2))
            print('\nVERIFIED. Power-cycle the board to load the new FPGA image.')
    finally:
        try:
            try: programmer.command(0x11)
            except Exception as cleanup_error:
                print('\nEND session failed:',cleanup_error,file=sys.stderr)
        finally: transport.close()
    return 0

if __name__=='__main__':
    try: sys.exit(main())
    except (OSError,RuntimeError,ValueError,TimeoutError) as error:
        print('\nERROR:',error,file=sys.stderr);sys.exit(1)
