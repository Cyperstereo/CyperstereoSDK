"""Hardware smoke test for cyper_stream.exe (needs a connected camera)."""
import collections
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import camera_param
import cyper_stream_client as csc

counts = collections.Counter()
last = {}


def on_message(kind, head, body):
    key = 'frame' if kind == 'F' else head.get('type')
    counts[key] += 1
    last[key] = head
    if key in ('error', 'warning', 'info', 'snapshot', 'exited'):
        print(key, head)


root = Path(tempfile.mkdtemp(prefix='cyper_'))
out = root / '图像 保存'
helper = csc.StreamHelper(on_message=on_message)
try:
    time.sleep(4)
    info = camera_param.ParamClient(csc.HelperTransport(helper)).info()
    print('param via helper:', info.sensor.name, info.exposure_lines, 'lines', info.gain_code / 64, 'x')
    helper.snapshot(str(out / 'snap'), 'png')
    helper.record(str(out / 'rec'), 2, 'jpg')
    time.sleep(3)
    helper.stop_record()
    time.sleep(1)
    print('status:', last.get('status'))
    print('imu sample:', (last.get('imu') or {}).get('samples', [None])[-1])
    print('telemetry:', last.get('telemetry'))
    print('counts:', dict(counts))
finally:
    helper.stop()
for dirpath, _, files in os.walk(out):
    if files:
        print(Path(dirpath).relative_to(out), len(files), files[0])
shutil.rmtree(root, ignore_errors=True)
