// cyper_stream: headless Cyperstereo SDK capture for the Cyperstereo GUI.
//
// The processing path (ISP per plane, six-image halves, V1.6 C3/C4 order) is
// the SDK capture_image_imu sample. Output goes to the GUI over the ORIGINAL
// stdout as framed binary messages; anything the SDK prints is redirected to
// stderr so it can never corrupt the stream.
//
//   message := "CYP1" type:u8 head_len:u32le body_len:u32le head body
//   type 'J': head is one JSON object, no body
//   type 'F': head is JSON {"slot":i,...}, body is a JPEG preview
//
// Commands on stdin, one per line:
//   preview <fps> <max_width>      preview rate (0 = off) and tile width
//   snapshot <dir> <png|jpg>       save the next processed frame
//   record <dir> <rate_hz> <png|jpg>   save frames at rate_hz plus imu.csv
//   stop_record
//   xs <64 hex>  /  xg             UVC XU entity 3 selector 5 SET / GET
//   quit
#include <array>
#include <atomic>
#include <cctype>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#ifdef _WIN32
#include <direct.h>
#include <fcntl.h>
#include <io.h>
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <sys/stat.h>
#include <unistd.h>
#endif
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "six_camera_isp.h"
#include "thread_priority.h"

CYPERSTEREO_USE_NAMESPACE

namespace {

constexpr double kGravity = 9.7887;

std::atomic<bool> g_stop{false};
int g_out_fd = -1;
std::mutex g_out_mtx;

std::string JsonEscape(const std::string &s) {
  std::string r;
  for (char c : s) {
    if (c == '"' || c == '\\') { r += '\\'; r += c; }
    else if (static_cast<unsigned char>(c) < 0x20) r += ' ';
    else r += c;
  }
  return r;
}

bool WriteAll(const void *data, size_t size) {
  const char *p = static_cast<const char *>(data);
  while (size) {
#ifdef _WIN32
    const int n = _write(g_out_fd, p, static_cast<unsigned>(size > (1u << 30) ? (1u << 30) : size));
#else
    const ssize_t n = ::write(g_out_fd, p, size);
#endif
    if (n <= 0) return false;
    p += n;
    size -= static_cast<size_t>(n);
  }
  return true;
}

void Send(char type, const std::string &head, const std::vector<uchar> *body = nullptr) {
  std::lock_guard<std::mutex> lock(g_out_mtx);
  unsigned char header[13] = {'C', 'Y', 'P', '1', static_cast<unsigned char>(type)};
  const uint32_t hl = static_cast<uint32_t>(head.size());
  const uint32_t bl = body ? static_cast<uint32_t>(body->size()) : 0;
  for (int i = 0; i < 4; ++i) {
    header[5 + i] = static_cast<unsigned char>(hl >> (8 * i));
    header[9 + i] = static_cast<unsigned char>(bl >> (8 * i));
  }
  if (!WriteAll(header, sizeof(header)) || !WriteAll(head.data(), head.size()) ||
      (bl && !WriteAll(body->data(), bl)))
    g_stop = true;  // GUI went away.
}

void SendJson(const std::string &json) { Send('J', json); }

void SendError(const std::string &message) {
  SendJson("{\"type\":\"error\",\"message\":\"" + JsonEscape(message) + "\"}");
}

void LowerThreadPriority() {
#ifdef _WIN32
  SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
#endif
}

// Paths arrive from the GUI as UTF-8; Windows needs the wide API for them.
#ifdef _WIN32
std::wstring Wide(const std::string &utf8) {
  const int n = MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), nullptr, 0);
  std::wstring w(n, L'\0');
  MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), &w[0], n);
  return w;
}
#endif

void MakeDir(const std::string &path) {
#ifdef _WIN32
  _wmkdir(Wide(path).c_str());
#else
  mkdir(path.c_str(), 0755);
#endif
}

FILE *OpenFile(const std::string &path, const char *mode) {
#ifdef _WIN32
  return _wfopen(Wide(path).c_str(), Wide(mode).c_str());
#else
  return std::fopen(path.c_str(), mode);
#endif
}

bool WriteImage(const std::string &path, const cv::Mat &image, const std::vector<int> &params) {
  std::vector<uchar> buf;
  if (!cv::imencode(path.substr(path.size() - 4), image, buf, params)) return false;
  FILE *f = OpenFile(path, "wb");
  if (!f) return false;
  const bool ok = std::fwrite(buf.data(), 1, buf.size(), f) == buf.size();
  return std::fclose(f) == 0 && ok;
}

// Creates every component of a '/'- or '\\'-separated path.
void MakeDirs(const std::string &path) {
  for (size_t i = 1; i <= path.size(); ++i)
    if (i == path.size() || path[i] == '/' || path[i] == '\\')
      MakeDir(path.substr(0, i));
}

bool HexToBytes(const std::string &hex, std::vector<uint8_t> &out) {
  if (hex.size() % 2) return false;
  out.clear();
  for (size_t i = 0; i < hex.size(); i += 2) {
    unsigned v = 0;
    if (std::sscanf(hex.c_str() + i, "%2x", &v) != 1) return false;
    out.push_back(static_cast<uint8_t>(v));
  }
  return true;
}

std::string BytesToHex(const uint8_t *p, size_t n) {
  static const char *d = "0123456789abcdef";
  std::string r;
  for (size_t i = 0; i < n; ++i) { r += d[p[i] >> 4]; r += d[p[i] & 15]; }
  return r;
}

// ---- Shared state between the stdin thread and the capture loop ----------
struct Control {
  std::mutex mtx;
  double preview_fps = 10.0;
  int preview_width = 640;
  int zoom_slot = -1;  // this preview slot is sent at full resolution
  bool snapshot = false;
  std::string snapshot_dir, snapshot_format = "png";
  bool recording = false;
  std::string record_dir, record_format = "png";
  double record_rate = 1.0;
  uint64_t record_generation = 0;
};
Control g_control;

// ---- UVC XU relay (entity 3, selector 5, 32-byte packets) ---------------
struct XuRelay {
  uvc::device *device = nullptr;
  std::mutex mtx;
  int node = -1;
  uvc::xu Xu(int n) const {
    return uvc::xu{3, n, {0xffffffff, 0xffff, 0xffff, {0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff}}};
  }
  bool Query(bool set, uint8_t data[32], int n) {
    try {
      return uvc::xu_control_query(*device, Xu(n), 5,
                                   set ? uvc::XU_QUERY_SET : uvc::XU_QUERY_GET, 32, data);
    } catch (const std::exception &) {
      return false;
    }
  }
  bool Probe() {
    if (node >= 0) return true;
    for (int n = 0; n < 32; ++n) {
      uint8_t data[32] = {};
      if (Query(false, data, n) && data[0] == 0x46) { node = n; return true; }
    }
    return false;
  }
  void Handle(bool set, const std::string &hex) {
    std::lock_guard<std::mutex> lock(mtx);
    uint8_t data[32] = {};
    std::vector<uint8_t> bytes;
    if (set && (!HexToBytes(hex, bytes) || bytes.size() != 32)) {
      SendJson("{\"type\":\"xu\",\"ok\":false,\"message\":\"bad packet\"}");
      return;
    }
    if (set) std::memcpy(data, bytes.data(), 32);
    if (!Probe() || !Query(set, data, node)) {
      SendJson("{\"type\":\"xu\",\"ok\":false,\"message\":\"XU selector 5 unavailable\"}");
      return;
    }
    SendJson(set ? std::string("{\"type\":\"xu\",\"ok\":true}")
                 : "{\"type\":\"xu\",\"ok\":true,\"data\":\"" + BytesToHex(data, 32) + "\"}");
  }
};
XuRelay g_xu;

void StdinLoop() {
  std::string line;
  while (!g_stop && std::getline(std::cin, line)) {
    std::istringstream in(line);
    std::string cmd;
    in >> cmd;
    if (cmd == "quit") break;
    if (cmd == "xs" || cmd == "xg") {
      std::string hex;
      in >> hex;
      g_xu.Handle(cmd == "xs", hex);
      continue;
    }
    std::lock_guard<std::mutex> lock(g_control.mtx);
    if (cmd == "preview") {
      double fps = 10; int width = 640;
      in >> fps >> width;
      g_control.preview_fps = std::max(0.0, std::min(fps, 60.0));
      g_control.preview_width = std::max(160, std::min(width, 4096));
    } else if (cmd == "zoom") {
      int slot = -1;
      in >> slot;
      g_control.zoom_slot = slot;
    } else if (cmd == "snapshot") {
      in >> std::ws;
      std::string rest, fmt;
      std::getline(in, rest);
      const size_t sp = rest.find_last_of(' ');
      fmt = sp == std::string::npos ? "png" : rest.substr(sp + 1);
      g_control.snapshot_dir = sp == std::string::npos ? rest : rest.substr(0, sp);
      g_control.snapshot_format = fmt == "jpg" ? "jpg" : "png";
      g_control.snapshot = true;
    } else if (cmd == "record") {
      // record <dir with spaces allowed> <rate> <fmt>
      in >> std::ws;
      std::string rest;
      std::getline(in, rest);
      const size_t s2 = rest.find_last_of(' ');
      const size_t s1 = s2 == std::string::npos ? s2 : rest.find_last_of(' ', s2 - 1);
      if (s1 == std::string::npos) { SendError("record: bad arguments"); continue; }
      g_control.record_dir = rest.substr(0, s1);
      g_control.record_rate = std::max(0.1, std::atof(rest.substr(s1 + 1, s2 - s1 - 1).c_str()));
      g_control.record_format = rest.substr(s2 + 1) == "jpg" ? "jpg" : "png";
      g_control.recording = true;
      ++g_control.record_generation;
    } else if (cmd == "stop_record") {
      g_control.recording = false;
    }
  }
  g_stop = true;
}

// ---- Preview sender: single-slot mailbox, newest frame wins --------------
struct PreviewFrame {
  std::vector<cv::Mat> tiles;
  std::vector<std::string> names;
  std::string telemetry;  // JSON array, one object per tile
};

class PreviewSender {
 public:
  PreviewSender() : thread_([this] { Run(); }) {}
  ~PreviewSender() {
    { std::lock_guard<std::mutex> lock(mtx_); done_ = true; }
    con_.notify_one();
    thread_.join();
  }
  void Post(PreviewFrame frame) {
    { std::lock_guard<std::mutex> lock(mtx_); slot_.reset(new PreviewFrame(std::move(frame))); }
    con_.notify_one();
  }

 private:
  void Run() {
    LowerThreadPriority();
    std::vector<uchar> jpeg;
    const std::vector<int> params{cv::IMWRITE_JPEG_QUALITY, 85};
    while (true) {
      std::unique_ptr<PreviewFrame> frame;
      {
        std::unique_lock<std::mutex> lock(mtx_);
        con_.wait(lock, [this] { return done_ || slot_; });
        if (done_) return;
        frame.swap(slot_);
      }
      for (size_t i = 0; i < frame->tiles.size(); ++i) {
        if (frame->tiles[i].empty() || !cv::imencode(".jpg", frame->tiles[i], jpeg, params)) continue;
        std::ostringstream head;
        head << "{\"slot\":" << i << ",\"count\":" << frame->tiles.size()
             << ",\"name\":\"" << frame->names[i] << "\",\"w\":" << frame->tiles[i].cols
             << ",\"h\":" << frame->tiles[i].rows << "}";
        Send('F', head.str(), &jpeg);
      }
      SendJson("{\"type\":\"telemetry\",\"cameras\":" + frame->telemetry + "}");
    }
  }
  std::mutex mtx_;
  std::condition_variable con_;
  std::unique_ptr<PreviewFrame> slot_;
  bool done_ = false;
  std::thread thread_;
};

// ---- Image writer: bounded queue; a full queue drops and counts ----------
struct SaveJob {
  std::vector<std::pair<std::string, cv::Mat>> files;
};

class ImageWriter {
 public:
  ImageWriter() {
    const unsigned n = std::max(2u, std::min(4u, std::thread::hardware_concurrency() / 2));
    for (unsigned i = 0; i < n; ++i) threads_.emplace_back([this] { Run(); });
  }
  ~ImageWriter() {
    { std::lock_guard<std::mutex> lock(mtx_); done_ = true; }
    con_.notify_all();
    for (auto &t : threads_) t.join();
  }
  bool Push(SaveJob job) {
    std::lock_guard<std::mutex> lock(mtx_);
    if (queue_.size() >= 12) { ++dropped_; return false; }
    queue_.push_back(std::move(job));
    con_.notify_one();
    return true;
  }
  uint64_t written() const { return written_; }
  uint64_t dropped() const { return dropped_; }
  uint64_t failed() const { return failed_; }
  size_t pending() {
    std::lock_guard<std::mutex> lock(mtx_);
    return queue_.size();
  }

 private:
  void Run() {
    LowerThreadPriority();
    const std::vector<int> png{cv::IMWRITE_PNG_COMPRESSION, 1};
    const std::vector<int> jpg{cv::IMWRITE_JPEG_QUALITY, 95};
    while (true) {
      SaveJob job;
      {
        std::unique_lock<std::mutex> lock(mtx_);
        con_.wait(lock, [this] { return done_ || !queue_.empty(); });
        if (queue_.empty()) return;  // done_ and drained
        job = std::move(queue_.front());
        queue_.pop_front();
      }
      bool ok = true;
      for (auto &f : job.files) {
        const bool is_jpg = f.first.size() > 4 && f.first.compare(f.first.size() - 4, 4, ".jpg") == 0;
        ok = WriteImage(f.first, f.second, is_jpg ? jpg : png) && ok;
      }
      if (ok) ++written_; else ++failed_;
    }
  }
  std::mutex mtx_;
  std::condition_variable con_;
  std::deque<SaveJob> queue_;
  bool done_ = false;
  std::atomic<uint64_t> written_{0}, dropped_{0}, failed_{0};
  std::vector<std::thread> threads_;
};

// FrameInfo holds only the newest frame's IMU, so samples are collected in the
// USB callback: a frame the main loop skips must not lose its IMU data.
struct ImuSample {
  double t, ax, ay, az, gx, gy, gz, temp;
};

class ImuCollector {
 public:
  void Collect(const IMUStreamData &imu) {
    std::lock_guard<std::mutex> lock(mtx_);
    for (int i = 0; i < imu.imu_count; ++i) {
      if (imu.imu_timestamp[i] <= last_ts_) continue;
      last_ts_ = imu.imu_timestamp[i];
      samples_.push_back({imu.imu_timestamp[i], imu.acc_x[i] * kGravity, imu.acc_y[i] * kGravity,
                          imu.acc_z[i] * kGravity, imu.gyro_x[i], imu.gyro_y[i], imu.gyro_z[i],
                          imu.temperature[i]});
    }
    if (samples_.size() > 20000) samples_.erase(samples_.begin(), samples_.end() - 20000);
  }
  void Drain(std::vector<ImuSample> &out) {
    std::lock_guard<std::mutex> lock(mtx_);
    out.swap(samples_);
    samples_.clear();
  }

 private:
  std::mutex mtx_;
  std::vector<ImuSample> samples_;
  double last_ts_ = -1e300;
};

bool WaitForFrame(FrameInfo &frame_info) {
  std::unique_lock<std::mutex> lock(frame_info.mtx);
  int waited_ms = 0;
  while (frame_info.frame == nullptr && !g_stop) {
    if (frame_info.con.wait_for(lock, std::chrono::milliseconds(200),
                                [&] { return frame_info.frame != nullptr; }))
      break;
    waited_ms += 200;
    if (waited_ms % 5000 == 0)
      SendJson("{\"type\":\"warning\",\"message\":\"no frame for " +
               std::to_string(waited_ms / 1000) + " s\"}");
  }
  if (frame_info.frame == nullptr) return false;
  frame_info.frame = nullptr;
  return true;
}

// Windows PnP instance IDs (the SDK's serial source) are upper-cased, while the
// USB string descriptor keeps its original case.
bool SameSerial(const std::string &a, const std::string &b) {
  if (a.size() != b.size()) return false;
  for (size_t i = 0; i < a.size(); ++i)
    if (std::toupper(static_cast<unsigned char>(a[i])) != std::toupper(static_cast<unsigned char>(b[i])))
      return false;
  return true;
}

std::string Num(double v, int precision = 4) {
  if (!std::isfinite(v)) return "null";
  std::ostringstream o;
  o << std::fixed << std::setprecision(precision) << v;
  return o.str();
}

}  // namespace

int main(int argc, char *argv[]) {
#ifdef _WIN32
  g_out_fd = _dup(1);
  _setmode(g_out_fd, _O_BINARY);
  _dup2(2, 1);
#else
  g_out_fd = dup(1);
  dup2(2, 1);
#endif
  std::cout.rdbuf(std::cerr.rdbuf());
  std::string want_serial;
  bool list_only = false;
  for (int i = 1; i < argc; ++i) {
    const std::string arg(argv[i]);
    if (arg == "--list") list_only = true;
    else if (arg == "--serial" && i + 1 < argc) want_serial = argv[++i];
  }
  cv::setNumThreads(1);
  try {
    auto context = uvc::create_context();
    auto devices = uvc::query_devices(context);
    std::shared_ptr<uvc::device> device;
    std::ostringstream list;
    list << "{\"type\":\"devices\",\"devices\":[";
    bool first = true;
    for (auto &&d : devices) {
      if (uvc::get_vendor_id(*d) != Cyperstereo_VID) continue;
      const std::string serial = uvc::get_serial_number(*d);
      list << (first ? "" : ",") << "{\"serial\":\"" << JsonEscape(serial)
           << "\",\"name\":\"" << JsonEscape(uvc::get_name(*d)) << "\",\"pid\":"
           << uvc::get_product_id(*d) << "}";
      first = false;
      if (!device && (want_serial.empty() || SameSerial(serial, want_serial))) device = d;
    }
    list << "]}";
    SendJson(list.str());
    if (list_only) return 0;
    if (!device) {
      SendError(want_serial.empty() ? "未找到相机" : "未找到序列号为 " + want_serial + " 的相机");
      return 2;
    }
    g_xu.device = device.get();
    std::thread stdin_thread(StdinLoop);
    stdin_thread.detach();

    FrameInfo frame_info{};
    const std::string serial = uvc::get_serial_number(*device);
    const CameraProfile &profile = SelectProfile(serial, *device);
    frame_info.Init(profile);
    frame_info.framestream.serial_num = serial;
    const int process_cameras = SmartSensProcessedCameraCount(serial, profile.num_cameras);
    const bool six_image = IsSixImageSerial(serial);
    const bool is_smartsens = IsSmartSensProfile(profile);
    auto send_info = [&](int images) {
      std::ostringstream info;
      info << "{\"type\":\"info\",\"serial\":\"" << JsonEscape(serial) << "\",\"profile\":\""
           << JsonEscape(profile.name) << "\",\"width\":" << profile.frame_width
           << ",\"height\":" << profile.frame_height << ",\"fps\":" << profile.fps
           << ",\"images\":" << images << ",\"sdk\":\"" << CYPERSTREAM_SDK_COMMIT << "\"}";
      SendJson(info.str());
    };
    send_info(CameraModeImageCount(six_image, process_cameras));
    // A V1.6 six-image FPGA build stamps the C5/C6 marker (meta col 132) in every
    // frame. Without it the FPGA is a quad build sending four full images, and
    // splitting lanes 2/3 into halves would squash each picture 2:1 vertically.
    bool c56_marker_seen = false, quad_fpga = false;
    int frames_without_c56 = 0;
    ImuCollector imu_collector;
    uvc::set_device_mode(*device, profile.frame_width, profile.frame_height,
                         static_cast<int>(Format::YUYV), profile.fps,
                         [&frame_info, &imu_collector](const void *data, std::function<void()> continuation) {
                           SetStreamData(frame_info, data, continuation);
                           std::lock_guard<std::mutex> lock(frame_info.mtx);
                           imu_collector.Collect(frame_info.framestream.imu);
                         });
    uvc::start_streaming(*device, 0);
    ApplyThreadPriority(ThreadRole::kMain, "main");

    cv::Mat left_image(profile.frame_height, profile.cam_width, CV_8U);
    cv::Mat right_image(profile.frame_height, profile.cam_width, CV_8U);
    cv::Mat left_front_image(profile.frame_height, profile.cam_width, CV_8U);
    cv::Mat right_front_image(profile.frame_height, profile.cam_width, CV_8U);
    cv::Mat left_color(profile.frame_height, profile.cam_width, CV_8UC3);
    cv::Mat right_color(profile.frame_height, profile.cam_width, CV_8UC3);
    cv::Mat left_front_color(profile.frame_height, profile.cam_width, CV_8UC3);
    cv::Mat right_front_color(profile.frame_height, profile.cam_width, CV_8UC3);
    const bool use_fast_balanced = FastBalancedIspEnabled();
    const IspMode isp_mode = use_fast_balanced ? IspMode::kFastBalancedBgr888
                                               : IspMode::kQualityReferenceBgr888;
    IspProcessor isp(isp_mode);
    IspProcessor half_isp(isp_mode);
    std::unique_ptr<SixCameraIspProcessor> six_isp;
    const bool use_six_scheduler = use_fast_balanced &&
        !FastEnvTruthy("CYPERSTEREO_DISABLE_SIX_CAMERA_ISP");
    cv::Mat half_raw[4], half_color[4];
    HalfResIspPlanes half_planes;
    for (int i = 0; i < 4; ++i)
      half_color[i].create(SmartSensHalfResHeight(profile.frame_height),
                           SmartSensHalfResWidth(profile.cam_width), CV_8UC3);

    PreviewSender preview;
    ImageWriter writer;
    FILE *imu_csv = nullptr;
    uint64_t imu_generation = 0;
    auto last_preview = std::chrono::steady_clock::now() - std::chrono::hours(1);
    auto last_status = std::chrono::steady_clock::now();
    auto last_imu_msg = last_status;
    double last_record_ts = -1e9;
    uint64_t frames = 0, frames_at_status = 0, imu_samples = 0, imu_at_status = 0;
    uint64_t record_sets = 0;
    std::ostringstream imu_batch;
    int imu_batch_n = 0;
    std::vector<ImuSample> imu;

    while (!g_stop) {
      if (!WaitForFrame(frame_info)) break;
      double image_timestamp = 0.0;
      double exposure_time[4]{}, camera_gain[4]{}, isp_camera_gain[4]{}, temperature[4]{};
      bool fpga_bayer_nr[4]{};
      double c56_exposure[2]{}, c56_gain[2]{}, c56_temperature[2]{};
      bool c56_valid = false;
      RawTelemetrySnapshot raw_telemetry;
      uint32_t hardware_version = 0, software_version = 0;
      {
        std::lock_guard<std::mutex> lock(frame_info.mtx);
        auto &fs = frame_info.framestream;
        image_timestamp = fs.image_timestamp;
        raw_telemetry = fs.raw_telemetry;
        hardware_version = fs.hardware_version;
        software_version = fs.software_version;
        cv::swap(fs.left_image, left_image);
        if (process_cameras >= 2) cv::swap(fs.right_image, right_image);
        if (process_cameras >= 4) {
          cv::swap(fs.left_front_image, left_front_image);
          cv::swap(fs.right_front_image, right_front_image);
        }
        if (is_smartsens) {
          for (int i = 0; i < process_cameras && i < 4; ++i) {
            exposure_time[i] = fs.exposure_time[i];
            camera_gain[i] = fs.camera_gain[i];
            isp_camera_gain[i] = fs.isp_camera_gain[i];
            fpga_bayer_nr[i] = fs.fpga_bayer_nr[i];
            temperature[i] = fs.camera_temperature[i];
          }
          c56_valid = fs.c56_telemetry_valid;
          for (int c = 0; c < 2; ++c) {
            c56_exposure[c] = fs.c56_exposure_time[c];
            c56_gain[c] = fs.c56_camera_gain[c];
            c56_temperature[c] = fs.c56_camera_temperature[c];
          }
        }
      }
      ++frames;
      if (six_image && is_smartsens && process_cameras >= 4 && !c56_marker_seen && !quad_fpga &&
          IsV16BoardHardware(static_cast<int>(hardware_version))) {
        if (c56_valid) {
          c56_marker_seen = true;
        } else if (++frames_without_c56 >= 10) {
          quad_fpga = true;
          send_info(process_cameras);
          SendJson("{\"type\":\"warning\",\"message\":\"相机序列号为六目，但 FPGA 是四目固件（无 C5/C6 数据），"
                   "已按四目显示；请烧录六目 FPGA 固件或把序列号改为四目\"}");
        }
      }

      // Control snapshot for this frame.
      double preview_fps; int preview_width, zoom_slot; bool snapshot, recording;
      std::string snapshot_dir, snapshot_format, record_dir, record_format;
      double record_rate; uint64_t record_generation;
      {
        std::lock_guard<std::mutex> lock(g_control.mtx);
        preview_fps = g_control.preview_fps;
        preview_width = g_control.preview_width;
        zoom_slot = g_control.zoom_slot;
        snapshot = g_control.snapshot;
        snapshot_dir = g_control.snapshot_dir;
        snapshot_format = g_control.snapshot_format;
        recording = g_control.recording;
        record_dir = g_control.record_dir;
        record_format = g_control.record_format;
        record_rate = g_control.record_rate;
        record_generation = g_control.record_generation;
        g_control.snapshot = false;
      }

      // IMU: GUI stream (batched ~20 Hz) and, while recording, imu.csv.
      if (recording && imu_generation != record_generation) {
        if (imu_csv) std::fclose(imu_csv);
        MakeDirs(record_dir + "/imu");
        imu_csv = OpenFile(record_dir + "/imu/imu.csv", "a");
        if (!imu_csv) SendError("无法创建 " + record_dir + "/imu/imu.csv");
        imu_generation = record_generation;
        last_record_ts = -1e9;
      }
      if (!recording && imu_csv) { std::fclose(imu_csv); imu_csv = nullptr; }
      imu_collector.Drain(imu);
      for (const ImuSample &s : imu) {
        ++imu_samples;
        imu_batch << (imu_batch_n ? "," : "") << "[" << Num(s.t, 6) << "," << Num(s.ax) << ","
                  << Num(s.ay) << "," << Num(s.az) << "," << Num(s.gx, 6) << "," << Num(s.gy, 6)
                  << "," << Num(s.gz, 6) << "," << Num(s.temp, 2) << "]";
        ++imu_batch_n;
        if (imu_csv)
          std::fprintf(imu_csv, "%.4f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f\n", s.t, s.gx, s.gy, s.gz,
                       s.ax, s.ay, s.az);
      }
      const auto now = std::chrono::steady_clock::now();
      if (imu_batch_n && now - last_imu_msg >= std::chrono::milliseconds(50)) {
        SendJson("{\"type\":\"imu\",\"samples\":[" + imu_batch.str() + "]}");
        imu_batch.str(std::string());
        imu_batch.clear();
        imu_batch_n = 0;
        last_imu_msg = now;
      }

      if (now - last_status >= std::chrono::milliseconds(500)) {
        const double dt = std::chrono::duration<double>(now - last_status).count();
        std::ostringstream st;
        st << "{\"type\":\"status\",\"fps\":" << Num((frames - frames_at_status) / dt, 1)
           << ",\"imu_rate\":" << Num((imu_samples - imu_at_status) / dt, 0)
           << ",\"image_drops\":" << frame_info.image_drop_count
           << ",\"imu_drops\":" << frame_info.imu_drop_count
           << ",\"recording\":" << (recording ? "true" : "false")
           << ",\"record_sets\":" << record_sets << ",\"written\":" << writer.written()
           << ",\"save_dropped\":" << writer.dropped() << ",\"save_failed\":" << writer.failed()
           << ",\"save_pending\":" << writer.pending()
           << ",\"hardware\":" << hardware_version << ",\"software\":" << software_version << "}";
        SendJson(st.str());
        last_status = now;
        frames_at_status = frames;
        imu_at_status = imu_samples;
      }

      const bool preview_due = preview_fps > 0 &&
          now - last_preview >= std::chrono::duration<double>(0.95 / preview_fps);
      const bool record_due = recording &&
          image_timestamp - last_record_ts >= 1.0 / record_rate - 0.5 / std::max(1, profile.fps);
      if (!preview_due && !record_due && !snapshot) continue;

      // ---- ISP (from samples/capture_image_imu.cc) ----
      int n_images = process_cameras;
      const cv::Mat *color_images[6] = {&left_color, &right_color, &left_front_color,
                                        &right_front_color, nullptr, nullptr};
      std::string tags[6] = {"cam1", "cam2", "cam3", "cam4", "cam5", "cam6"};
      std::string names[6] = {"Cam1", "Cam2", "Cam3", "Cam4", "Cam5", "Cam6"};
      int telemetry_plane[6] = {0, 1, 2, 3, -1, -1};
      if (is_smartsens) {
        const BayerConversion image1_bayer = SelectDeliveredPlaneBayer(hardware_version, software_version, 0);
        const BayerConversion image2_bayer = SelectDeliveredPlaneBayer(hardware_version, software_version, 1);
        const BayerConversion image3_bayer = SelectBayerConversion(hardware_version, software_version, 2);
        const BayerConversion image4_bayer = SelectBayerConversion(hardware_version, software_version, 3);
        const bool half_res_lanes = process_cameras >= 4 && !quad_fpga &&
            IsSmartSensHalfResLaneLayout(six_image, static_cast<int>(hardware_version),
                                         static_cast<int>(software_version));
        if (process_cameras <= 1) {
          isp.ApplyParallel({{left_image, left_color, "cam1", isp_camera_gain[0], image1_bayer,
                              fpga_bayer_nr[0], raw_telemetry.RegionForPlane(0)}});
        } else if (half_res_lanes) {
          const SixImageHalves halves = SelectSixImageHalves(hardware_version, software_version,
                                                             isp_camera_gain, c56_gain);
          const bool six_this_frame = use_six_scheduler &&
              IsAr0234FamilyHardware(static_cast<int>(hardware_version));
          if (!six_this_frame) {
            isp.ApplyParallel({
                {left_image, left_color, "cam1", isp_camera_gain[0], image1_bayer,
                 fpga_bayer_nr[0], raw_telemetry.RegionForPlane(0)},
                {right_image, right_color, "cam2", isp_camera_gain[1], image2_bayer,
                 fpga_bayer_nr[1], raw_telemetry.RegionForPlane(1)},
            });
          }
          half_planes.Split(left_front_image, right_front_image, half_raw);
          const BayerConversion *cam_bayer = halves.bayer;
          const double *cam_gain = halves.gain;
          const double half_nr = half_planes.NrGainScale();
          const bool half_tall = half_planes.demosaic_first;
          cv::Mat &hr0 = half_planes.IspRaw(half_raw, 0), &hc0 = half_color[0];
          cv::Mat &hr1 = half_planes.IspRaw(half_raw, 1), &hc1 = half_color[1];
          cv::Mat &hr2 = half_planes.IspRaw(half_raw, 2), &hc2 = half_color[2];
          cv::Mat &hr3 = half_planes.IspRaw(half_raw, 3), &hc3 = half_color[3];
          if (six_this_frame) {
            if (!six_isp) six_isp.reset(new SixCameraIspProcessor(IspPixelFormat::kBgr888));
            const IspFrameJob jobs[] = {
                {left_image, left_color, "cam1", isp_camera_gain[0], image1_bayer,
                 fpga_bayer_nr[0], raw_telemetry.RegionForPlane(0)},
                {right_image, right_color, "cam2", isp_camera_gain[1], image2_bayer,
                 fpga_bayer_nr[1], raw_telemetry.RegionForPlane(1)},
                {hr0, hc0, halves.name[0], cam_gain[0], cam_bayer[0], false, {}, half_nr, half_tall},
                {hr1, hc1, halves.name[1], cam_gain[1], cam_bayer[1], false, {}, half_nr, half_tall},
                {hr2, hc2, halves.name[2], cam_gain[2], cam_bayer[2], false, {}, half_nr, half_tall},
                {hr3, hc3, halves.name[3], cam_gain[3], cam_bayer[3], false, {}, half_nr, half_tall}};
            six_isp->Apply(jobs);
          } else {
            half_isp.ApplyParallel({
                {hr0, hc0, halves.name[0], cam_gain[0], cam_bayer[0], false, {}, half_nr, half_tall},
                {hr1, hc1, halves.name[1], cam_gain[1], cam_bayer[1], false, {}, half_nr, half_tall},
                {hr2, hc2, halves.name[2], cam_gain[2], cam_bayer[2], false, {}, half_nr, half_tall},
                {hr3, hc3, halves.name[3], cam_gain[3], cam_bayer[3], false, {}, half_nr, half_tall},
            });
          }
          OrientSixImageHalves(hardware_version, half_raw, half_color);
          n_images = 6;
          const int *half_order = SixImageHalfOutputOrder(hardware_version);
          const bool v16 = halves.camera[0] == 3;
          for (int i = 0; i < 4; ++i) {
            const int h = half_order[i];
            const int camera = SixCamHalfImageCamera(static_cast<int>(hardware_version), h);
            color_images[2 + i] = &half_color[h];
            tags[2 + i] = "cam" + std::to_string(camera) + (v16 ? "" : "h");
            names[2 + i] = "C" + std::to_string(camera) + "h";
            telemetry_plane[2 + i] = (v16 && camera >= 5) ? 10 + camera - 5 : -1;
          }
        } else if (process_cameras >= 4) {
          isp.ApplyParallel({
              {left_image, left_color, "cam1", isp_camera_gain[0], image1_bayer,
               fpga_bayer_nr[0], raw_telemetry.RegionForPlane(0)},
              {right_image, right_color, "cam2", isp_camera_gain[1], image2_bayer,
               fpga_bayer_nr[1], raw_telemetry.RegionForPlane(1)},
              {left_front_image, left_front_color, "cam3", isp_camera_gain[2], image3_bayer,
               fpga_bayer_nr[2], raw_telemetry.RegionForPlane(2)},
              {right_front_image, right_front_color, "cam4", isp_camera_gain[3], image4_bayer,
               fpga_bayer_nr[3], raw_telemetry.RegionForPlane(3)},
          });
          if (V16QuadShowsC3ThenC4(static_cast<int>(hardware_version), false)) {
            std::swap(color_images[2], color_images[3]);
            std::swap(telemetry_plane[2], telemetry_plane[3]);
          }
        } else {
          isp.ApplyParallel({
              {left_image, left_color, "cam1", isp_camera_gain[0], image1_bayer,
               fpga_bayer_nr[0], raw_telemetry.RegionForPlane(0)},
              {right_image, right_color, "cam2", isp_camera_gain[1], image2_bayer,
               fpga_bayer_nr[1], raw_telemetry.RegionForPlane(1)},
          });
        }
      } else {
        // MT9V034: monochrome planes shown as-is.
        cv::cvtColor(left_image, left_color, cv::COLOR_GRAY2BGR);
        cv::cvtColor(right_image, right_color, cv::COLOR_GRAY2BGR);
        n_images = 2;
      }

      if (preview_due) {
        last_preview = now;
        PreviewFrame frame;
        std::ostringstream tel;
        tel << "[";
        for (int i = 0; i < n_images; ++i) {
          const cv::Mat &src = *color_images[i];
          cv::Mat tile;
          if (src.cols > preview_width && i != zoom_slot) {
            const double s = static_cast<double>(preview_width) / src.cols;
            cv::resize(src, tile, cv::Size(preview_width, std::max(1, static_cast<int>(src.rows * s + 0.5))),
                       0, 0, cv::INTER_AREA);
          } else {
            tile = src.clone();
          }
          frame.tiles.push_back(tile);
          frame.names.push_back(names[i]);
          const int p = telemetry_plane[i];
          tel << (i ? "," : "") << "{\"name\":\"" << names[i] << "\"";
          if (is_smartsens && p >= 0 && p < 4)
            tel << ",\"exposure_ms\":" << Num(exposure_time[p] * 1000.0, 3)
                << ",\"gain\":" << Num(camera_gain[p], 2) << ",\"temperature\":" << Num(temperature[p], 1);
          else if (is_smartsens && p >= 10 && c56_valid)
            tel << ",\"exposure_ms\":" << Num(c56_exposure[p - 10] * 1000.0, 3)
                << ",\"gain\":" << Num(c56_gain[p - 10], 2)
                << ",\"temperature\":" << Num(c56_temperature[p - 10], 1);
          tel << "}";
        }
        tel << "]";
        frame.telemetry = tel.str();
        preview.Post(std::move(frame));
      }

      const std::string stamp = std::to_string(static_cast<int64_t>(image_timestamp * 10000));
      auto make_job = [&](const std::string &dir, const std::string &fmt) {
        SaveJob job;
        for (int i = 0; i < n_images; ++i) {
          const std::string sub = dir + "/" + tags[i];
          MakeDirs(sub);
          job.files.emplace_back(sub + "/" + stamp + "." + fmt, color_images[i]->clone());
        }
        return job;
      };
      if (snapshot) {
        const bool ok = writer.Push(make_job(snapshot_dir, snapshot_format));
        SendJson(std::string("{\"type\":\"snapshot\",\"ok\":") + (ok ? "true" : "false") +
                 ",\"dir\":\"" + JsonEscape(snapshot_dir) + "\",\"stamp\":\"" + stamp + "\"}");
      }
      if (record_due) {
        last_record_ts = image_timestamp;
        if (writer.Push(make_job(record_dir, record_format))) ++record_sets;
      }

    }
    uvc::stop_streaming(*device);
    if (imu_csv) std::fclose(imu_csv);
  } catch (const std::exception &e) {
    SendError(e.what());
    return 1;
  }
  SendJson("{\"type\":\"stopped\"}");
  return 0;
}
