"""Record at full rate (PNG) and check frame rate and IMU completeness (needs a camera)."""
import shutil
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cyper_stream_client as csc

rate = float(sys.argv[1]) if len(sys.argv) > 1 else 1000
fmt = sys.argv[2] if len(sys.argv) > 2 else 'png'
statuses = []
helper = csc.StreamHelper(on_message=lambda k, h, b: statuses.append(h) if h.get('type') == 'status' else None)
root = Path(tempfile.mkdtemp(prefix='cyper_stress_'))
try:
    time.sleep(3)
    helper.record(str(root), rate, fmt)
    time.sleep(6)
    helper.stop_record()
    time.sleep(2)
finally:
    helper.stop()
rows = [line.split(',') for line in (root / 'imu' / 'imu.csv').read_text().splitlines()]
ts = [float(r[0]) for r in rows]
gaps = [b - a for a, b in zip(ts, ts[1:])]
print('fps during record:', [s['fps'] for s in statuses[-14:]])
print('last status:', statuses[-1])
print(f'imu rows {len(rows)} over {ts[-1] - ts[0]:.2f}s = {len(rows) / (ts[-1] - ts[0]):.1f} Hz, '
      f'max gap {max(gaps) * 1000:.1f} ms')
print('cam1 files:', len(list((root / 'cam1').iterdir())))
shutil.rmtree(root, ignore_errors=True)
