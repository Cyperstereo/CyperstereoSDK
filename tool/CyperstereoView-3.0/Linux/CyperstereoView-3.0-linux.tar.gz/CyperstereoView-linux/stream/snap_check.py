"""Save one processed set and print each slot's size (needs a camera)."""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cyper_stream_client as csc

out = Path(sys.argv[1] if len(sys.argv) > 1 else r'C:\xc6slx\tmp\snap_check')
fmt = sys.argv[2] if len(sys.argv) > 2 else 'png'
events = []
helper = csc.StreamHelper(on_message=lambda k, h, b: events.append(h) if k == 'J' and h.get('type') in (
    'info', 'snapshot', 'error', 'telemetry') else None)
try:
    time.sleep(4)
    helper.snapshot(str(out), fmt)
    time.sleep(3)
finally:
    helper.stop()
for e in events:
    if e['type'] != 'telemetry':
        print(e)
print([e for e in events if e['type'] == 'telemetry'][-1:])
import cv2
for d in sorted(p for p in out.iterdir() if p.is_dir()):
    files = sorted(d.glob('*.' + fmt))
    if files:
        img = cv2.imread(str(files[-1]))
        print(d.name, img.shape[1], 'x', img.shape[0], files[-1])
