"""FX3 firmware updater. Does not modify the FPGA image and does not keep a backup."""
import hashlib
import struct
import time
from pathlib import Path
from fpga_upgrade import Transport, crc16, list_devices, device_address, is_target_device

VERSION = '1.3'
CAPACITY = 0x100000
PAGE, SECTOR = 256, 4096
TAGS = {1: b'FX3U5V1:SINGLE', 2: b'FX3U5V1:DOUBLE'}

def inspect_image(path):
    raw = Path(path).read_bytes()
    return raw, inspect_bytes(raw)

def inspect_bytes(raw):
    if not 16 <= len(raw) <= CAPACITY or raw[:2] != b'CY' or raw[3] != 0xb0:
        raise ValueError('请选择 FX3 的 CY/B0 格式 .img 文件，不能使用 FPGA .bit/.mcs。')
    if raw[2] & 0xc1:
        raise ValueError('IMG 不是可执行镜像，或含保留的启动配置位。')
    pos, checksum, sections = 4, 0, []
    while True:
        if pos+8 > len(raw): raise ValueError('IMG 段头不完整。')
        words, addr = struct.unpack_from('<II', raw, pos); pos += 8
        if not words:
            entry = addr
            if pos+4 != len(raw): raise ValueError('IMG 结束记录或文件长度错误。')
            expected, = struct.unpack_from('<I', raw, pos)
            if expected != checksum: raise ValueError('IMG 启动校验和错误。')
            if entry & 3 or not any(a <= entry < b for a,b in sections):
                raise ValueError('IMG 入口地址不在已加载的段内。')
            if not (entry < 0x4000 or 0x40000000 <= entry < 0x40080000):
                raise ValueError('IMG 入口不在 FX3 可执行 RAM 内。')
            break
        size = words*4; end = addr+size
        if pos+size > len(raw) or addr & 3:
            raise ValueError('IMG 段数据截断或地址未对齐。')
        if not any(lo <= addr < end <= hi for lo,hi in
                   ((0,0x4000),(0x10000000,0x10002000),(0x40000000,0x40080000))):
            raise ValueError(f'IMG 包含不支持的地址：0x{addr:08x}。')
        if any(addr < b and end > a for a,b in sections): raise ValueError('IMG 段地址重叠。')
        sections.append((addr,end))
        checksum = (checksum + sum(struct.unpack_from('<%dI'%words,raw,pos))) & 0xffffffff
        pos += size
    variants = [v for v,tag in TAGS.items() if tag+b'\0' in raw]
    if len(variants) != 1:
        raise ValueError('IMG 未包含本工具配套的 FX3 升级模块标识。')
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                    variant=variants[0], variant_name='slave' if variants[0]==1 else 'slave_double',
                    entry=f'0x{entry:08x}',sections=len(sections))

def packet(op,seq,address=0,count=0,data=b''):
    if not 0 <= address < CAPACITY or not 0 <= count <= PAGE or len(data)>PAGE:
        raise ValueError('Invalid firmware request range')
    body=bytes((0x55,op,seq,count & 255))+address.to_bytes(3,'big')+b'\0'+data.ljust(278,b'\0')
    return body+crc16(body).to_bytes(2,'big')

class Programmer:
    def __init__(self, transport, journal=lambda _:None):
        self.transport=transport;self.journal=journal;self.seq=0;self.variant=None
        self.session=False;self.dirty=False;self.last_command=None

    def command(self,op,address=0,count=0,data=b''):
        self.seq=(self.seq+1)&255
        context=dict(op=hex(op),address=hex(address),count=count,sequence=self.seq,selector=7)
        def log(event,**extra):
            self.last_command=dict(context,event=event,**extra);self.journal(self.last_command)
        log('start')
        if op in (3,0x24): self.dirty=True
        try:
            self.transport.query(packet(op,self.seq,address,count,data),selector=7)
            log('set_accepted')
            reply=self.transport.query(selector=7)
            if len(reply)!=288 or reply[:2]!=b'U\x01' or crc16(reply):
                raise RuntimeError('FX3 升级应答长度、版本或 CRC 错误；未重试写命令。')
            if reply[3]!=self.seq or reply[5]!=op: raise RuntimeError('FX3 升级应答序号不匹配。')
            status=reply[2]
            if status:
                message={2:'请求 CRC 错误',3:'参数越界或命令错误',0x81:'设备正在采集或另一个升级会话占用',
                    0x82:'升级会话尚未开始或写入未授权',0x8a:'无法关闭 USB 低功耗',
                    0x90:'固件存储访问失败',0x91:'固件存储正在擦写，请保持供电',
                    0x92:'固件存储写保护已启用（不自动解除）',0x93:'固件型号不匹配',0x94:'固件存储未接受写使能'}.get(status,'未知错误')
                raise RuntimeError(f'{message}，状态 0x{status:02x}，地址 0x{address:06x}')
            expected={6:20,0x10:0,0x11:0,0x12:0,1:3,5:2,3:0,0x22:count,0x24:count}[op]
            if reply[4] != expected & 255: raise RuntimeError('FX3 升级返回数据长度不匹配。')
            log('complete');return reply[8:8+expected]
        except Exception as e:
            try: log('error',error=str(e))
            except Exception: pass
            raise

    def begin(self):
        try:
            idle=self.transport.query(selector=7) # GET only: old firmware fails without mutation.
        except Exception as e:
            raise RuntimeError('无法访问 FX3 升级接口。旧固件需先安装一次配套版本；若已安装，请关闭其他摄像头软件并重新连接设备。原始错误：'+str(e)) from e
        if len(idle)!=288 or idle[:2]!=b'U\x01' or crc16(idle):
            raise RuntimeError('不支持的 FX3 自升级接口。')
        caps=self.command(6)
        variant=caps[16]
        if variant not in TAGS or caps[:15]!=TAGS[variant]+b'\0' or caps[17:]!=bytes((20,8,12)):
            raise RuntimeError('FX3 自升级能力/型号不匹配。')
        self.variant=variant
        self.session=True # END required even if BEGIN acknowledgement fails.
        self.command(0x10);self.wait_ready()
        ident=self.command(1)
        if ident!=bytes.fromhex('ef4014'):
            raise RuntimeError('FX3 固件存储器件与配套固件不一致，禁止写入。')
        s1,s2=self.command(5)
        if s1 & 0x7c or s2 & 0x40: raise RuntimeError('FX3 固件存储已设置写保护；不自动解锁。')
        first=self.command(0x22,0,256)
        if first!=self.command(0x22,0,256): raise RuntimeError('两次只读预检数据不同；禁止写入。')
        return dict(jedec=ident.hex().upper(),variant=variant,capacity=CAPACITY,
                    variant_name='slave' if variant==1 else 'slave_double')

    def end(self):
        if self.session:
            try:self.wait_ready()
            except Exception:pass # END itself refuses WIP, but can clean up a failed BEGIN.
            self.command(0x11);self.session=False

    def wait_ready(self,timeout=5):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            if not self.command(5)[0]&1:return
            time.sleep(.01)
        raise TimeoutError('固件擦写忙超时；请保持供电，不会自动重试。')

    def program(self,raw,metadata,progress=lambda *_:None,force_overwrite=False):
        if not self.session or self.variant not in TAGS or metadata.get('variant') not in TAGS:
            raise ValueError('升级会话或固件型号无效；未擦写。')
        if self.variant!=metadata['variant'] and not force_overwrite:
            raise ValueError('固件与所选设备不匹配：slave / slave_double 不能混刷。')
        if len(raw)!=metadata['bytes'] or hashlib.sha256(raw).hexdigest()!=metadata['sha256']:
            raise ValueError('固件内容发生变化。')
        from fx3_serial import verify_prepared
        # Last read-only identity check before ARM/erase, using the active transport.
        verify_prepared(raw,metadata,self.transport.read_serial()['serial'],force_overwrite)
        size=(len(raw)+SECTOR-1)//SECTOR*SECTOR
        target=raw.ljust(size,b'\xff');start=time.monotonic()
        progress('erase',0,size) # GUI cancellation boundary before ARM / first erase.
        self.command(0x12,count=8,data=b'U5WRITE!')
        # Erase first sector first, so interrupted image cannot retain old CY header.
        for addr in range(0,size,SECTOR):
            self.command(3,addr);self.wait_ready();progress('erase',addr+SECTOR,size)
        # Write and verify body while the boot header is still erased.
        for addr in range(PAGE,size,PAGE):
            data=target[addr:addr+PAGE]
            if data!=b'\xff'*PAGE:self.command(0x24,addr,PAGE,data);self.wait_ready()
            progress('program',addr+PAGE,size)
        for addr in range(PAGE,size,PAGE):
            if self.command(0x22,addr,PAGE)!=target[addr:addr+PAGE]:
                raise RuntimeError(f'固件内容校验失败 0x{addr:06x}，启动头尚未提交。')
            progress('body_verify',addr+PAGE,size)
        self.command(0x24,0,PAGE,target[:PAGE]);self.wait_ready()
        readback=bytearray()
        for addr in range(0,size,PAGE):
            data=self.command(0x22,addr,PAGE)
            if data!=target[addr:addr+PAGE]:raise RuntimeError(f'固件最终校验失败 0x{addr:06x}。')
            readback.extend(data);progress('verify',addr+PAGE,size)
        return dict(status='VERIFIED',app_version=VERSION,flash='fx3',path='fx3',
                    force_overwrite=bool(force_overwrite),source_variant=self.variant,target_variant=metadata['variant'],
                    elapsed_seconds=round(time.monotonic()-start,2),written_region=size,
                    verified_sha256=hashlib.sha256(readback[:len(raw)]).hexdigest(),image=metadata)
