#!/usr/bin/env python3
"""Camera maximum exposure and maximum gain.

A written value applies after the camera is power-cycled.
"""
import argparse
import math
import sys
import time

import fpga_upgrade as backend
from fpga_upgrade import crc16, make_packet

OP_STATUS, OP_INFO, OP_ERASE, OP_PROGRAM, OP_READ = 0x05, 0x30, 0x31, 0x32, 0x33
RECORD_SIZE = 16
APP_VERSION = '1.0'


class SensorLimits:
    def __init__(self, kind, name, max_exposure_ms, max_gain, gain_choices=None,
                 min_exposure_ms=1.0, ae_floor_lines=0):
        self.kind, self.name = kind, name
        self.max_exposure_ms, self.max_gain = max_exposure_ms, max_gain
        self.gain_choices = gain_choices
        self.min_exposure_ms, self.min_gain = min_exposure_ms, 1.0
        # AE's normal lower bound; a cap below it also lowers the floor (see ae_controller.v).
        self.ae_floor_lines = ae_floor_lines


SENSORS = {
    1: SensorLimits(1, 'SC136HGS', 10.0, 12.0, min_exposure_ms=0.01, ae_floor_lines=7),
    2: SensorLimits(2, 'AR0234', 20.0, 8.0, (1, 2, 4, 8)),
}


class ParamError(RuntimeError):
    pass


STATUS_TEXT = {
    2: '数据校验失败，请重试',
    3: 'FPGA 程序不支持参数功能，请先升级 FPGA 程序',
    0x81: 'FX3 忙（正在出图或正在升级）。如 FX3 为旧固件，请关闭视频后重试或升级 FX3 固件',
    0x82: 'FX3 固件不支持参数功能，请先升级 FX3 固件',
    0x83: 'FX3 → FPGA I2C 发送失败',
    0x84: 'FX3 → FPGA I2C 接收失败',
    0x85: 'FPGA 应答格式错误',
    0x86: 'FX3 I2C 速率设置失败',
    0x87: 'FPGA 应答 CRC 错误',
}


def status_message(op, status):
    return f'命令 0x{op:02x} 失败（状态 0x{status:02x}）：' + STATUS_TEXT.get(status, '未知错误')


def make_record(kind, exposure_lines, gain_code):
    body = bytes((0x43, 0x50, 1, kind)) + exposure_lines.to_bytes(2, 'big') + gain_code.to_bytes(2, 'big') + bytes(6)
    return body + crc16(body).to_bytes(2, 'big')


def parse_record(data):
    """Return (kind, exposure_lines, gain_code), None for an erased sector, or 'invalid'."""
    if data == b'\xff' * RECORD_SIZE:
        return None
    if len(data) != RECORD_SIZE or data[:3] != b'CP\x01' or any(data[8:14]) or crc16(data):
        return 'invalid'
    return data[3], int.from_bytes(data[4:6], 'big'), int.from_bytes(data[6:8], 'big')


class CameraInfo:
    def __init__(self, data):
        if len(data) != 16 or data[:3] != b'CP\x01':
            raise ParamError('FPGA 参数信息格式错误')
        self.kind = data[3]
        self.exposure_lines = int.from_bytes(data[4:6], 'big')
        self.gain_code = int.from_bytes(data[6:8], 'big')
        self.ready = bool(data[8] & 2)
        self.from_flash = bool(data[8] & 1)
        self.hw_version = data[9]
        self.exposure_limit_lines = int.from_bytes(data[10:12], 'big')
        self.gain_limit_code = int.from_bytes(data[12:14], 'big')
        self.line_ns = int.from_bytes(data[14:16], 'big')
        if self.kind not in SENSORS:
            raise ParamError(f'未知传感器类型 {self.kind}')
        if not self.line_ns:
            raise ParamError('FPGA 行时间为 0')
        self.sensor = SENSORS[self.kind]

    def lines_to_ms(self, lines):
        return lines * self.line_ns / 1e6

    def max_exposure_ms(self):
        return min(self.sensor.max_exposure_ms, self.lines_to_ms(self.exposure_limit_lines + 1))

    def max_gain(self):
        return min(self.sensor.max_gain, self.gain_limit_code / 64)

    def exposure_lines_for(self, ms):
        if not math.isfinite(ms):
            raise ValueError('曝光时间无效')
        limit = self.max_exposure_ms()
        if ms < self.sensor.min_exposure_ms - 1e-9 or ms > limit + 1e-9:
            raise ValueError(f'{self.sensor.name} 最大曝光时间范围 {self.sensor.min_exposure_ms:g} ~ {limit:.3f} ms')
        return max(1, min(int(ms * 1e6 // self.line_ns), self.exposure_limit_lines))

    def exposure_warning(self, lines):
        """Text for a cap that is coarser than requested or below the AE floor, else ''."""
        notes = []
        if lines == 1:
            notes.append(f'最小可设 1 行 = {self.lines_to_ms(1):.3f} ms（曝光以行为单位）')
        if lines < self.sensor.ae_floor_lines:
            notes.append(f'低于 {self.sensor.ae_floor_lines} 行 ({self.lines_to_ms(self.sensor.ae_floor_lines):.3f} ms) '
                         '时 AE 下限随之降低，图像可能出现亮度跳变，请实测确认')
        return '；'.join(notes)

    def gain_code_for(self, gain):
        if not math.isfinite(gain):
            raise ValueError('增益无效')
        limit = self.max_gain()
        if self.sensor.gain_choices:
            if gain not in self.sensor.gain_choices or gain > limit:
                choices = '/'.join(f'{c}x' for c in self.sensor.gain_choices if c <= limit)
                raise ValueError(f'{self.sensor.name} 最大增益只能选择 {choices}')
        elif gain < self.sensor.min_gain - 1e-9 or gain > limit + 1e-9:
            raise ValueError(f'{self.sensor.name} 最大增益范围 {self.sensor.min_gain:g} ~ {limit:g} 倍')
        return min(int(round(gain * 64)), self.gain_limit_code)


class ParamClient:
    def __init__(self, transport):
        self.transport, self.seq = transport, 0

    def command(self, op, count=0, data=b'', timeout=2.0):
        self.seq = (self.seq + 1) & 255
        self.transport.query(make_packet(op, self.seq, 0, count, data))
        deadline = time.monotonic() + timeout
        while True:
            response = self.transport.query()
            if len(response) != 32 or response[:2] != b'F\x01' or crc16(response):
                raise ParamError('相机应答损坏或不支持')
            if response[3] == self.seq and response[5] == op and response[2] != 1:
                break
            if time.monotonic() > deadline:
                raise TimeoutError(f'命令 0x{op:02x} 应答超时')
            time.sleep(0.005)
        if response[2]:
            raise ParamError(status_message(op, response[2]))
        expected = {OP_STATUS: 1, OP_INFO: 16, OP_ERASE: 0, OP_PROGRAM: count, OP_READ: count}[op]
        if response[4] != expected:
            raise ParamError(f'命令 0x{op:02x} 应答长度错误')
        return response[8:8 + expected]

    def info(self):
        return CameraInfo(self.command(OP_INFO))

    def stored(self):
        return parse_record(self.command(OP_READ, RECORD_SIZE))

    def flash_status(self):
        return self.command(OP_STATUS)[0]

    def wait_ready(self, timeout=3.0):
        deadline = time.monotonic() + timeout
        while True:
            status = self.flash_status()
            if not status & 1:
                return status
            if time.monotonic() > deadline:
                raise TimeoutError('Flash 忙状态未结束')
            time.sleep(0.01)

    def _prepare(self):
        status = self.wait_ready()
        if status & 0x7c:
            raise ParamError(f'Flash 写保护位已置位（状态 0x{status:02x}），未执行写入')

    def erase(self):
        self._prepare()
        self.command(OP_ERASE)
        self.wait_ready()
        if self.command(OP_READ, RECORD_SIZE) != b'\xff' * RECORD_SIZE:
            raise ParamError('参数扇区擦除校验失败')

    def write(self, info, exposure_lines, gain_code):
        record = make_record(info.kind, exposure_lines, gain_code)
        self.erase()
        self.command(OP_PROGRAM, RECORD_SIZE, record)
        self.wait_ready()
        if self.command(OP_READ, RECORD_SIZE) != record:
            raise ParamError('参数写入回读校验失败')
        return record


def target_devices():
    return [d for d in backend.list_devices() if backend.is_target_device(d)]


def open_client(device=None):
    if device is None:
        devices = target_devices()
        if not devices:
            raise RuntimeError('未找到相机（VID 04B4 / PID 00F8/00F9）')
        device = backend.device_address(devices[0])
    return backend.Transport(device)


def describe(info, stored):
    s = info.sensor
    lines = [
        f'传感器: {s.name}  (FPGA 硬件版本 {info.hw_version}, 行时间 {info.line_ns / 1000:.3f} us)',
        f'当前生效: 最大曝光 {info.lines_to_ms(info.exposure_lines):.3f} ms ({info.exposure_lines} 行), '
        f'最大增益 {info.gain_code / 64:g} 倍  [{"Flash 参数" if info.from_flash else "程序默认值"}]',
        f'允许范围: 曝光 {s.min_exposure_ms:g} ~ {info.max_exposure_ms():.3f} ms（按 {info.line_ns / 1000:.3f} us 行取整）, '
        + (f'增益 {"/".join(f"{c}x" for c in s.gain_choices if c <= info.max_gain())}'
           if s.gain_choices else f'增益 {s.min_gain:g} ~ {info.max_gain():g} 倍'),
    ]
    if stored is None:
        lines.append('Flash 已保存: 无（使用程序默认值）')
    elif stored == 'invalid':
        lines.append('Flash 已保存: 记录无效（FPGA 将使用默认值）')
    else:
        kind, e, g = stored
        name = SENSORS[kind].name if kind in SENSORS else f'类型 {kind}'
        pending = (e, g) != (info.exposure_lines, info.gain_code) or not info.from_flash
        lines.append(f'Flash 已保存: {name} 最大曝光 {info.lines_to_ms(e):.3f} ms ({e} 行), 最大增益 {g / 64:g} 倍'
                     + ('  （重启相机后生效）' if pending else ''))
    return '\n'.join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(description='相机最大曝光/最大增益参数工具 ' + APP_VERSION)
    parser.add_argument('--device', help='设备地址（见 list），默认第一台相机')
    sub = parser.add_subparsers(dest='action', required=True)
    sub.add_parser('list', help='列出相机')
    sub.add_parser('info', help='读取当前参数')
    p_set = sub.add_parser('set', help='写入参数（重启相机后生效）')
    p_set.add_argument('--exposure-ms', type=float, help='最大曝光时间 (ms)')
    p_set.add_argument('--gain', type=float, help='最大增益（倍）')
    sub.add_parser('reset', help='清除已保存参数，恢复程序默认值（重启后生效）')
    args = parser.parse_args(argv)
    if args.action == 'list':
        for d in target_devices():
            print(backend.device_address(d), d.get('name', ''))
        return 0
    transport = open_client(args.device)
    try:
        client = ParamClient(transport)
        info = client.info()
        if args.action == 'set':
            stored = client.stored()
            base_e, base_g = (stored[1], stored[2]) if isinstance(stored, tuple) and stored[0] == info.kind \
                else (info.exposure_lines, info.gain_code)
            if args.exposure_ms is None and args.gain is None:
                parser.error('至少指定 --exposure-ms 或 --gain')
            e = info.exposure_lines_for(args.exposure_ms) if args.exposure_ms is not None else base_e
            g = info.gain_code_for(args.gain) if args.gain is not None else base_g
            if info.exposure_warning(e):
                print('注意:', info.exposure_warning(e))
            client.write(info, e, g)
            print('写入成功，请重新上电相机使参数生效。')
        elif args.action == 'reset':
            client.erase()
            print('已清除，重新上电后恢复程序默认值。')
        print(describe(client.info(), client.stored()))
    finally:
        transport.close()
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (RuntimeError, ValueError, TimeoutError, OSError) as error:
        print('错误:', error, file=sys.stderr)
        sys.exit(1)
