"""Build the application icons from the CyperStereo logo picture.

    python assets/make_icon.py <logo.png>

Writes assets/cyperstereo.png (512 px, full logo), assets/cyperstereo_mark.png
(512 px, S mark only) and assets/cyperstereo.ico. The full logo's word mark is
unreadable below 64 px, so the 16..48 px icon sizes use the S mark alone.
"""
import struct
import sys
from pathlib import Path

import cv2
import numpy as np

HERE = Path(__file__).resolve().parent


def white_square(image):
    ys, xs = np.where(image.min(axis=2) > 235)
    return image[ys.min():ys.max() + 1, xs.min():xs.max() + 1]


def mark(square):
    colour = (square.max(axis=2).astype(int) - square.min(axis=2)) > 60
    ys, xs = np.where(colour)
    # The S sits above the word mark; split at the widest blank band.
    rows = np.where(colour.any(axis=1))[0]
    gaps = np.diff(rows)
    cut = rows[int(np.argmax(gaps))] + 1
    ys, xs = np.where(colour[:cut])
    s = square[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    side = int(max(s.shape[:2]) * 1.3)
    canvas = np.full((side, side, 3), 255, np.uint8)
    y0, x0 = (side - s.shape[0]) // 2, (side - s.shape[1]) // 2
    canvas[y0:y0 + s.shape[0], x0:x0 + s.shape[1]] = s
    return canvas


def rounded(image, size, radius_ratio=0.2):
    """BGRA image with rounded transparent corners."""
    out = cv2.resize(image, (size, size), interpolation=cv2.INTER_AREA)
    alpha = np.zeros((size * 4, size * 4), np.uint8)
    r = int(size * 4 * radius_ratio)
    cv2.rectangle(alpha, (r, 0), (size * 4 - r, size * 4), 255, -1)
    cv2.rectangle(alpha, (0, r), (size * 4, size * 4 - r), 255, -1)
    for cx, cy in ((r, r), (size * 4 - r, r), (r, size * 4 - r), (size * 4 - r, size * 4 - r)):
        cv2.circle(alpha, (cx, cy), r, 255, -1, cv2.LINE_AA)
    alpha = cv2.resize(alpha, (size, size), interpolation=cv2.INTER_AREA)
    return np.dstack([out, alpha])


def write_ico(path, images):
    pngs = [cv2.imencode('.png', im)[1].tobytes() for im in images]
    header = struct.pack('<HHH', 0, 1, len(pngs))
    offset = 6 + 16 * len(pngs)
    entries = b''
    for im, data in zip(images, pngs):
        size = im.shape[0]
        entries += struct.pack('<BBBBHHII', size % 256, size % 256, 0, 0, 1, 32, len(data), offset)
        offset += len(data)
    path.write_bytes(header + entries + b''.join(pngs))


def main(source):
    picture = cv2.imread(str(source))
    if picture is None:
        raise SystemExit(f'cannot read {source}')
    square = white_square(picture)
    s_mark = mark(square)
    cv2.imwrite(str(HERE / 'cyperstereo.png'), rounded(square, 512))
    cv2.imwrite(str(HERE / 'cyperstereo_mark.png'), rounded(s_mark, 512))
    sizes = [(256, square), (128, square), (64, square), (48, s_mark), (32, s_mark), (24, s_mark), (16, s_mark)]
    write_ico(HERE / 'cyperstereo.ico', [rounded(src, size) for size, src in sizes])


if __name__ == '__main__':
    main(sys.argv[1])
