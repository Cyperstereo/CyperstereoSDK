"""Client for cyper_stream.exe, the SDK capture helper (see stream/cyper_stream.cc).

The helper owns the camera while streaming, so parameter commands are relayed
through it (HelperTransport) instead of opening a second XU handle.
"""
import json
import queue
import struct
import subprocess
import sys
import threading
from pathlib import Path

MAGIC = b'CYP1'
HEADER = struct.Struct('<4sBII')
MAX_PART = 64 << 20


class ProtocolError(RuntimeError):
    pass


class StreamParser:
    """Incremental decoder: feed() bytes, get back (kind, head, body) messages."""

    def __init__(self):
        self.buffer = bytearray()

    def feed(self, data):
        self.buffer += data
        messages = []
        while len(self.buffer) >= HEADER.size:
            magic, kind, head_len, body_len = HEADER.unpack_from(self.buffer)
            if magic != MAGIC or kind not in b'JF' or head_len > MAX_PART or body_len > MAX_PART:
                raise ProtocolError('helper 数据流格式错误')
            end = HEADER.size + head_len + body_len
            if len(self.buffer) < end:
                break
            head = json.loads(bytes(self.buffer[HEADER.size:HEADER.size + head_len]).decode('utf-8'))
            body = bytes(self.buffer[HEADER.size + head_len:end])
            del self.buffer[:end]
            messages.append((chr(kind), head, body))
        return messages


def helper_exe():
    return Path(__file__).with_name('cyper_stream.exe' if sys.platform == 'win32' else 'cyper_stream')


def _popen(args):
    return subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0)


def list_stream_devices(timeout=20):
    proc = subprocess.run([str(helper_exe()), '--list'], capture_output=True, timeout=timeout,
                          creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0)
    for kind, head, _ in StreamParser().feed(proc.stdout):
        if kind == 'J' and head.get('type') == 'devices':
            return head['devices']
    raise RuntimeError('helper 未返回设备列表: ' + proc.stderr.decode('utf-8', 'replace')[-300:])


class StreamHelper:
    """Runs the helper; on_message(kind, head, body) is called on a reader thread."""

    def __init__(self, serial=None, on_message=None, popen=_popen):
        args = [str(helper_exe())] + (['--serial', serial] if serial else [])
        self.process = popen(args)
        self.on_message = on_message or (lambda kind, head, body: None)
        self.xu_replies = queue.Queue()
        self.send_lock, self.xu_lock = threading.Lock(), threading.Lock()
        self.stderr_tail = []
        self.reader = threading.Thread(target=self._read, daemon=True)
        self.reader.start()
        threading.Thread(target=self._drain_stderr, daemon=True).start()

    def _read(self):
        parser = StreamParser()
        try:
            while True:
                chunk = self.process.stdout.read1(1 << 16) if hasattr(self.process.stdout, 'read1') \
                    else self.process.stdout.read(1 << 16)
                if not chunk:
                    break
                for kind, head, body in parser.feed(chunk):
                    if kind == 'J' and head.get('type') == 'xu':
                        self.xu_replies.put(head)
                    else:
                        self.on_message(kind, head, body)
        except (ProtocolError, ValueError, OSError) as error:
            self.on_message('J', {'type': 'error', 'message': str(error)}, b'')
        finally:
            self.xu_replies.put(None)
            self.on_message('J', {'type': 'exited', 'stderr': ''.join(self.stderr_tail)[-500:]}, b'')

    def _drain_stderr(self):
        for line in iter(self.process.stderr.readline, b''):
            self.stderr_tail = (self.stderr_tail + [line.decode('utf-8', 'replace')])[-20:]

    def send(self, command):
        with self.send_lock:
            try:
                self.process.stdin.write((command + '\n').encode('utf-8'))
                self.process.stdin.flush()
            except (BrokenPipeError, OSError, ValueError):
                raise RuntimeError('图像服务已退出')

    def preview(self, fps, max_width):
        self.send(f'preview {fps:g} {int(max_width)}')

    def zoom(self, slot):
        """Send preview slot `slot` at full resolution (-1: none)."""
        self.send(f'zoom {int(slot)}')

    def snapshot(self, directory, fmt):
        self.send(f'snapshot {directory} {fmt}')

    def record(self, directory, rate_hz, fmt):
        self.send(f'record {directory} {rate_hz:g} {fmt}')

    def stop_record(self):
        self.send('stop_record')

    def xu(self, set_data=None, timeout=3.0):
        with self.xu_lock:
            self.send('xs ' + set_data.hex() if set_data is not None else 'xg')
            try:
                reply = self.xu_replies.get(timeout=timeout)
            except queue.Empty:
                raise TimeoutError('图像服务 XU 应答超时')
            if reply is None:
                raise RuntimeError('图像服务已退出')
            if not reply.get('ok'):
                raise RuntimeError('XU 命令失败: ' + reply.get('message', ''))
            return bytes.fromhex(reply['data']) if set_data is None else None

    def alive(self):
        return self.process.poll() is None

    def stop(self, timeout=5.0):
        try:
            self.send('quit')
        except RuntimeError:
            pass
        try:
            self.process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait()


class HelperTransport:
    """fpga_upgrade.Transport-compatible XU access through a running helper."""

    def __init__(self, helper):
        self.helper = helper

    def query(self, set_data=None, fast=False, selector=None):
        if fast or selector is not None:
            raise ValueError('图像服务仅转发 selector 5 普通命令')
        if set_data is not None and len(set_data) != 32:
            raise ValueError('Invalid USB packet length')
        return self.helper.xu(set_data)

    def close(self):
        pass
