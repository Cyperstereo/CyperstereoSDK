#!/usr/bin/env python3
"""Sync the vendored CyperstereoSDK (sdk/) with GitHub and rebuild cyper_stream.exe.

    python update_sdk.py            check, download changed files, rebuild, run tests
    python update_sdk.py --check    only report whether the remote has new commits
    python update_sdk.py --package  also rebuild Cyperstereo.exe (build_cyperstereo.ps1)

Only the parts the helper compiles are vendored (VENDORED below). Files are
fetched through the GitHub API, which is far faster here than git clone.
Set GITHUB_TOKEN to avoid the anonymous API rate limit.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path

REPO, BRANCH = 'Cyperstereo/CyperstereoSDK', 'develop'
ROOT = Path(__file__).resolve().parent
SDK = ROOT / 'sdk'
VENDORED = ('src/usb/uvc/', 'src/ISP/', 'cmake/', 'LICENSE', 'FIRMWARE_COMPATIBILITY.md')


def vendored(path):
    return any(path == v or (v.endswith('/') and path.startswith(v)) for v in VENDORED)


def api(path):
    request = urllib.request.Request(f'https://api.github.com/repos/{REPO}/{path}',
                                     headers={'Accept': 'application/vnd.github+json', 'User-Agent': 'cyperstereo'})
    if os.environ.get('GITHUB_TOKEN'):
        request.add_header('Authorization', 'Bearer ' + os.environ['GITHUB_TOKEN'])
    with urllib.request.urlopen(request, timeout=60) as response:
        return json.load(response)


def raw(commit, path):
    url = f'https://raw.githubusercontent.com/{REPO}/{commit}/{path}'
    with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'cyperstereo'}),
                                timeout=120) as response:
        return response.read()


def plan(files):
    """Changed vendored files -> (writes, deletes) of SDK-relative paths."""
    writes, deletes = [], []
    for f in files:
        if f['status'] == 'renamed' and vendored(f['previous_filename']):
            deletes.append(f['previous_filename'])
        if not vendored(f['filename']):
            continue
        (deletes if f['status'] == 'removed' else writes).append(f['filename'])
    return writes, deletes


def run(command, **kw):
    print('>', ' '.join(map(str, command)))
    subprocess.run(command, check=True, **kw)


def rebuild():
    build = ROOT / 'stream' / 'build'
    run(['cmake', '-S', ROOT / 'stream', '-B', build, '-G', 'Visual Studio 17 2022', '-A', 'x64'])
    run(['cmake', '--build', build, '--config', 'Release'])
    shutil.copy2(build / 'Release' / 'cyper_stream.exe', ROOT / 'cyper_stream.exe')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--package', action='store_true')
    parser.add_argument('--branch', default=BRANCH)
    args = parser.parse_args(argv)

    current = (SDK / 'SDK_COMMIT.txt').read_text().strip()
    head = api(f'commits/{args.branch}')['sha']
    print(f'本地 SDK {current[:8]}，远端 {args.branch} {head[:8]}')
    if head == current:
        print('SDK 已是最新。')
        return 0
    compare = api(f'compare/{current}...{head}')
    if compare.get('status') not in ('ahead', 'diverged'):
        print('远端分支不在本地版本之后（status=%s），未更新。' % compare.get('status'))
        return 1
    if len(compare['files']) >= 300:
        raise SystemExit('改动文件超过 GitHub compare 上限（300），请手动同步。')
    writes, deletes = plan(compare['files'])
    print(f"{compare['ahead_by']} 个新提交；需要更新 {len(writes)} 个文件，删除 {len(deletes)} 个文件")
    for c in compare['commits']:
        print('  ', c['sha'][:8], c['commit']['message'].splitlines()[0])
    if args.check:
        return 0

    backup = ROOT / 'sdk_backup' / current[:8]
    for path in writes + deletes:
        target = SDK / path
        if target.exists():
            (backup / path).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, backup / path)
    for path in writes:
        target = SDK / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw(head, path))
        print('  更新', path)
    for path in deletes:
        if (SDK / path).exists():
            (SDK / path).unlink()
            print('  删除', path)
    (SDK / 'SDK_COMMIT.txt').write_text(head + '\n')
    print(f'已同步到 {head[:8]}；旧文件备份在 {backup}')

    rebuild()
    run([sys.executable, '-m', 'unittest', 'test_camera_param', 'test_cyperstereo'], cwd=ROOT)
    if args.package:
        run(['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ROOT / 'build_cyperstereo.ps1'])
    return 0


if __name__ == '__main__':
    sys.exit(main())
