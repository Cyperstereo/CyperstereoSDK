"""Headless FPGA/FX3 updater; no Tk dependency. Linux launcher supplies kind."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import time
import uuid
import fpga_upgrade as fpga

def main(argv=None):
    parser=argparse.ArgumentParser(description='FPGA / FX3 updater (no backups; full readback verification)')
    parser.add_argument('--kind',choices=('fpga','fx3'),required=True)
    sub=parser.add_subparsers(dest='action',required=True)
    sub.add_parser('list',help='Enumerate matching devices; no flash access')
    inspect=sub.add_parser('inspect',help='Validate firmware file locally');inspect.add_argument('firmware')
    layout=sub.add_parser('serial-layout',help='FX3: bind serial symbol from matching linker map to IMG SHA256')
    layout.add_argument('firmware');layout.add_argument('--map',required=True,type=Path)
    for action in ('check','program','prepare'):
        p=sub.add_parser(action);p.add_argument('--device',required=True,help='/dev/videoN or /dev/v4l/by-id/...')
        p.add_argument('--log-dir',type=Path,default=Path.home()/'Documents'/'USB_Upgrade_Logs')
        if action in ('program','prepare'):
            p.add_argument('firmware')
            p.add_argument('--force-overwrite',action='store_true',help='FX3 only: use target IMG SN and allow slave/slave_double migration')
        if action=='program':
            p.add_argument('--accept-single-image-risk',action='store_true',required=True,
                           help='Explicitly allow flash erase/program without a backup')
    args=parser.parse_args(argv)
    if getattr(args,'force_overwrite',False) and args.kind!='fx3':parser.error('--force-overwrite is FX3-only')
    if args.action=='list':
        print(json.dumps([d for d in fpga.list_devices() if fpga.is_target_device(d)],ensure_ascii=False,indent=2));return 0
    backend=fpga
    if args.kind=='fx3':
        import fx3_upgrade
        backend=fx3_upgrade
    if args.action in ('serial-layout','prepare') and args.kind!='fx3':
        parser.error('serial-layout / prepare are FX3-only commands')
    if args.action=='serial-layout':
        from fx3_serial import layout_from_map
        raw,_=backend.inspect_image(args.firmware)
        target=Path(str(args.firmware)+'.serial.json')
        data=layout_from_map(raw,args.map)
        with target.open('x',encoding='utf-8') as f:
            json.dump(data,f,ensure_ascii=False,indent=2)
        print(str(target));return 0
    raw=metadata=None
    if args.action in ('inspect','program','prepare'):
        if args.kind=='fx3':raw,metadata=backend.inspect_image(args.firmware)
        else:
            raw=backend.bit_payload(args.firmware)
            metadata=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
        if args.action=='inspect':print(json.dumps(metadata,ensure_ascii=False,indent=2));return 0
    folder=args.log_dir/(datetime.datetime.now().strftime('%Y%m%d_%H%M%S_')+uuid.uuid4().hex[:8])
    folder.mkdir(parents=True,exist_ok=False)
    def save(name,data):(folder/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    def emit(text):
        print(text,flush=True)
        with (folder/'upgrade.log').open('a',encoding='utf-8') as f:f.write(text+'\n')
    dirty=False;transport=programmer=None;handlers={};last_progress=None;last_command=None
    def journal(record):
        nonlocal dirty,last_command
        last_command=record
        with (folder/'commands.jsonl').open('a',encoding='utf-8') as f:
            f.write(json.dumps(record,ensure_ascii=False)+'\n');f.flush()
            if record['event']=='start' and int(record['op'],16) in (3,4,0x24):
                os.fsync(f.fileno());dirty=True
    def protect_write():
        if handlers:return
        # Keep the fd and power intact on terminal Ctrl+C during a mutation.
        def ignored(signum,frame):
            print('Flash update in progress; wait for verification before exiting.',file=sys.stderr,flush=True)
        for s in (signal.SIGINT,signal.SIGTERM):handlers[s]=signal.signal(s,ignored)
    def progress(stage,n,total):
        nonlocal last_progress
        if stage in ('erase','program'):protect_write()
        current=(stage,int(n*100/total))
        if current!=last_progress:emit(f'{stage}: {n}/{total} ({current[1]}%)');last_progress=current
    save('request.json',dict(kind=args.kind,operation=args.action,device=args.device,image=metadata,
                             firmware=getattr(args,'firmware',None),platform=sys.platform,backup=False,
                             force_overwrite=getattr(args,'force_overwrite',False)))
    try:
        emit('Logs: '+str(folder))
        if args.kind=='fx3':
            from fx3_serial import read_device_serial, prepare_image
            identity=read_device_serial(args.device);save('device_serial.json',identity)
            emit('Original USB serial: '+identity['serial'])
            if args.action in ('program','prepare'):
                raw,metadata=prepare_image(args.firmware,identity,folder,force_overwrite=args.force_overwrite)
                emit('Force overwrite: '+str(args.force_overwrite)+'; original SN '+identity['serial']+' -> output SN '+metadata['serial_preservation']['serial'])
                emit('Prepared IMG: '+str(folder/metadata['output_filename']))
            if args.action=='prepare':
                emit('PREPARED: no upgrade interface required; no flash erase/program.');return 0
        transport=backend.Transport(args.device);programmer=backend.Programmer(transport);programmer.journal=journal
        info=programmer.begin()
        if args.kind=='fpga':
            info=dict(jedec=info.hex().upper(),mode=programmer.mode_detail)
        else:info['serial']=identity['serial']
        emit('Connection: '+json.dumps(info,ensure_ascii=False))
        if args.action=='check':
            if args.kind=='fpga':programmer.read(size=4096)
            save('check.json',info);emit('CHECK PASSED: no flash erase/program.');return 0
        if args.kind=='fx3':result=programmer.program(raw,metadata,progress,force_overwrite=args.force_overwrite)
        else:result=programmer.program(raw,progress)
        save('result.json',result);emit('VERIFIED: readback matches. Power-cycle to load the new firmware.');return 0
    except (Exception,KeyboardInterrupt) as e:
        save('failure.json',dict(error=str(e) or 'Interrupted',write_started=dirty,last_command=last_command,automatic_retry=False))
        emit('FAILED: '+(str(e) or 'Interrupted'))
        if dirty:emit('KEEP POWER ON. Flash may be incomplete. No write was retried; no backup was saved.')
        return 1
    finally:
        if programmer:
            try:
                if args.kind=='fx3':programmer.end()
                else:programmer.command(0x11)
            except Exception as e:emit('END session failed: '+str(e))
        try:
            if transport:transport.close()
        finally:
            for s,previous in handlers.items():signal.signal(s,previous)

if __name__=='__main__':
    try:sys.exit(main())
    except (Exception,KeyboardInterrupt) as e:
        print('ERROR: '+(str(e) or 'Interrupted'),file=sys.stderr);sys.exit(1)
