"""Read USB identity independently of XU and personalize a hash-bound FX3 IMG.

Layouts come from the matching linker map, never a guessed string/offset.
Only the allocated serial descriptor and boot checksum may change.
"""
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
from urllib.parse import quote


def validate_serial(value):
    if not isinstance(value, str) or not value or not value.isprintable() or value.strip() != value:
        raise ValueError('设备未提供有效 USB 序列号；禁止使用设备编号/路径代替。')
    encoded = value.encode('utf-16le', errors='strict')
    if len(encoded) > 252:
        raise ValueError('USB 序列号过长。')
    return encoded


def read_device_serial(address):
    if sys.platform == 'linux':
        from linux_uvc import snapshot, IDENTITY_KEYS
        expected = json.loads(address[6:]) if address.startswith('linux:') else None
        current = snapshot(expected['node'] if expected else address)
        if expected and any(current[k] != expected[k] for k in IDENTITY_KEYS):
            raise RuntimeError('所选设备已变化，请刷新列表。')
        # sysfs serial is populated from the USB string descriptor, not the node name.
        serial = (Path(current['usb_path'])/'serial').read_text(encoding='utf-8')
        if serial.endswith('\n'): serial = serial[:-1]
        result = dict(serial=serial, source='Linux USB sysfs serial descriptor', address=address)
    elif sys.platform == 'win32':
        from fpga_upgrade import helper_path
        if not address.startswith('winlink:'):
            raise ValueError('读取序列号必须使用所选设备的完整 USB 路径。')
        proc = subprocess.run([str(helper_path()), '--serial-link', address[8:]],
                              capture_output=True, text=True, encoding='utf-8', timeout=20,
                              creationflags=subprocess.CREATE_NO_WINDOW)
        if proc.returncode:
            raise RuntimeError('读取 USB 原序列号失败（未擦写）：'+(proc.stdout.strip() or proc.stderr.strip()))
        result = json.loads(proc.stdout)
        result.update(address=address, source='Windows USB hub GET_DESCRIPTOR')
    else:
        raise RuntimeError('仅支持 Windows / Linux。')
    validate_serial(result['serial'])
    return result


def sections(raw):
    pos = 4
    while True:
        words, address = struct.unpack_from('<II', raw, pos)
        pos += 8
        if not words:
            return
        yield pos, address, words*4
        pos += words*4


def descriptor(raw, layout):
    if layout.get('format') != 'fx3-usb-serial-layout-v1' or layout.get('image_sha256') != hashlib.sha256(raw).hexdigest():
        raise ValueError('序列号布局与 IMG 的 SHA256 不匹配；请使用同次编译的 .map 重新生成布局。')
    offset, capacity = layout.get('offset'), layout.get('capacity')
    if type(offset) is not int or type(capacity) is not int or not 4 <= capacity <= 254 or capacity % 2:
        raise ValueError('序列号布局的偏移/容量无效。')
    matches = [(p,a) for p,a,n in sections(raw) if p <= offset and offset+capacity <= p+n]
    if len(matches) != 1 or layout.get('address') != matches[0][1]+offset-matches[0][0]:
        raise ValueError('序列号描述符不在声明的 IMG 数据段内。')
    length = raw[offset]
    if raw[offset+1] != 3 or not 4 <= length <= capacity or length % 2:
        raise ValueError('定位到的数据不是有效 USB 字符串描述符。')
    serial = raw[offset+2:offset+length].decode('utf-16le', errors='strict')
    validate_serial(serial)
    return offset, capacity, serial


def layout_from_map(raw, map_path):
    from fx3_upgrade import inspect_bytes
    inspect_bytes(raw)
    text = Path(map_path).read_text(encoding='utf-8', errors='replace')
    blocks = re.findall(r'\.rodata\.CyFxUSBSerialNumberDscr\s+0x([0-9a-fA-F]+)\s+0x([0-9a-fA-F]+)', text)
    symbols = re.findall(r'^\s*0x([0-9a-fA-F]+)\s+CyFxUSBSerialNumberDscr\s*$', text, re.M)
    if len(blocks) != 1 or len(symbols) != 1 or int(blocks[0][0],16) != int(symbols[0],16):
        raise ValueError('MAP 中必须有唯一 CyFxUSBSerialNumberDscr 符号及其独立 .rodata 节大小。')
    address, capacity = (int(v,16) for v in blocks[0])
    offsets = [p+address-a for p,a,n in sections(raw) if a <= address and address+capacity <= a+n]
    if len(offsets) != 1:
        raise ValueError('MAP 中序列号地址无法映射到 IMG；请核对编译产物。')
    layout = dict(format='fx3-usb-serial-layout-v1', image_sha256=hashlib.sha256(raw).hexdigest(),
                  offset=offsets[0], capacity=capacity, address=address, symbol='CyFxUSBSerialNumberDscr')
    descriptor(raw, layout)
    return layout


def load_layout(path, raw):
    path = Path(path)
    sidecar = Path(str(path)+'.serial.json')
    if sidecar.exists():
        layout = json.loads(sidecar.read_text(encoding='utf-8'))
    elif path.with_suffix('.map').exists():
        layout = layout_from_map(raw, path.with_suffix('.map'))
    else:
        raise ValueError('缺少固件序列号布局：请把同次编译的同名 .map 或 .img.serial.json 放在 IMG 旁；不猜测偏移，未擦写。')
    descriptor(raw, layout)
    return layout


def personalize(raw, layout, serial):
    from fx3_upgrade import inspect_bytes
    inspect_bytes(raw)
    offset, capacity, previous = descriptor(raw, layout)
    encoded = validate_serial(serial)
    if len(encoded)+2 > capacity:
        raise ValueError(f'原序列号需要 {len(encoded)+2} 字节，新固件描述符仅 {capacity} 字节；需扩大固件数组并重新编译，未擦写。')
    patched = bytearray(raw)
    patched[offset:offset+capacity] = (bytes((len(encoded)+2,3))+encoded).ljust(capacity,b'\0')
    checksum = sum(sum(struct.unpack_from('<%dI'%(n//4),patched,p)) for p,_,n in sections(raw)) & 0xffffffff
    struct.pack_into('<I',patched,len(patched)-4,checksum)
    patched = bytes(patched)
    meta = inspect_bytes(patched)
    updated = dict(layout, image_sha256=meta['sha256'])
    assert descriptor(patched,updated)[2] == serial
    meta['serial_preservation'] = dict(serial=serial, template_serial=previous,
        original_sha256=hashlib.sha256(raw).hexdigest(), layout=updated)
    return patched, meta


def image_filename(serial):
    validate_serial(serial)
    # Escape path separators and Windows-forbidden characters without changing
    # the actual USB serial written into the image.
    token = quote(serial, safe='-_')
    if len(token) > 160:
        token = token[:140]+'_'+hashlib.sha256(serial.encode('utf-8')).hexdigest()[:16]
    return 'serial_preserved_'+token+'.img'


# Cyperstereo serials start with the sensor family: S = SC136HGS, A = AR0234.
# The FX3 variant tag (slave / slave_double) does not tell the two apart.
SENSOR_FAMILIES = {'S': 'SC136HGS', 'A': 'AR0234'}


def check_sensor_family(template_serial, device_serial):
    image = SENSOR_FAMILIES.get(template_serial[:1].upper())
    device = SENSOR_FAMILIES.get(device_serial[:1].upper())
    if image and device and image != device:
        raise ValueError(f'固件是 {image} 版本（模板 SN {template_serial}），设备是 {device}（SN {device_serial}）；'
                         '传感器不匹配，未擦写。确需更换请使用强制覆盖。')


def prepare_image(path, identity, directory, layout=None, force_overwrite=False):
    from fx3_upgrade import inspect_image
    raw, metadata = inspect_image(path)
    layout = layout if layout is not None else load_layout(path,raw)
    validate_serial(identity['serial'])
    if force_overwrite:
        target_serial=descriptor(raw,layout)[2]
        # Forced mode writes the selected IMG byte-for-byte, including its SN.
        patched=raw
        metadata['serial_preservation']=dict(mode='overwrite',serial=target_serial,
            device_serial=identity['serial'],template_serial=target_serial,
            original_sha256=metadata['sha256'],layout=layout)
    else:
        check_sensor_family(descriptor(raw,layout)[2], identity['serial'])
        patched, metadata = personalize(raw,layout,identity['serial'])
    directory = Path(directory)
    filename=image_filename(metadata['serial_preservation']['serial'])
    if force_overwrite:filename=filename.replace('serial_preserved_','serial_overwrite_',1)
    output = directory/filename
    metadata['output_filename'] = output.name
    with output.open('xb') as f:
        f.write(patched); f.flush()
        import os
        os.fsync(f.fileno())
    if output.read_bytes() != patched:
        raise IOError('专用镜像落盘校验失败，未擦写。')
    Path(str(output)+'.serial.json').write_text(json.dumps(metadata['serial_preservation']['layout'],indent=2),encoding='utf-8')
    (directory/'serial_preservation.json').write_text(json.dumps(dict(identity=identity,image=metadata,
        output=str(output),reboot_serial_verified=False),ensure_ascii=False,indent=2),encoding='utf-8')
    return patched, metadata


def verify_prepared(raw, metadata, serial, force_overwrite=False):
    from fx3_upgrade import inspect_bytes
    actual = inspect_bytes(raw)
    if actual['sha256'] != metadata.get('sha256') or actual['variant'] != metadata.get('variant'):
        raise ValueError('待写入镜像校验/型号与元数据不一致。')
    record = metadata.get('serial_preservation',{})
    if force_overwrite:
        if record.get('mode')!='overwrite' or record.get('device_serial')!=serial:
            raise ValueError('强制覆盖记录缺失或所选设备序列号发生变化；未擦写。')
        if record.get('original_sha256')!=actual['sha256'] or record.get('serial')!=record.get('template_serial'):
            raise ValueError('强制覆盖镜像与选中的目标 IMG 不一致；未擦写。')
    elif record.get('mode','preserve')!='preserve' or record.get('serial') != serial:
        raise ValueError('缺少序列号保留记录，或当前设备序列号发生变化；未擦写。')
    if descriptor(raw,record.get('layout',{}))[2] != record.get('serial'):
        raise ValueError('待写入镜像与预期序列号不一致；未擦写。')
