"""FPGA and FX3 upgrade workers shared by Cyperstereo View and its CLI.

Taken from the FPGA_Upgrade_V3 / FX3_Upgrade_V1.3 Tk tools without Tk. A worker
owns the device for its whole run and reports through events.put((kind, value)):
  log, folder, locked (FPGA: erase started), writing (FX3: erase started),
  progress (stage, done, total), device_serial, error, prepared, finished.
Old firmware is never backed up and failed writes are never retried.
"""
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import sys
import threading
import time
import uuid

import fpga_upgrade as fpga
import fx3_upgrade as fx3
from fx3_serial import read_device_serial, prepare_image

FPGA_STAGES = {'program': ('擦除 / 写入', 0), 'verify': ('整区读回校验', 1)}
FX3_STAGES = {'erase': '擦除 U5', 'program': '写入固件主体', 'body_verify': '校验固件主体', 'verify': '最终完整校验'}


class Cancelled(Exception):
    pass


class OperationControl:
    """Atomic boundary: a stop accepted before erase guarantees no flash writes."""

    def __init__(self):
        self.lock = threading.Lock()
        self.cancelled = self.writing = False

    def clear(self):
        with self.lock:
            self.cancelled = self.writing = False

    def is_set(self):
        with self.lock:
            return self.cancelled

    def set(self):
        with self.lock:
            if self.writing:
                return False
            self.cancelled = True
            return True

    def begin_write(self):
        with self.lock:
            if self.cancelled:
                raise Cancelled('已停止，未执行擦写。')
            self.writing = True


def explain(error):
    text = str(error)
    if '80070005' in text.lower():
        return '设备访问被拒绝。请关闭采集软件，并检查 Windows 设置 → 隐私 → 相机 → 允许桌面应用访问相机。\n' + text
    if 'selector 5 not found' in text or 'XU_PROBE_FAILED' in text:
        return ('Windows 未能访问升级控制项。可能是旧 FX3 固件，也可能是前一版固件缺少 UVC 查询导致 Windows 禁用了接口。'
                '请安装 XU 修复版 FX3 固件并重新枚举；此时尚未访问 FPGA Flash。\n' + text)
    if 'status 0x81' in text:
        return '设备仍在输出视频。请关闭全部视频采集程序后重试。\n' + text
    if 'status 0x83' in text or 'status 0x84' in text:
        if 'command 0x22' in text:
            return '批量读取失败。是否已擦写须看本次阶段记录；若已进入擦写，请保持供电。\n' + text
        return '传输失败。若已进入擦写，请保持供电，不要立即重启。\n' + text
    if '8007001f' in text.lower():
        return ('USB 控制请求失败，不能据此确认该命令是否执行。未自动重试。保持供电，关闭软件后重新打开，只做连接检查；'
                '检查通过也不代表 Flash 镜像完整。\n' + text)
    if 'status 0x8a' in text:
        return 'FX3 无法禁止 USB 低功耗，本次未允许进入升级操作。\n' + text
    return text


def run_dir(base):
    path = Path(base) / (datetime.datetime.now().strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:8])
    path.mkdir(parents=True, exist_ok=False)
    return path


def keep_awake(flags):
    """Windows: per-thread 'system required'; returns False if refused. Elsewhere a no-op."""
    if sys.platform != 'win32':
        return True
    return bool(ctypes.windll.kernel32.SetThreadExecutionState(flags))


def release_awake():
    if sys.platform == 'win32':
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)


def fpga_job(device, image, directory, events, cancel, transport_factory=fpga.Transport):
    """Probe (image=None) or program an FPGA .bit."""
    transport = programmer = log = journal = folder = last_stage = stage_started = last_sector = None
    destructive = awake = False
    outcome = 'failed'

    def emit(kind, value):
        events.put((kind, value))
        if kind == 'log' and log:
            log.write(datetime.datetime.now().strftime('%H:%M:%S  ') + value + '\n')
            log.flush()

    try:
        folder = run_dir(directory)
        log = (folder / 'upgrade.log').open('w', encoding='utf-8')
        journal = (folder / 'commands.jsonl').open('w', encoding='utf-8')

        def audit(record):
            record['time'] = datetime.datetime.now().isoformat(timespec='milliseconds')
            journal.write(json.dumps(record, ensure_ascii=False) + '\n')
            journal.flush()
            if record['event'] == 'start' and record['op'] == '0x03':
                os.fsync(journal.fileno())

        emit('folder', str(folder))
        emit('log', f"FPGA 升级 · 设备 SN {(device.get('serial') or '未知').upper()} · {device.get('name', '')}")
        emit('log', 'USB 路径：' + device.get('link', fpga.device_address(device)))
        emit('log', '日志目录：' + str(folder))
        payload = fpga.bit_payload(image) if image else None
        metadata = {'application_version': fpga.APP_VERSION, 'device': device,
                    'image': str(image) if image else None, 'operation': 'program' if image else 'probe'}
        emit('log', '不备份旧固件；擦写后执行完整读回校验。')
        if payload is not None:
            metadata.update(payload_bytes=len(payload), payload_sha256=hashlib.sha256(payload).hexdigest())
            emit('log', '目标固件：' + str(image))
            emit('log', '配置数据 SHA256：' + metadata['payload_sha256'])
        (folder / 'request.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
        if cancel.is_set():
            raise Cancelled('已停止，未执行擦写。')
        awake = keep_awake(0x80000001)
        if not awake:
            raise RuntimeError('无法请求系统在升级期间保持唤醒；未打开设备。')
        emit('log', '正在打开选中的设备并检查 FPGA 升级通路……')
        transport = transport_factory(fpga.device_address(device))
        programmer = fpga.Programmer(transport)
        programmer.journal = audit
        ident = programmer.begin()
        emit('log', '升级通路正常。')
        emit('log', '传输模式：' + programmer.mode_detail)
        if payload is not None:
            emit('log', '写入策略：批量模式；失败不自动重试。' if programmer.fast
                 else '写入策略：兼容模式；失败不自动重试。')
        if cancel.is_set():
            raise Cancelled('已停止，未执行擦写。')
        if payload is None:
            started = time.monotonic()
            sample = programmer.read(size=4096)
            elapsed = max(time.monotonic() - started, 0.000001)
            probe = {'protocol': 2 if programmer.fast else 1, 'i2c_hz': programmer.i2c_hz,
                     'sample_bytes': len(sample), 'sample_seconds': round(elapsed, 4),
                     'read_kib_per_second': round(len(sample) / 1024 / elapsed, 2)}
            (folder / 'probe.json').write_text(json.dumps(probe, indent=2), encoding='utf-8')
            emit('log', f"4 KiB 只读测速：{probe['read_kib_per_second']:.2f} KiB/s")
            emit('log', '连接检查通过；未擦除或写入 Flash。')
            outcome = 'probe_ok'
        else:
            def progress(stage, current, total):
                nonlocal destructive, last_stage, stage_started, last_sector
                if not destructive and cancel.is_set():
                    raise Cancelled('已停止，未执行擦写。')
                if stage == 'program' and not destructive:
                    cancel.begin_write()
                    destructive = True
                    emit('locked', True)
                if stage != last_stage:
                    if stage_started is not None:
                        emit('log', f'阶段耗时：{time.monotonic() - stage_started:.1f} 秒')
                    stage_started, last_stage = time.monotonic(), stage
                    emit('log', '阶段：' + FPGA_STAGES[stage][0])
                if stage == 'program':
                    sector = programmer.flash_context.get('sector')
                    if sector != last_sector and sector and int(sector, 16) % 0x10000 == 0:
                        emit('log', '处理扇区：' + str(sector))
                    last_sector = sector
                events.put(('progress', (stage, current, total)))

            result = programmer.program(payload, progress)
            result.update(metadata)
            (folder / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
            emit('log', f"本次耗时：{result['elapsed_seconds']:.1f} 秒；擦除 {result['erased_sectors']} 个扇区，"
                        f"编程 {result['program_commands']} 次")
            emit('log', 'VERIFIED：全部读回一致。请断电重启加载新 FPGA 固件。')
            outcome = 'verified'
    except Cancelled as error:
        emit('log', str(error))
        outcome = 'cancelled'
    except Exception as error:
        message = explain(error)
        context = getattr(error, 'command_context', None)
        if context:
            message += (f"\n失败位置：命令 {context['op']}，地址 {context['address']}，长度 {context['count']}，"
                        f"阶段 {context['phase']}。")
            if context.get('flash'):
                message += '\n擦写上下文：' + json.dumps(context['flash'], ensure_ascii=False)
        if folder:
            try:
                (folder / 'failure.json').write_text(json.dumps({
                    'error': str(error), 'destructive_started': destructive, 'command': context,
                    'last_command': programmer.last_command if programmer else None,
                    'flash': programmer.flash_context if programmer else {}, 'automatic_retry': False},
                    ensure_ascii=False, indent=2), encoding='utf-8')
            except OSError:
                pass
        if destructive:
            message += '\n已进入擦写阶段。请保持供电并保留日志，不要立即断电；排除故障后重新升级或通过 JTAG 恢复。'
        emit('log', '失败：' + message)
        events.put(('error', message))
    finally:
        if programmer:
            try:
                programmer.command(0x11)
            except Exception as error:
                emit('log', '结束会话失败，重新连接后再检查：' + str(error))
        if transport:
            try:
                transport.close()
            except Exception as error:
                emit('log', '关闭连接：' + str(error))
        if awake:
            release_awake()
        if journal:
            journal.close()
        if log:
            log.close()
        events.put(('finished', outcome))


def fx3_job(device, path, directory, events, cancel, transport_factory=fx3.Transport, serial_reader=None,
            prepare_only=False, serial_layout=None, force_overwrite=False):
    """Check (path=None), export (prepare_only) or program an FX3 .img."""
    p = t = folder = None
    verified = dirty = awake = False
    outcome = 'failed'

    def save(name, value):
        (folder / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

    def emit(text):
        line = datetime.datetime.now().strftime('%H:%M:%S  ') + text
        if folder:
            with (folder / 'upgrade.log').open('a', encoding='utf-8') as f:
                f.write(line + '\n')
        events.put(('log', text))

    def progress(stage, done, total):
        nonlocal dirty
        if not dirty:
            cancel.begin_write()
            dirty = True
            events.put(('writing', None))
        events.put(('progress', (stage, done, total)))

    try:
        folder = run_dir(directory)
        events.put(('folder', str(folder)))
        awake = keep_awake(0x80000003)
        if not awake:
            raise RuntimeError('无法阻止系统休眠，未开始升级。')
        raw = meta = None
        if path:
            raw, meta = fx3.inspect_image(path)
        save('request.json', dict(device=device, image_path=path, image=meta, app_version=fx3.VERSION,
                                  force_overwrite=bool(force_overwrite)))
        emit(f"FX3 升级 · 设备 SN {(device.get('serial') or '未知').upper()} · {device.get('name', '')}")
        emit('USB 路径：' + device.get('link', fx3.device_address(device)))
        emit('日志目录：' + str(folder))
        if meta:
            emit('目标固件：' + meta['variant_name'] + '，SHA256 ' + meta['sha256'])
        if cancel.is_set():
            raise Cancelled('已取消，未擦写。')
        identity = (serial_reader or read_device_serial)(fx3.device_address(device))
        if device.get('serial') and device['serial'].upper() != identity['serial'].upper():
            raise RuntimeError('当前设备序列号与列表中选中的设备不同，请刷新后重新选择；未擦写。')
        events.put(('device_serial', identity['serial']))
        save('device_serial.json', identity)
        emit('设备原 USB 序列号：' + identity['serial'])
        if path:
            raw, meta = prepare_image(path, identity, folder, serial_layout, force_overwrite)
            if force_overwrite:
                emit('强制覆盖已开启：原 SN ' + identity['serial'] + ' → 目标 SN '
                     + meta['serial_preservation']['serial'] + '；允许跨型号烧录。')
            else:
                emit('普通升级：保留原 SN，执行型号与传感器匹配检查。')
            emit(('已校验使用目标 SN 的覆盖镜像：' if force_overwrite else '已生成并校验保留原序列号的镜像：')
                 + str(folder / meta['output_filename']))
            emit('专用镜像 SHA256：' + meta['sha256'])
        if prepare_only:
            emit('导出完成：未检查升级接口、未擦写 Flash。预期写入的 SN：' + meta['serial_preservation']['serial'])
            events.put(('prepared', str(folder)))
            outcome = 'prepared'
            return

        def journal(record):
            with (folder / 'commands.jsonl').open('a', encoding='utf-8') as f:
                f.write(json.dumps(record, ensure_ascii=False) + '\n')
                if record['event'] == 'start' and record['op'] in ('0x3', '0x24'):
                    f.flush()
                    os.fsync(f.fileno())

        t = transport_factory(fx3.device_address(device))
        p = fx3.Programmer(t, journal)
        info = p.begin()
        info['serial'] = identity['serial']
        emit(f"FX3 升级通路通过，型号 {info['variant_name']}。")
        if cancel.is_set():
            raise Cancelled('已取消，未擦写。')
        if path:
            if force_overwrite:
                emit('型号：设备 ' + info['variant_name'] + ' → 目标 ' + meta['variant_name'])
            result = p.program(raw, meta, progress, force_overwrite=force_overwrite)
            save('result.json', result)
            verified = True
            emit(f"VERIFIED：{result['written_region']} 字节完整读回一致，耗时 {result['elapsed_seconds']} 秒。")
            emit('请断电重启后刷新设备，核对序列号为 ' + meta['serial_preservation']['serial'] + '。')
            outcome = 'verified'
        else:
            save('check.json', info)
            emit('连接检查通过；未擦除、未写入，不访问 FPGA。')
            outcome = 'probe_ok'
    except Cancelled as e:
        emit(str(e))
        outcome = 'cancelled'
    except Exception as e:
        is_dirty = bool(p and p.dirty)
        if folder:
            try:
                save('failure.json', dict(error=str(e), write_started=is_dirty,
                                          last_command=getattr(p, 'last_command', None), verified=verified))
            except OSError:
                pass
        message = str(e)
        if not is_dirty and ('XU_PROBE_FAILED' in message or 'selector 7' in message):
            message += '\n当前设备没有可用的 FX3 升级接口。旧固件需要先安装一次配套版本。'
        if is_dirty:
            message += '\n已发出擦写命令：请保持供电，不要立即重启。不自动重试；重新检查后再执行升级。'
        emit('失败：' + message)
        events.put(('error', message))
    finally:
        if p:
            try:
                p.end()
            except Exception as e:
                emit('结束会话失败：' + str(e) + '；保持供电后重新检查连接。')
        if t:
            t.close()
        if awake:
            release_awake()
        events.put(('finished', outcome))
