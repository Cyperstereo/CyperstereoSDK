#!/usr/bin/env python3
"""Cyperstereo View: camera viewer and recorder, max exposure / gain, FPGA and FX3 upgrades.

Without arguments this opens the GUI; `cyperstereo-view --help` lists the
command-line mode (see cyperstereo_cli.py).
"""
import datetime
import math
import os
import queue
import sys
import threading
import time
from collections import deque
from pathlib import Path

import cyperstereo_cli

if __name__ == '__main__' and sys.argv[1:2] and sys.argv[1] in cyperstereo_cli.COMMANDS:
    sys.exit(cyperstereo_cli.run())

from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt, Signal

import camera_param as core
import cyper_stream_client as csc
import fpga_upgrade as backend
import fx3_upgrade
import upgrade_jobs as jobs
from fx3_serial import read_device_serial, load_layout, layout_from_map, descriptor

APP_NAME, APP_VERSION = cyperstereo_cli.APP_NAME, cyperstereo_cli.APP_VERSION
SAVE_RATES = (0.5, 1, 2, 5, 10, 15, 30)
PREVIEW_FPS = 15
SAVE_HINT = '「保存图像」保存当前一组；「连续保存」按所选频率保存图像和 IMU 数据'
IMU_WINDOW_S = 5.0

ACCENT, GREEN, ORANGE, RED, MUTED = '#0071e3', '#248a3d', '#c93400', '#d70015', '#86868b'
STYLE = f"""
* {{ font-family: "Segoe UI", "Microsoft YaHei UI", "PingFang SC", "Noto Sans CJK SC", "Source Han Sans SC",
    "WenQuanYi Micro Hei", "Ubuntu", "Cantarell", sans-serif; font-size: 13px; color: #1d1d1f; }}
QMainWindow, QWidget#root {{ background: #f5f5f7; }}
QFrame#card {{ background: #ffffff; border-radius: 14px; }}
QLabel#title {{ font-size: 22px; font-weight: 600; }}
QLabel#cardTitle {{ font-size: 15px; font-weight: 600; }}
QLabel#muted {{ color: {MUTED}; font-size: 12px; }}
QLabel#value {{ font-family: "Segoe UI", "Consolas"; font-size: 13px; }}
QLabel#big {{ font-size: 18px; font-weight: 600; }}
QPushButton {{ background: #e8e8ed; border: none; border-radius: 8px; padding: 6px 14px; min-height: 20px; }}
QPushButton:hover {{ background: #dedee3; }}
QPushButton:pressed {{ background: #d2d2d7; }}
QPushButton:disabled {{ color: #aeaeb2; background: #f0f0f3; }}
QPushButton#primary {{ background: {ACCENT}; color: #ffffff; font-weight: 600; }}
QPushButton#primary:hover {{ background: #0077ed; }}
QPushButton#primary:disabled {{ background: #9cc3f0; color: #ffffff; }}
QPushButton#stop {{ background: #ff3b30; color: #ffffff; font-weight: 600; }}
QPushButton#stop:disabled {{ background: #f0f0f3; color: #aeaeb2; }}
QPushButton#segment {{ background: transparent; border-radius: 6px; padding: 4px 12px; }}
QPushButton#segment:checked {{ background: #ffffff; font-weight: 600; }}
QFrame#segments {{ background: #e8e8ed; border-radius: 8px; }}
QComboBox, QDoubleSpinBox, QLineEdit {{ background: #ffffff; border: 1px solid #d2d2d7; border-radius: 8px;
    padding: 4px 8px; min-height: 20px; selection-background-color: {ACCENT}; }}
QComboBox:focus, QDoubleSpinBox:focus, QLineEdit:focus {{ border: 1px solid {ACCENT}; }}
QComboBox {{ padding-right: 24px; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox::down-arrow {{ image: url(__CHEVRON__); width: 10px; height: 6px; }}
QComboBox QAbstractItemView {{ background: #ffffff; border: 1px solid #d2d2d7; selection-background-color: #e8f1fc;
    selection-color: #1d1d1f; outline: none; }}
QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; border: none; }}
QScrollBar:vertical {{ width: 8px; background: transparent; }}
QScrollBar::handle:vertical {{ background: #c7c7cc; border-radius: 4px; min-height: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QToolTip {{ background: #ffffff; border: 1px solid #d2d2d7; padding: 4px; }}
QProgressBar {{ background: #e8e8ed; border: none; border-radius: 4px; max-height: 8px; min-height: 8px; }}
QProgressBar::chunk {{ background: {ACCENT}; border-radius: 4px; }}
QPlainTextEdit#log {{ background: #f5f5f7; border: none; border-radius: 10px; padding: 8px;
    font-family: "Consolas", "Menlo", "DejaVu Sans Mono", "Microsoft YaHei UI", monospace; font-size: 12px; }}
QPushButton#tool {{ background: #2c2c2e; color: #ffffff; border-radius: 7px; padding: 4px 10px; }}
QPushButton#tool:hover {{ background: #3a3a3c; }}
QPushButton#tool:checked {{ background: {ACCENT}; }}
QFrame#note {{ background: #fff4e5; border-radius: 10px; }}
"""


def asset(name):
    base = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
    return str(base / 'assets' / name)


STYLE = STYLE.replace('__CHEVRON__', asset('chevron.png').replace('\\', '/'))


# ---------------------------------------------------------------- pure logic
def grid_shape(count):
    """(rows, columns) for the image grid: 4 -> 2x2, 6 -> 2x3."""
    if count <= 1:
        return 1, 1
    if count == 2:
        return 1, 2
    if count <= 4:
        return 2, 2
    return math.ceil(count / 3), 3


def tile_caption(telemetry):
    parts = []
    if telemetry.get('exposure_ms') is not None:
        parts.append(f"曝光 {telemetry['exposure_ms']:.3f} ms")
    if telemetry.get('gain') is not None:
        parts.append(f"增益 {telemetry['gain']:.2f}x")
    if telemetry.get('temperature') is not None:
        parts.append(f"{telemetry['temperature']:.1f} °C")
    return '  ·  '.join(parts)


def sensor_title(profile):
    """SDK profile name -> sensor name, e.g. 'SmartSens(SC136HGS-stereo/S2)' -> 'SC136HGS'."""
    for sensor in ('SC136HGS', 'AR0234', 'MT9V034'):
        if sensor in profile:
            return sensor
    return profile.split('(')[0].strip()


def preview_width_for(tile_width, ratio=1.0):
    """Preview JPEG width matched to the on-screen tile, in 64 px steps."""
    return int(max(320, min(1280, math.ceil(tile_width * ratio / 64) * 64)))


def rate_label(rate):
    return f'{rate:g} Hz（每 {1 / rate:g} 秒 1 组）' if rate < 1 else f'{rate:g} Hz'


def session_dir(base, prefix, now=None):
    return str(Path(base) / f"{prefix}_{(now or datetime.datetime.now()).strftime('%Y%m%d_%H%M%S')}")


SENSOR_BY_SN = {'S': 'SC136HGS', 'A': 'AR0234'}


def camera_choice_label(entry):
    """One line for the camera picker: serial plus the model implied by its prefix."""
    serial = (entry.get('serial') or '').upper()
    family = SENSOR_BY_SN.get(serial[:1], '')
    if serial and family:
        return f'{serial} · {family}'
    if serial:
        return serial
    name = entry.get('name') or ''
    return f'未读取到 SN · {name}' if name else '未读取到 SN'


def match_serials(entries, stream_serials):
    """Fill missing SNs when the hub-descriptor read failed but the SDK sees exactly one camera."""
    missing = [e for e in entries if not e['serial']]
    known = {e['serial'].upper() for e in entries if e['serial']}
    spare = [s for s in stream_serials if s.upper() not in known]
    if len(missing) == 1 and len(spare) == 1:
        missing[0]['serial'] = spare[0]
    return entries


def scan_devices():
    entries = []
    for device in core.target_devices():
        address = backend.device_address(device)
        try:
            serial, error = read_device_serial(address)['serial'], ''
        except Exception as exc:  # SN read is per-device; keep listing others.
            serial, error = '', str(exc)
        entries.append(dict(serial=serial, address=address, error=error, name=device.get('name', ''),
                            link=device.get('link', address)))
    if any(not e['serial'] for e in entries):
        try:
            match_serials(entries, [d['serial'] for d in csc.list_stream_devices()])
        except Exception:
            pass
    return entries


class ImuBuffer:
    """Last IMU_WINDOW_S seconds of samples [t, ax, ay, az, gx, gy, gz, temp]."""

    def __init__(self, window=IMU_WINDOW_S):
        self.window, self.samples, self.lock = window, deque(), threading.Lock()

    def extend(self, samples):
        with self.lock:
            self.samples.extend(samples)
            if self.samples:
                newest = self.samples[-1][0]
                while self.samples and (self.samples[0][0] < newest - self.window or self.samples[0][0] > newest):
                    self.samples.popleft()

    def snapshot(self):
        with self.lock:
            return list(self.samples)

    def clear(self):
        with self.lock:
            self.samples.clear()


# ---------------------------------------------------------------- widgets
def card(title=None):
    frame = QtWidgets.QFrame(objectName='card')
    shadow = QtWidgets.QGraphicsDropShadowEffect(frame, blurRadius=24, offset=QtCore.QPointF(0, 2))
    shadow.setColor(QtGui.QColor(0, 0, 0, 22))
    frame.setGraphicsEffect(shadow)
    layout = QtWidgets.QVBoxLayout(frame)
    layout.setContentsMargins(18, 16, 18, 16)
    layout.setSpacing(10)
    if title:
        layout.addWidget(QtWidgets.QLabel(title, objectName='cardTitle'))
    return frame, layout


def muted(text=''):
    label = QtWidgets.QLabel(text, objectName='muted')
    label.setWordWrap(True)
    return label


class Segmented(QtWidgets.QFrame):
    changed = Signal(str)

    def __init__(self, options, current):
        super().__init__(objectName='segments')
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(2)
        self.group = QtWidgets.QButtonGroup(self, exclusive=True)
        self.buttons = {}
        for key, text in options:
            button = QtWidgets.QPushButton(text, objectName='segment', checkable=True)
            button.setCursor(Qt.PointingHandCursor)
            button.clicked.connect(lambda _=False, k=key: self.changed.emit(k))
            self.group.addButton(button)
            layout.addWidget(button)
            self.buttons[key] = button
        self.set_value(current)

    def value(self):
        return next(k for k, b in self.buttons.items() if b.isChecked())

    def set_value(self, key):
        self.buttons.get(key, next(iter(self.buttons.values()))).setChecked(True)


class TileView(QtWidgets.QWidget):
    activated = Signal()

    def __init__(self):
        super().__init__()
        self.image, self.name, self.caption = None, '', ''
        self.setMinimumSize(200, 140)
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.setToolTip('双击放大查看')

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.activated.emit()

    def set_frame(self, image, name):
        self.image, self.name = image, name
        self.update()

    def set_caption(self, caption):
        if caption != self.caption:
            self.caption = caption
            self.update()

    def clear(self):
        self.image, self.caption = None, ''
        self.update()

    def paintEvent(self, _):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        p.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
        rect = QtCore.QRectF(self.rect()).adjusted(1, 1, -1, -1)
        clip = QtGui.QPainterPath()
        clip.addRoundedRect(rect, 12, 12)
        p.setClipPath(clip)
        p.fillRect(rect, QtGui.QColor('#1c1c1e'))
        if self.image is not None and not self.image.isNull():
            size = self.image.size().scaled(rect.size().toSize(), Qt.KeepAspectRatio)
            target = QtCore.QRectF(0, 0, size.width(), size.height())
            target.moveCenter(rect.center())
            p.drawImage(target, self.image)
        else:
            p.setPen(QtGui.QColor('#8e8e93'))
            p.drawText(rect, Qt.AlignCenter, '点击「显示图像」开始预览')
        self._pill(p, rect.topLeft() + QtCore.QPointF(10, 10), self.name, bold=True)
        if self.caption:
            metrics = QtGui.QFontMetrics(self.font())
            self._pill(p, QtCore.QPointF(rect.left() + 10, rect.bottom() - metrics.height() - 18), self.caption)

    def _pill(self, p, origin, text, bold=False):
        if not text:
            return
        font = QtGui.QFont(self.font())
        font.setBold(bold)
        font.setPixelSize(12)
        p.setFont(font)
        metrics = QtGui.QFontMetrics(font)
        box = QtCore.QRectF(origin, QtCore.QSizeF(metrics.horizontalAdvance(text) + 16, metrics.height() + 8))
        p.setPen(Qt.NoPen)
        p.setBrush(QtGui.QColor(0, 0, 0, 140))
        p.drawRoundedRect(box, box.height() / 2, box.height() / 2)
        p.setPen(QtGui.QColor('#ffffff'))
        p.drawText(box, Qt.AlignCenter, text)


class ZoomView(TileView):
    """One camera enlarged: wheel zooms around the cursor, drag pans, double-click toggles fit / 100 %."""
    MAX_SCALE = 16.0
    changed = Signal()

    def __init__(self):
        super().__init__()
        self.setToolTip('')
        self.fit, self.scale, self.center = True, 1.0, QtCore.QPointF()
        self.drag_from, self.hover = None, None
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setCursor(Qt.OpenHandCursor)

    def set_frame(self, image, name):
        old = self.image.size() if self.image is not None else None
        super().set_frame(image, name)
        if image is not None and old is not None and old != image.size() and not old.isEmpty():
            # Grid tiles arrive downscaled until the helper switches this slot to full resolution.
            ratio = image.width() / old.width()
            self.center = QtCore.QPointF(self.center.x() * ratio, self.center.y() * ratio)
            self.scale /= ratio
        self._clamp()

    def reset(self):
        self.fit, self.hover = True, None
        self.changed.emit()
        self.update()

    def fit_scale(self):
        if self.image is None or self.image.isNull():
            return 1.0
        return min(self.width() / self.image.width(), self.height() / self.image.height())

    def current_scale(self):
        return self.fit_scale() if self.fit else self.scale

    def set_scale(self, scale, anchor=None):
        if self.image is None or self.image.isNull():
            return
        anchor = QtCore.QPointF(anchor) if anchor is not None else QtCore.QPointF(self.rect().center())
        point = self.to_image(anchor)
        scale = max(self.fit_scale(), min(scale, self.MAX_SCALE))
        self.fit = abs(scale - self.fit_scale()) < 1e-6
        self.scale = scale
        offset = anchor - QtCore.QPointF(self.rect().center())
        self.center = point - offset / scale
        self._clamp()
        self.changed.emit()
        self.update()

    def to_image(self, pos):
        scale = self.current_scale()
        center = self.center if not self.fit else QtCore.QPointF(self.image.width() / 2, self.image.height() / 2)
        return center + (QtCore.QPointF(pos) - QtCore.QPointF(self.rect().center())) / scale

    def _clamp(self):
        if self.image is None or self.image.isNull():
            return
        if self.fit:
            self.center = QtCore.QPointF(self.image.width() / 2, self.image.height() / 2)
            return
        half_w, half_h = self.width() / 2 / self.scale, self.height() / 2 / self.scale
        w, h = self.image.width(), self.image.height()
        x = w / 2 if half_w * 2 >= w else min(max(self.center.x(), half_w), w - half_w)
        y = h / 2 if half_h * 2 >= h else min(max(self.center.y(), half_h), h - half_h)
        self.center = QtCore.QPointF(x, y)

    def wheelEvent(self, event):
        steps = event.angleDelta().y() / 120
        if steps:
            self.set_scale(self.current_scale() * 1.25 ** steps, event.position())
            self.mouseMoveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and not self.fit:
            self.drag_from = event.position()
            self.setCursor(Qt.ClosedHandCursor)

    def mouseMoveEvent(self, event):
        if self.drag_from is not None:
            self.center -= (event.position() - self.drag_from) / self.scale
            self.drag_from = event.position()
            self._clamp()
        if self.image is not None and not self.image.isNull():
            point = self.to_image(event.position())
            inside = 0 <= point.x() < self.image.width() and 0 <= point.y() < self.image.height()
            self.hover = (int(point.x()), int(point.y())) if inside else None
        self.update()

    def mouseReleaseEvent(self, event):
        self.drag_from = None
        self.setCursor(Qt.OpenHandCursor)

    def leaveEvent(self, event):
        self.hover = None
        self.update()

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.set_scale(1.0 if self.fit else self.fit_scale(), event.position())

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if not self.fit:
            self.scale = max(self.scale, self.fit_scale())
        self._clamp()
        self.changed.emit()

    def paintEvent(self, _):
        p = QtGui.QPainter(self)
        rect = QtCore.QRectF(self.rect()).adjusted(1, 1, -1, -1)
        clip = QtGui.QPainterPath()
        clip.addRoundedRect(rect, 12, 12)
        p.setClipPath(clip)
        p.fillRect(rect, QtGui.QColor('#1c1c1e'))
        if self.image is None or self.image.isNull():
            p.setPen(QtGui.QColor('#8e8e93'))
            p.drawText(rect, Qt.AlignCenter, '点击「显示图像」开始预览')
            return
        scale = self.current_scale()
        # Above 2x show real pixels instead of a blurred interpolation.
        p.setRenderHint(QtGui.QPainter.SmoothPixmapTransform, scale < 2)
        p.save()
        p.translate(QtCore.QPointF(self.rect().center()))
        p.scale(scale, scale)
        p.translate(-self.center)
        p.drawImage(QtCore.QPointF(0, 0), self.image)
        p.restore()
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        self._pill(p, rect.topLeft() + QtCore.QPointF(10, 10),
                   f'{self.name}  ·  {self.image.width()}×{self.image.height()}', bold=True)
        info = f'{scale * 100:.0f}%' + (f'  ·  x {self.hover[0]}  y {self.hover[1]}' if self.hover else '')
        font = QtGui.QFont(self.font())
        font.setPixelSize(12)
        metrics = QtGui.QFontMetrics(font)
        self._pill(p, QtCore.QPointF(rect.right() - metrics.horizontalAdvance(info) - 26, rect.top() + 10), info)
        if self.caption:
            self._pill(p, QtCore.QPointF(rect.left() + 10, rect.bottom() - metrics.height() - 18), self.caption)


class ImuChart(QtWidgets.QWidget):
    COLORS = ('#ff3b30', '#34c759', '#0a84ff')

    def __init__(self, buffer):
        super().__init__()
        self.buffer, self.mode = buffer, 'acc'
        self.setMinimumHeight(120)

    def paintEvent(self, _):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        rect = QtCore.QRectF(self.rect()).adjusted(0, 4, 0, -4)
        p.setPen(Qt.NoPen)
        p.setBrush(QtGui.QColor('#f5f5f7'))
        p.drawRoundedRect(rect, 10, 10)
        samples = self.buffer.snapshot()
        if len(samples) < 2:
            p.setPen(QtGui.QColor(MUTED))
            p.drawText(rect, Qt.AlignCenter, '无 IMU 数据')
            return
        offset = 1 if self.mode == 'acc' else 4
        step = max(1, len(samples) // max(1, int(rect.width())))
        samples = samples[::step]
        values = [s[offset + a] for s in samples for a in range(3)]
        lo, hi = min(values), max(values)
        span = max(hi - lo, 0.5 if self.mode == 'acc' else 0.05)
        mid = (hi + lo) / 2
        lo, hi = mid - span * 0.6, mid + span * 0.6
        t0, t1 = samples[-1][0] - IMU_WINDOW_S, samples[-1][0]
        inner = rect.adjusted(8, 8, -8, -8)

        def point(t, v):
            return QtCore.QPointF(inner.left() + (t - t0) / (t1 - t0) * inner.width(),
                                  inner.bottom() - (v - lo) / (hi - lo) * inner.height())

        for axis, color in enumerate(self.COLORS):
            path = QtGui.QPainterPath(point(samples[0][0], samples[0][offset + axis]))
            for s in samples[1:]:
                path.lineTo(point(s[0], s[offset + axis]))
            p.setPen(QtGui.QPen(QtGui.QColor(color), 1.5))
            p.setBrush(Qt.NoBrush)
            p.drawPath(path)
        p.setPen(QtGui.QColor(MUTED))
        font = QtGui.QFont(self.font())
        font.setPixelSize(11)
        p.setFont(font)
        p.drawText(inner, Qt.AlignTop | Qt.AlignRight, f'{hi:.2f}')
        p.drawText(inner, Qt.AlignBottom | Qt.AlignRight, f'{lo:.2f}')
        p.drawText(inner, Qt.AlignBottom | Qt.AlignLeft, f'最近 {IMU_WINDOW_S:g} s')


class ConfirmDialog(QtWidgets.QDialog):
    """Frameless rounded sheet with a summary table, optional warning and Cancel / confirm buttons."""

    def __init__(self, parent, title, message, rows=(), warning='', confirm='确定', destructive=False):
        super().__init__(parent)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowTitle(APP_NAME)
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(24, 24, 24, 24)
        sheet = QtWidgets.QFrame(objectName='sheet')
        sheet.setStyleSheet('QFrame#sheet { background: #ffffff; border-radius: 16px; }'
                            'QFrame#rows { background: #f5f5f7; border-radius: 10px; }')
        shadow = QtWidgets.QGraphicsDropShadowEffect(sheet, blurRadius=40, offset=QtCore.QPointF(0, 8))
        shadow.setColor(QtGui.QColor(0, 0, 0, 70))
        sheet.setGraphicsEffect(shadow)
        outer.addWidget(sheet)
        layout = QtWidgets.QVBoxLayout(sheet)
        layout.setContentsMargins(28, 26, 28, 22)
        layout.setSpacing(12)
        heading = QtWidgets.QLabel(title, alignment=Qt.AlignCenter)
        heading.setStyleSheet('font-size: 17px; font-weight: 600;')
        layout.addWidget(heading)
        text = QtWidgets.QLabel(message, alignment=Qt.AlignCenter, wordWrap=True)
        text.setStyleSheet(f'color: {MUTED};')
        layout.addWidget(text)
        if rows:
            box = QtWidgets.QFrame(objectName='rows')
            grid = QtWidgets.QGridLayout(box)
            grid.setContentsMargins(16, 12, 16, 12)
            grid.setVerticalSpacing(8)
            for r, (name, value) in enumerate(rows):
                grid.addWidget(QtWidgets.QLabel(name, styleSheet=f'color: {MUTED};'), r, 0)
                grid.addWidget(QtWidgets.QLabel(value, styleSheet='font-weight: 600;'), r, 1, Qt.AlignRight)
            layout.addWidget(box)
        if warning:
            note = QtWidgets.QLabel('⚠ ' + warning, wordWrap=True)
            note.setStyleSheet(f'color: {ORANGE}; background: #fff4e5; border-radius: 8px; padding: 8px 10px;')
            layout.addWidget(note)
        layout.addSpacing(4)
        buttons = QtWidgets.QHBoxLayout()
        buttons.setSpacing(10)
        cancel = QtWidgets.QPushButton('取消', clicked=self.reject)
        ok = QtWidgets.QPushButton(confirm, objectName='stop' if destructive else 'primary', clicked=self.accept)
        for b in (cancel, ok):
            b.setMinimumHeight(34)
            b.setCursor(Qt.PointingHandCursor)
            buttons.addWidget(b)
        ok.setDefault(True)
        layout.addLayout(buttons)
        self.setFixedWidth(420)

    def showEvent(self, event):
        super().showEvent(event)
        parent = self.parentWidget()
        if parent:
            self.move(parent.frameGeometry().center() - self.rect().center())


# ---------------------------------------------------------------- main window
class MainWindow(QtWidgets.QMainWindow):
    invoke = Signal(object)

    def __init__(self, settings=None):
        super().__init__()
        self.setWindowTitle(f'{APP_NAME} {APP_VERSION}')
        self.setWindowIcon(QtGui.QIcon(asset('cyperstereo.ico')))
        self.resize(1440, 900)
        self.invoke.connect(lambda fn: fn(), Qt.QueuedConnection)
        # Settings keep the pre-rename location so saved directories carry over.
        self.settings = settings or QtCore.QSettings('Cyperstereo', 'Cyperstereo')
        self.devices, self.helper, self.info = [], None, None
        self.param_busy = self.scanning = self.recording = False
        self.frame_lock = threading.Lock()
        self.pending_frames, self.telemetry = {}, []
        self.imu = ImuBuffer()
        self.imu_latest, self.status, self.stream_info = None, {}, {}
        self.tiles, self.tile_count, self.zoom_slot = [], 0, -1
        self.preview_width, self.record_dir, self.stream_error, self.stream_warning = 0, '', '', ''
        self.upgrade_kind, self.upgrade_events, self.upgrade_cancel = None, queue.Queue(), jobs.OperationControl()
        self.upgrade_locked, self.upgrade_folder, self.fx3_layout, self.fx3_template_sn = False, '', None, ''
        self._build()
        self._set_tile_count(4)
        for kind in self.fw:
            saved = self.settings.value(f'{kind}_image', '')
            if saved and Path(saved).is_file():
                self._load_firmware(kind, saved, ask_map=False)
        self.refresh_timer = QtCore.QTimer(self, interval=33, timeout=self._refresh_view)
        self.refresh_timer.start()
        self.resize_timer = QtCore.QTimer(self, singleShot=True, interval=300, timeout=self._send_preview)
        self.upgrade_timer = QtCore.QTimer(self, interval=100, timeout=self._poll_upgrade)
        QtCore.QTimer.singleShot(0, self.scan)

    # ---- layout
    def _build(self):
        root = QtWidgets.QWidget(objectName='root')
        self.setCentralWidget(root)
        outer = QtWidgets.QVBoxLayout(root)
        outer.setContentsMargins(24, 18, 24, 18)
        outer.setSpacing(16)

        top = QtWidgets.QHBoxLayout()
        logo = QtWidgets.QLabel()
        logo.setPixmap(QtGui.QIcon(asset('cyperstereo_mark.png')).pixmap(QtCore.QSize(44, 44)))
        top.addWidget(logo)
        top.addSpacing(4)
        titles = QtWidgets.QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(QtWidgets.QLabel(APP_NAME, objectName='title'))
        self.subtitle = muted('正在查找相机…')
        self.subtitle.setWordWrap(False)
        titles.addWidget(self.subtitle)
        top.addLayout(titles)
        top.addStretch(1)
        self.page_seg = Segmented((('view', '图像'), ('upgrade', '固件升级')), 'view')
        self.page_seg.changed.connect(self._show_page)
        top.addWidget(self.page_seg)
        top.addStretch(1)
        top.addWidget(QtWidgets.QLabel('连接相机'))
        self.device_box = QtWidgets.QComboBox(minimumWidth=250)
        self.device_box.setPlaceholderText('未找到相机')
        self.device_box.setToolTip('一次只能连接一台。显示图像或升级时不能切换，请先停止。')
        self.device_box.currentIndexChanged.connect(self._device_changed)
        top.addWidget(self.device_box)
        self.scan_button = QtWidgets.QPushButton('刷新', clicked=self.scan)
        top.addWidget(self.scan_button)
        top.addSpacing(8)
        self.view_button = QtWidgets.QPushButton('显示图像', objectName='primary', clicked=self.toggle_stream)
        self.view_button.setMinimumWidth(120)
        top.addWidget(self.view_button)
        outer.addLayout(top)

        self.pages = QtWidgets.QStackedWidget()
        view_page = QtWidgets.QWidget()
        body = QtWidgets.QHBoxLayout(view_page)
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(16)
        side = QtWidgets.QWidget()
        side_layout = QtWidgets.QVBoxLayout(side)
        side_layout.setContentsMargins(4, 4, 8, 4)
        side_layout.setSpacing(14)
        side_layout.addWidget(self._build_params())
        side_layout.addWidget(self._build_save())
        side_layout.addWidget(self._build_imu())
        side_layout.addStretch(1)
        scroll = QtWidgets.QScrollArea(widgetResizable=True, horizontalScrollBarPolicy=Qt.ScrollBarAlwaysOff)
        scroll.setWidget(side)
        scroll.setFixedWidth(400)
        body.addWidget(scroll)

        view, view_layout = card()
        self.view_stack = QtWidgets.QStackedWidget()
        grid_page = QtWidgets.QWidget()
        self.grid = QtWidgets.QGridLayout(grid_page)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setSpacing(10)
        self.view_stack.addWidget(grid_page)
        self.view_stack.addWidget(self._build_zoom())
        view_layout.addWidget(self.view_stack, 1)
        self.stream_line = muted('未显示图像  ·  双击画面可放大查看')
        view_layout.addWidget(self.stream_line)
        body.addWidget(view, 1)
        self.pages.addWidget(view_page)
        self.pages.addWidget(self._build_upgrade())
        outer.addWidget(self.pages, 1)

    def _build_zoom(self):
        page = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        bar = QtWidgets.QHBoxLayout()
        back = QtWidgets.QPushButton('‹ 返回全部画面', clicked=self.close_zoom)
        bar.addWidget(back)
        bar.addSpacing(8)
        self.zoom_cameras = QtWidgets.QHBoxLayout()
        self.zoom_cameras.setSpacing(4)
        self.zoom_group = QtWidgets.QButtonGroup(self, exclusive=True)
        bar.addLayout(self.zoom_cameras)
        bar.addStretch(1)
        hint = muted('滚轮缩放 · 拖动平移 · 双击 适应/100%')
        hint.setWordWrap(False)
        bar.addWidget(hint)
        back.setToolTip('Esc；← → 切换相机')
        bar.addSpacing(8)
        for text, action in (('－', lambda: self.zoom_view.set_scale(self.zoom_view.current_scale() / 1.25)),
                             ('＋', lambda: self.zoom_view.set_scale(self.zoom_view.current_scale() * 1.25)),
                             ('适应窗口', lambda: self.zoom_view.reset()),
                             ('100%', lambda: self.zoom_view.set_scale(1.0))):
            button = QtWidgets.QPushButton(text, clicked=action)
            button.setCursor(Qt.PointingHandCursor)
            bar.addWidget(button)
        layout.addLayout(bar)
        self.zoom_view = ZoomView()
        layout.addWidget(self.zoom_view, 1)
        for key, action in (('Escape', self.close_zoom), ('Left', lambda: self._zoom_step(-1)),
                            ('Right', lambda: self._zoom_step(1))):
            QtGui.QShortcut(QtGui.QKeySequence(key), page, activated=action,
                            context=Qt.WidgetWithChildrenShortcut)
        return page

    def _build_params(self):
        frame, layout = card('最大曝光 / 最大增益')
        form = QtWidgets.QGridLayout()
        form.setHorizontalSpacing(12)
        form.setVerticalSpacing(8)
        self.sensor_label = QtWidgets.QLabel('—', objectName='value')
        self.active_label = QtWidgets.QLabel('—', objectName='value', wordWrap=True)
        self.stored_label = QtWidgets.QLabel('—', objectName='value', wordWrap=True)
        for row, (name, widget) in enumerate((('传感器', self.sensor_label), ('当前生效', self.active_label),
                                              ('Flash 已保存', self.stored_label))):
            form.addWidget(muted(name), row, 0, Qt.AlignTop)
            form.addWidget(widget, row, 1)
        self.exposure_spin = QtWidgets.QDoubleSpinBox(decimals=3, suffix=' ms', singleStep=0.1,
                                                      keyboardTracking=False)
        self.exposure_spin.setRange(0.01, 10)
        self.exposure_spin.valueChanged.connect(self._update_exposure_hint)
        self.gain_spin = QtWidgets.QDoubleSpinBox(decimals=2, suffix=' 倍', singleStep=0.5, keyboardTracking=False)
        self.gain_spin.setRange(1, 12)
        self.gain_combo = QtWidgets.QComboBox()
        self.gain_combo.hide()
        form.addWidget(muted('最大曝光'), 3, 0)
        form.addWidget(self.exposure_spin, 3, 1)
        self.exposure_hint = muted()
        form.addWidget(self.exposure_hint, 4, 1)
        form.addWidget(muted('最大增益'), 5, 0)
        gain_box = QtWidgets.QHBoxLayout()
        gain_box.addWidget(self.gain_spin)
        gain_box.addWidget(self.gain_combo)
        form.addLayout(gain_box, 5, 1)
        form.setColumnStretch(1, 1)
        layout.addLayout(form)
        buttons = QtWidgets.QHBoxLayout()
        self.read_button = QtWidgets.QPushButton('读取', clicked=self.read_params)
        self.write_button = QtWidgets.QPushButton('写入', objectName='primary', clicked=self.write_params)
        self.reset_button = QtWidgets.QPushButton('恢复默认', clicked=self.reset_params)
        for b in (self.read_button, self.write_button, self.reset_button):
            buttons.addWidget(b)
        layout.addLayout(buttons)
        self.param_message = muted('写入后需重新上电相机生效')
        layout.addWidget(self.param_message)
        self._param_controls(False)
        return frame

    def _build_save(self):
        frame, layout = card('保存图像')
        form = QtWidgets.QGridLayout()
        form.setHorizontalSpacing(12)
        form.setVerticalSpacing(8)
        default_dir = str(Path.home() / 'Pictures' / APP_NAME)
        self.dir_edit = QtWidgets.QLineEdit(self.settings.value('save_dir', default_dir))
        browse = QtWidgets.QPushButton('选择…', clicked=self._browse)
        row = QtWidgets.QHBoxLayout()
        row.addWidget(self.dir_edit, 1)
        row.addWidget(browse)
        form.addWidget(muted('保存目录'), 0, 0)
        form.addLayout(row, 0, 1)
        self.format_seg = Segmented((('png', 'PNG 无损'), ('jpg', 'JPG')), self.settings.value('format', 'png'))
        form.addWidget(muted('格式'), 1, 0)
        form.addWidget(self.format_seg, 1, 1)
        self.rate_box = QtWidgets.QComboBox()
        for rate in SAVE_RATES:
            self.rate_box.addItem(rate_label(rate), rate)
        self.rate_box.addItem('每帧（相机帧率）', 1000.0)
        saved_rate = float(self.settings.value('rate', 1.0))
        self.rate_box.setCurrentIndex(max(0, self.rate_box.findData(saved_rate)))
        form.addWidget(muted('保存频率'), 2, 0)
        form.addWidget(self.rate_box, 2, 1)
        form.setColumnStretch(1, 1)
        layout.addLayout(form)
        buttons = QtWidgets.QHBoxLayout()
        self.snap_button = QtWidgets.QPushButton('保存图像', clicked=self.snapshot)
        self.record_button = QtWidgets.QPushButton('开始连续保存', objectName='primary', clicked=self.toggle_record)
        buttons.addWidget(self.snap_button)
        buttons.addWidget(self.record_button)
        layout.addLayout(buttons)
        self.save_message = muted(SAVE_HINT)
        layout.addWidget(self.save_message)
        return frame

    def _build_imu(self):
        frame, layout = card('IMU')
        grid = QtWidgets.QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(4)
        for c, axis in enumerate('XYZ'):
            grid.addWidget(muted(axis), 0, c + 1, Qt.AlignRight)
        self.imu_labels = {}
        for r, (key, name) in enumerate((('acc', '加速度 m/s²'), ('gyro', '角速度 rad/s')), start=1):
            grid.addWidget(muted(name), r, 0)
            for c in range(3):
                label = QtWidgets.QLabel('—', objectName='value', alignment=Qt.AlignRight)
                label.setMinimumWidth(70)
                grid.addWidget(label, r, c + 1)
                self.imu_labels[key, c] = label
        layout.addLayout(grid)
        info = QtWidgets.QHBoxLayout()
        self.imu_temp = muted('温度 —')
        self.imu_rate = muted('频率 —')
        info.addWidget(self.imu_temp)
        info.addWidget(self.imu_rate)
        info.addStretch(1)
        self.imu_seg = Segmented((('acc', '加速度'), ('gyro', '角速度')), 'acc')
        info.addWidget(self.imu_seg)
        layout.addLayout(info)
        self.imu_chart = ImuChart(self.imu)
        self.imu_seg.changed.connect(self._imu_mode)
        layout.addWidget(self.imu_chart)
        return frame

    def _build_upgrade(self):
        page = QtWidgets.QWidget()
        outer = QtWidgets.QVBoxLayout(page)
        outer.setContentsMargins(4, 4, 4, 4)
        outer.setSpacing(16)
        note = QtWidgets.QFrame(objectName='note')
        note_layout = QtWidgets.QVBoxLayout(note)
        note_layout.setContentsMargins(16, 10, 16, 10)
        self.upgrade_target = QtWidgets.QLabel('目标相机：—', styleSheet='font-weight: 600;')
        note_layout.addWidget(self.upgrade_target)
        warning = QtWidgets.QLabel(
            '升级对象为顶部「连接相机」所选的那一台，开始前会自动停止图像显示。不备份旧固件；擦写开始后不能取消，'
            '请保持供电，看到「校验通过」后再断电重启。建议先「检查连接」。', wordWrap=True)
        warning.setStyleSheet(f'color: {ORANGE};')
        note_layout.addWidget(warning)
        outer.addWidget(note)

        cards = QtWidgets.QHBoxLayout()
        cards.setSpacing(16)
        self.fw = {}
        for kind, title, subtitle, pattern in (
                ('fpga', 'FPGA 固件', '.bit 配置文件 · 写入后完整读回校验',
                 'FPGA 配置 (*.bit)'),
                ('fx3', 'FX3 固件', '.img 固件 · 自动保留相机原序列号',
                 'FX3 固件 (*.img)')):
            frame, layout = card(title)
            layout.addWidget(muted(subtitle))
            row = QtWidgets.QHBoxLayout()
            path = QtWidgets.QLineEdit(readOnly=True, placeholderText='请选择固件文件')
            browse = QtWidgets.QPushButton('选择…', clicked=lambda _=False, k=kind: self._choose_firmware(k))
            row.addWidget(path, 1)
            row.addWidget(browse)
            layout.addLayout(row)
            controls = {'path': path, 'browse': browse}
            if kind == 'fx3':
                controls['force'] = QtWidgets.QCheckBox('强制覆盖：写入固件自带 SN，并允许 slave / slave_double 及'
                                                        '不同传感器之间跨型号烧录（默认关闭）')
                controls['force'].setStyleSheet(f'color: {MUTED};')
                layout.addWidget(controls['force'])
            buttons = QtWidgets.QHBoxLayout()
            controls['check'] = QtWidgets.QPushButton('检查连接（不擦写）',
                                                      clicked=lambda _=False, k=kind: self.start_upgrade(k, False))
            controls['start'] = QtWidgets.QPushButton('开始升级', objectName='primary',
                                                      clicked=lambda _=False, k=kind: self.start_upgrade(k, True))
            buttons.addWidget(controls['check'])
            if kind == 'fx3':
                controls['prepare'] = QtWidgets.QPushButton(
                    '导出保留 SN 的镜像', clicked=lambda _=False: self.start_upgrade('fx3', 'prepare'))
                controls['prepare'].setToolTip('只读取相机 SN 并生成专用镜像，不擦写相机')
                buttons.addWidget(controls['prepare'])
            buttons.addStretch(1)
            buttons.addWidget(controls['start'])
            layout.addLayout(buttons)
            controls['bar'] = QtWidgets.QProgressBar(maximum=1000, textVisible=False)
            layout.addWidget(controls['bar'])
            controls['state'] = muted('建议先检查连接')
            layout.addWidget(controls['state'])
            layout.addStretch(1)
            self.fw[kind] = controls
            cards.addWidget(frame, 1)
        outer.addLayout(cards)

        frame, layout = card('运行记录')
        self.upgrade_log = QtWidgets.QPlainTextEdit(readOnly=True, objectName='log')
        self.upgrade_log.setMaximumBlockCount(5000)
        layout.addWidget(self.upgrade_log, 1)
        row = QtWidgets.QHBoxLayout()
        row.addWidget(muted('日志目录'))
        self.log_dir_edit = QtWidgets.QLineEdit(self.settings.value('upgrade_log_dir', str(cyperstereo_cli.LOG_DIR)))
        row.addWidget(self.log_dir_edit, 1)
        self.log_browse = QtWidgets.QPushButton('选择…', clicked=self._browse_log_dir)
        row.addWidget(self.log_browse)
        self.open_log = QtWidgets.QPushButton('打开本次日志', clicked=self._open_upgrade_folder, enabled=False)
        row.addWidget(self.open_log)
        row.addSpacing(12)
        self.upgrade_stop = QtWidgets.QPushButton('停止', objectName='stop', clicked=self.stop_upgrade, enabled=False)
        row.addWidget(self.upgrade_stop)
        layout.addLayout(row)
        outer.addWidget(frame, 1)
        return page

    # ---- helpers
    def run_async(self, work, done):
        def runner():
            try:
                result, error = work(), None
            except Exception as exc:
                result, error = None, exc
            self.invoke.emit(lambda: done(result, error))
        threading.Thread(target=runner, daemon=True).start()

    def current_device(self):
        index = self.device_box.currentIndex()
        return self.devices[index] if 0 <= index < len(self.devices) else None

    def _message(self, label, text, color=MUTED):
        label.setText(text)
        label.setStyleSheet(f'color: {color};')

    def _update_buttons(self):
        device = self.current_device()
        streaming = self.helper is not None
        upgrading = self.upgrade_kind is not None
        self.device_box.setEnabled(not streaming and not self.scanning and not upgrading)
        self.scan_button.setEnabled(not streaming and not self.scanning and not upgrading)
        self.view_button.setEnabled(device is not None and bool(device['serial']) and not self.param_busy
                                    and not upgrading)
        idle = device is not None and not self.scanning and not self.param_busy and not upgrading
        for kind, c in self.fw.items():
            c['browse'].setEnabled(not upgrading)
            c['check'].setEnabled(idle)
            c['start'].setEnabled(idle and bool(c['path'].text()))
            if 'prepare' in c:
                c['prepare'].setEnabled(idle and bool(c['path'].text()))
                c['force'].setEnabled(not upgrading)
        self.log_dir_edit.setEnabled(not upgrading)
        self.log_browse.setEnabled(not upgrading)
        self.upgrade_stop.setEnabled(upgrading and not self.upgrade_locked)
        self.upgrade_target.setText('目标相机：' + (f"SN {(device['serial'] or '未读取到').upper()}"
                                                   f"{'  ·  ' + device['name'] if device.get('name') else ''}"
                                                   if device else '未连接'))
        self.upgrade_target.setToolTip(device.get('link', device['address']) if device else '')
        if upgrading:
            for w in (self.snap_button, self.record_button, self.read_button):
                w.setEnabled(False)
            self._param_controls(False)
            return
        self.view_button.setText('停止显示' if streaming else '显示图像')
        self.view_button.setObjectName('stop' if streaming else 'primary')
        self.view_button.style().polish(self.view_button)
        self.snap_button.setEnabled(device is not None and bool(device['serial']))
        self.record_button.setEnabled(device is not None and bool(device['serial']))
        self.record_button.setText('停止保存' if self.recording else '开始连续保存')
        self.record_button.setObjectName('stop' if self.recording else 'primary')
        self.record_button.style().polish(self.record_button)
        self.read_button.setEnabled(device is not None and not self.param_busy)
        self._param_controls(self.info is not None and not self.param_busy)

    def _param_controls(self, enabled):
        for w in (self.exposure_spin, self.gain_spin, self.gain_combo):
            w.setEnabled(enabled)
        self.write_button.setEnabled(enabled)
        self.reset_button.setEnabled(enabled)

    # ---- devices
    def scan(self):
        if self.scanning or self.helper:
            return
        self.scanning = True
        self.subtitle.setText('正在查找相机…')
        self._update_buttons()
        self.run_async(scan_devices, self._scan_done)

    def _scan_done(self, entries, error):
        self.scanning = False
        previous = (self.current_device() or {}).get('serial')
        self.devices = entries or []
        self.device_box.blockSignals(True)
        self.device_box.clear()
        for e in self.devices:
            self.device_box.addItem(camera_choice_label(e), e['address'])
            tip = e.get('link') or e.get('address') or ''
            if e.get('error'):
                tip = (tip + '\n' if tip else '') + e['error']
            if tip:
                self.device_box.setItemData(self.device_box.count() - 1, tip, Qt.ToolTipRole)
        index = next((i for i, e in enumerate(self.devices) if e['serial'] == previous), 0)
        self.device_box.setCurrentIndex(index if self.devices else -1)
        self.device_box.blockSignals(False)
        if error:
            self.subtitle.setText(f'查找相机失败：{error}')
        elif not self.devices:
            self.subtitle.setText('未找到相机（VID 04B4 / PID 00F8/00F9），连接后点击「刷新」')
        else:
            count = len(self.devices)
            self.subtitle.setText('已连接 1 台相机' if count == 1 else f'找到 {count} 台相机，请选择要连接的一台')
        self._device_changed()

    def _device_changed(self, *_):
        self.info = None
        for label in (self.sensor_label, self.active_label, self.stored_label):
            label.setText('—')
        self.exposure_hint.setText('')
        self._message(self.param_message, '')
        self._message(self.save_message, SAVE_HINT)
        self._message(self.stream_line, '未显示图像')
        self._update_buttons()
        device = self.current_device()
        if device and not device['serial']:
            self._message(self.param_message, '读取 SN 失败：' + device['error'], RED)
        if device:
            self.read_params()

    # ---- parameters
    def _param_transport(self, device):
        return csc.HelperTransport(self.helper) if self.helper else backend.Transport(device['address'])

    def _param_job(self, action, done_text):
        device = self.current_device()
        if not device or self.param_busy or self.upgrade_kind:
            return
        self.param_busy = True
        self._update_buttons()
        self._message(self.param_message, '正在与相机通信…')
        transport = None

        def work():
            nonlocal transport
            transport = self._param_transport(device)
            try:
                client = core.ParamClient(transport)
                note = action(client)
                return client.info(), client.stored(), note
            finally:
                transport.close()

        def done(result, error):
            self.param_busy = False
            if error:
                self._message(self.param_message, str(error), RED)
            else:
                info, stored, note = result
                self._show_info(info, stored)
                text = done_text + (f'\n注意：{note}' if note else '')
                self._message(self.param_message, text, ORANGE if note else GREEN)
            self._update_buttons()

        self.run_async(work, done)

    def read_params(self):
        self._param_job(lambda client: '', '已读取')

    def write_params(self):
        info = self.info
        if not info:
            return
        try:
            lines = info.exposure_lines_for(self.exposure_spin.value())
            gain = float(self.gain_combo.currentData()) if info.sensor.gain_choices else self.gain_spin.value()
            code = info.gain_code_for(gain)
        except ValueError as error:
            self._message(self.param_message, str(error), RED)
            return
        applied = info.lines_to_ms(lines)
        warning = info.exposure_warning(lines)
        rows = [('最大曝光', f'{applied:.3f} ms（{lines} 行）'), ('最大增益', f'{code / 64:g} 倍')]
        if not ConfirmDialog(self, '写入相机参数', '参数将保存到相机 Flash，重新上电后生效。',
                             rows, warning, '写入').exec():
            return
        self._param_job(lambda client: (client.write(client.info(), lines, code), warning)[1],
                        '写入成功，请重新上电相机使参数生效')

    def reset_params(self):
        if not ConfirmDialog(self, '恢复默认参数', '将清除 Flash 中保存的参数，重新上电后恢复程序默认值。',
                             confirm='恢复默认', destructive=True).exec():
            return
        self._param_job(lambda client: (client.erase(), '')[1], '已清除，重新上电后恢复程序默认值')

    def _show_info(self, info, stored):
        self.info = info
        s = info.sensor
        self.sensor_label.setText(f'{s.name}  ·  行时间 {info.line_ns / 1000:.3f} µs')
        self.active_label.setText(f'{info.lines_to_ms(info.exposure_lines):.3f} ms  ·  {info.gain_code / 64:g} 倍'
                                  f'  （{"Flash 参数" if info.from_flash else "程序默认值"}）')
        if stored is None:
            self.stored_label.setText('无（使用程序默认值）')
            exp_lines, gain_code = info.exposure_lines, info.gain_code
        elif stored == 'invalid' or stored[0] != info.kind:
            self.stored_label.setText('记录无效（使用程序默认值）')
            exp_lines, gain_code = info.exposure_lines, info.gain_code
        else:
            _, exp_lines, gain_code = stored
            pending = (exp_lines, gain_code) != (info.exposure_lines, info.gain_code) or not info.from_flash
            self.stored_label.setText(f'{info.lines_to_ms(exp_lines):.3f} ms  ·  {gain_code / 64:g} 倍'
                                      + ('  （重新上电后生效）' if pending else ''))
        self.exposure_spin.blockSignals(True)
        self.exposure_spin.setRange(s.min_exposure_ms, round(info.max_exposure_ms(), 3))
        self.exposure_spin.setSingleStep(0.01 if s.min_exposure_ms < 1 else 0.1)
        self.exposure_spin.setValue(info.lines_to_ms(exp_lines))
        self.exposure_spin.blockSignals(False)
        self.exposure_spin.setToolTip(f'允许范围 {s.min_exposure_ms:g} ~ {info.max_exposure_ms():.3f} ms')
        if s.gain_choices:
            self.gain_combo.clear()
            for c in s.gain_choices:
                if c <= info.max_gain():
                    self.gain_combo.addItem(f'{c} 倍', c)
            self.gain_combo.setCurrentIndex(max(0, self.gain_combo.findData(gain_code // 64)))
            self.gain_spin.hide()
            self.gain_combo.show()
        else:
            self.gain_spin.setRange(s.min_gain, info.max_gain())
            self.gain_spin.setValue(gain_code / 64)
            self.gain_combo.hide()
            self.gain_spin.show()
        self._update_exposure_hint()

    def _update_exposure_hint(self, *_):
        info = self.info
        if not info:
            self.exposure_hint.setText('')
            return
        try:
            lines = info.exposure_lines_for(self.exposure_spin.value())
        except ValueError as error:
            self._message(self.exposure_hint, str(error), RED)
            return
        warning = info.exposure_warning(lines)
        self._message(self.exposure_hint, f'实际 {lines} 行 = {info.lines_to_ms(lines):.3f} ms'
                      + (f'\n{warning}' if warning else ''), ORANGE if warning else MUTED)

    # ---- streaming
    def toggle_stream(self):
        if self.helper:
            self.stop_stream()
        else:
            self.start_stream()

    def start_stream(self):
        device = self.current_device()
        if self.helper or not device or not device['serial'] or self.param_busy or self.upgrade_kind:
            return self.helper is not None
        try:
            self.helper = csc.StreamHelper(device['serial'], self._on_helper_message)
        except OSError as error:
            self._message(self.save_message, f'无法启动图像服务：{error}', RED)
            return False
        self.imu.clear()
        self.imu_latest, self.status, self.preview_width = None, {}, 0
        self.stream_error = self.stream_warning = ''
        self._message(self.stream_line, '正在打开相机…')
        if not self.recording:
            self._message(self.save_message, SAVE_HINT)
        self._send_preview()
        if self.zoom_slot >= 0:
            self.helper.zoom(self.zoom_slot)
        self._update_buttons()
        return True

    def stop_stream(self):
        helper, self.helper = self.helper, None
        self.recording = False
        if helper:
            threading.Thread(target=helper.stop, daemon=True).start()
        with self.frame_lock:
            self.pending_frames.clear()
            self.telemetry = []
        for tile in self.tiles:
            tile.clear()
        self.zoom_view.clear()
        self._message(self.stream_line, '未显示图像')
        self._update_buttons()
        return helper

    def _send_preview(self):
        if not self.helper or not self.tiles:
            return
        width = preview_width_for(self.tiles[0].width(), self.devicePixelRatioF())
        if width != self.preview_width:
            self.preview_width = width
            try:
                self.helper.preview(PREVIEW_FPS, width)
            except RuntimeError:
                pass

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.resize_timer.start()

    def _on_helper_message(self, kind, head, body):
        """Reader thread: decode frames here, hand everything else to the GUI thread."""
        if kind == 'F':
            image = QtGui.QImage.fromData(body, 'JPG')
            with self.frame_lock:
                self.pending_frames[head['slot']] = (image, head.get('name', ''), head.get('count', 1))
            return
        kind = head.get('type')
        if kind == 'imu':
            self.imu.extend(head['samples'])
            if head['samples']:
                self.imu_latest = head['samples'][-1]
        elif kind == 'telemetry':
            with self.frame_lock:
                self.telemetry = head['cameras']
        else:
            helper = self.helper
            self.invoke.emit(lambda: self._on_control_message(helper, head))

    def _on_control_message(self, helper, head):
        if helper is not self.helper:
            return
        kind = head.get('type')
        if kind == 'info':
            self.stream_info = head
            self._set_tile_count(head['images'])
            serial = ((self.current_device() or {}).get('serial') or head['serial']).upper()
            profile = sensor_title(head['profile'])
            self.subtitle.setText(f"SN {serial}  ·  {profile}  ·  {head['width']}×{head['height']} "
                                  f"@ {head['fps']} fps\nSDK {head['sdk'][:8]}")
            self.preview_width = 0
            self.resize_timer.start()
        elif kind == 'status':
            self.status = head
        elif kind == 'snapshot':
            if head['ok']:
                self._message(self.save_message, f"已保存到 {head['dir']}", GREEN)
            else:
                self._message(self.save_message, '保存队列已满，本次未保存', RED)
        elif kind == 'error':
            # Before the first status the camera never opened; later errors come from saving.
            if self.status:
                self._message(self.save_message, head['message'], RED)
            else:
                self.stream_error = head['message']
                self._message(self.stream_line, head['message'], RED)
        elif kind == 'warning':
            self.stream_warning = head['message']
            self._message(self.stream_line, head['message'], ORANGE)
        elif kind == 'exited':
            error = self.stream_error or (not self.status and head.get('stderr', '')[-200:])
            self.stop_stream()
            if error:
                hint = '（相机已更换或断开，请点击「刷新」）' if '未找到' in error else ''
                self._message(self.stream_line, '无法显示图像：' + error + hint, RED)

    def _set_tile_count(self, count):
        count = max(1, count)
        if count == self.tile_count:
            return
        self.tile_count = count
        while self.grid.count():
            widget = self.grid.takeAt(0).widget()
            if widget:
                widget.deleteLater()
        for r in range(self.grid.rowCount()):
            self.grid.setRowStretch(r, 0)
        for c in range(self.grid.columnCount()):
            self.grid.setColumnStretch(c, 0)
        rows, columns = grid_shape(count)
        self.tiles = [TileView() for _ in range(count)]
        for i, tile in enumerate(self.tiles):
            tile.name = f'Cam{i + 1}'
            tile.activated.connect(lambda i=i: self.open_zoom(i))
            self.grid.addWidget(tile, i // columns, i % columns)
        for r in range(rows):
            self.grid.setRowStretch(r, 1)
        for c in range(columns):
            self.grid.setColumnStretch(c, 1)
        for button in self.zoom_group.buttons():
            self.zoom_group.removeButton(button)
            button.deleteLater()
        for i, tile in enumerate(self.tiles):
            button = QtWidgets.QPushButton(tile.name, objectName='tool', checkable=True,
                                           clicked=lambda _=False, i=i: self.open_zoom(i))
            button.setCursor(Qt.PointingHandCursor)
            self.zoom_group.addButton(button, i)
            self.zoom_cameras.addWidget(button)
        if self.zoom_slot >= count:
            self.close_zoom()

    # ---- zoom
    def open_zoom(self, slot):
        if not 0 <= slot < len(self.tiles):
            return
        changed = slot != self.zoom_slot
        self.zoom_slot = slot
        tile = self.tiles[slot]
        if changed:
            self.zoom_view.set_frame(None, tile.name)
            self.zoom_view.set_frame(tile.image, tile.name)
            self.zoom_view.set_caption(tile.caption)
            self.zoom_view.reset()
        self.zoom_group.button(slot).setChecked(True)
        self.view_stack.setCurrentIndex(1)
        self.zoom_view.setFocus()
        if self.helper:
            try:
                self.helper.zoom(slot)
            except RuntimeError:
                pass

    def close_zoom(self):
        if self.zoom_slot < 0:
            return
        self.zoom_slot = -1
        self.view_stack.setCurrentIndex(0)
        if self.helper:
            try:
                self.helper.zoom(-1)
            except RuntimeError:
                pass

    def _zoom_step(self, step):
        if self.zoom_slot >= 0 and self.tiles:
            self.open_zoom((self.zoom_slot + step) % len(self.tiles))

    def _show_page(self, page):
        self.pages.setCurrentIndex(1 if page == 'upgrade' else 0)
        self.page_seg.set_value(page)

    def _refresh_view(self):
        with self.frame_lock:
            frames, self.pending_frames = self.pending_frames, {}
            telemetry = self.telemetry
        if frames:
            self._set_tile_count(max(c for _, _, c in frames.values()))
            for slot, (image, name, _) in frames.items():
                if slot < len(self.tiles):
                    self.tiles[slot].set_frame(image, name)
                    button = self.zoom_group.button(slot)
                    if button and name and button.text() != name:
                        button.setText(name)
                if slot == self.zoom_slot:
                    self.zoom_view.set_frame(image, name)
        for tile, t in zip(self.tiles, telemetry):
            tile.set_caption(tile_caption(t))
        if 0 <= self.zoom_slot < len(telemetry):
            self.zoom_view.set_caption(tile_caption(telemetry[self.zoom_slot]))
        if self.helper and self.status:
            s = self.status
            line = (f"{s['fps']:.1f} fps  ·  丢帧 {s['image_drops']}  ·  IMU {s['imu_rate']:.0f} Hz（丢包 {s['imu_drops']}）"
                    f"  ·  硬件 V{s['hardware']} / 软件 V{s['software']}")
            if self.stream_warning:
                self._message(self.stream_line, f'{line}\n{self.stream_warning}', ORANGE)
            else:
                self.stream_line.setText(line)
            if self.recording:
                self._message(self.save_message,
                              f"正在保存：{s['record_sets']} 组 · 已写入 {s['written']} · 待写 {s['save_pending']}"
                              + (f" · 丢弃 {s['save_dropped']}" if s['save_dropped'] else '')
                              + (f" · 失败 {s['save_failed']}" if s['save_failed'] else ''),
                              ORANGE if s['save_dropped'] or s['save_failed'] else ACCENT)
        self._refresh_imu()

    def _refresh_imu(self):
        latest = self.imu_latest
        if latest is None:
            return
        for c in range(3):
            self.imu_labels['acc', c].setText(f'{latest[1 + c]:+.3f}')
            self.imu_labels['gyro', c].setText(f'{latest[4 + c]:+.4f}')
        self.imu_temp.setText(f'温度 {latest[7]:.1f} °C')
        if self.status:
            self.imu_rate.setText(f"频率 {self.status['imu_rate']:.0f} Hz")
        self.imu_chart.update()

    def _imu_mode(self, mode):
        self.imu_chart.mode = mode
        self.imu_chart.update()

    # ---- saving
    def _browse(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(self, '选择保存目录', self.dir_edit.text())
        if path:
            self.dir_edit.setText(path)

    def _save_base(self):
        base = self.dir_edit.text().strip()
        if not base:
            self._message(self.save_message, '请先选择保存目录', RED)
            return None
        self.settings.setValue('save_dir', base)
        self.settings.setValue('format', self.format_seg.value())
        self.settings.setValue('rate', self.rate_box.currentData())
        return base

    def snapshot(self):
        base = self._save_base()
        if base is None or not self.start_stream():
            return
        self.helper.snapshot(str(Path(base) / 'snapshots'), self.format_seg.value())
        self._message(self.save_message, '正在保存…', ACCENT)

    def toggle_record(self):
        if self.recording:
            self.recording = False
            if self.helper:
                self.helper.stop_record()
            s = self.status
            self._message(self.save_message, f"已停止，共保存 {s.get('record_sets', 0)} 组 → {self.record_dir}", GREEN)
            self._update_buttons()
            return
        base = self._save_base()
        if base is None or not self.start_stream():
            return
        self.record_dir = session_dir(base, 'record')
        self.helper.record(self.record_dir, self.rate_box.currentData(), self.format_seg.value())
        self.recording = True
        self._message(self.save_message, f'开始保存 → {self.record_dir}', ACCENT)
        self._update_buttons()

    # ---- firmware upgrade
    def _choose_firmware(self, kind):
        current = self.fw[kind]['path'].text() or self.settings.value(f'{kind}_image', '')
        pattern = 'FPGA 配置 (*.bit)' if kind == 'fpga' else 'FX3 固件 (*.img)'
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, '选择 FPGA 固件' if kind == 'fpga' else '选择 FX3 固件',
                                                        str(Path(current).parent) if current else '', pattern)
        if path:
            self._load_firmware(kind, path)

    def _load_firmware(self, kind, path, ask_map=True):
        c = self.fw[kind]
        try:
            if kind == 'fpga':
                backend.bit_payload(path)
            else:
                raw, _meta = fx3_upgrade.inspect_image(path)
                try:
                    layout = load_layout(path, raw)
                except ValueError:
                    if not ask_map:
                        raise
                    mapfile, _ = QtWidgets.QFileDialog.getOpenFileName(
                        self, '选择与该 IMG 同次编译的 .map（用于定位序列号）', str(Path(path).parent),
                        'FX3 linker map (*.map)')
                    if not mapfile:
                        return
                    layout = layout_from_map(raw, mapfile)
                self.fx3_layout = layout
                self.fx3_template_sn = descriptor(raw, layout)[2]
        except Exception as error:
            c['path'].setText('')
            self._message(c['state'], '固件检查未通过：' + jobs.explain(error), RED)
            self._update_buttons()
            return
        c['path'].setText(path)
        c['path'].setToolTip(path)
        if c['state'].text().startswith('固件检查未通过'):
            self._message(c['state'], '建议先检查连接')
        self.settings.setValue(f'{kind}_image', path)
        self._update_buttons()

    def _browse_log_dir(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(self, '选择日志目录', self.log_dir_edit.text())
        if path:
            self.log_dir_edit.setText(path)

    def _open_upgrade_folder(self):
        if self.upgrade_folder:
            QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(self.upgrade_folder))

    def _append_log(self, text):
        self.upgrade_log.appendPlainText(datetime.datetime.now().strftime('%H:%M:%S  ') + text)

    def start_upgrade(self, kind, mode):
        """mode: False = connection check, True = program, 'prepare' = FX3 image export only."""
        device = self.current_device()
        c = self.fw[kind]
        if self.upgrade_kind or not device or self.param_busy:
            return
        image = c['path'].text() if mode else None
        if mode and not image:
            return
        log_dir = self.log_dir_edit.text().strip()
        if not log_dir:
            self._message(c['state'], '请先选择日志目录', RED)
            return
        force = kind == 'fx3' and bool(mode) and c['force'].isChecked()
        if mode is True:
            serial = (device['serial'] or '未读取到').upper()
            rows = [('相机 SN', serial), ('固件', Path(image).name)]
            if kind == 'fx3':
                rows.append(('升级后 SN', self.fx3_template_sn.upper() if force else serial + '（保留）'))
            title = '升级 FPGA 固件' if kind == 'fpga' else '升级 FX3 固件'
            what = 'FPGA 固件' if kind == 'fpga' else 'FX3 固件'
            if not ConfirmDialog(self, title, f'将覆盖相机中的 {what}，完成后自动完整读回校验。', rows,
                                 '不保存旧固件备份。擦写开始后不能取消，请保持相机供电和 USB 连接，'
                                 '校验通过后再断电重启。' + ('\n已开启强制覆盖：允许跨型号烧录。' if force else ''),
                                 '开始升级', destructive=True).exec():
                return
        self.settings.setValue('upgrade_log_dir', log_dir)
        helper = self.stop_stream() if self.helper else None
        self.upgrade_kind, self.upgrade_locked, self.upgrade_folder = kind, False, ''
        self.upgrade_cancel.clear()
        self.upgrade_events = queue.Queue()
        self.open_log.setEnabled(False)
        c['bar'].setValue(0)
        self._message(c['state'], '正在打开相机…', ACCENT)
        self.upgrade_log.clear()
        self._update_buttons()
        selected = dict(device)
        events, cancel, layout = self.upgrade_events, self.upgrade_cancel, self.fx3_layout

        def worker():
            if helper:
                events.put(('log', '已停止图像显示，等待图像服务释放相机……'))
                try:
                    helper.process.wait(timeout=10)
                except Exception:
                    pass
            try:
                if kind == 'fpga':
                    jobs.fpga_job(selected, image, log_dir, events, cancel)
                else:
                    jobs.fx3_job(selected, image, log_dir, events, cancel, prepare_only=mode == 'prepare',
                                 serial_layout=layout, force_overwrite=force)
            except Exception as error:  # job setup failures (log directory etc.)
                events.put(('error', jobs.explain(error)))
                events.put(('finished', 'failed'))

        threading.Thread(target=worker, daemon=True).start()
        self.upgrade_timer.start()

    def stop_upgrade(self):
        if not self.upgrade_kind or self.upgrade_locked:
            return
        c = self.fw[self.upgrade_kind]
        if self.upgrade_cancel.set():
            self._message(c['state'], '等待当前读操作结束后停止；不会进入擦写', ORANGE)
        else:
            self.upgrade_locked = True
            self._message(c['state'], '已进入擦写阶段，请等待升级与校验完成', ORANGE)
        self._update_buttons()

    def _poll_upgrade(self):
        kind = self.upgrade_kind
        if not kind:
            self.upgrade_timer.stop()
            return
        c = self.fw[kind]
        try:
            while True:
                event, value = self.upgrade_events.get_nowait()
                if event == 'log':
                    self._append_log(value)
                elif event == 'folder':
                    self.upgrade_folder = value
                    self.open_log.setEnabled(True)
                elif event in ('locked', 'writing'):
                    self.upgrade_locked = True
                    self._update_buttons()
                elif event == 'progress':
                    stage, done, total = value
                    if kind == 'fpga':
                        label, number = jobs.FPGA_STAGES[stage]
                        c['bar'].setValue(int((number + done / total) * 500))
                        text = f'{number + 1}/2  {label}：{done:,} / {total:,} 字节（{100 * done / total:.1f}%）'
                    else:
                        index = list(jobs.FX3_STAGES).index(stage)
                        c['bar'].setValue(int((index + done / total) * 250))
                        text = f'{index + 1}/4  {jobs.FX3_STAGES[stage]}：{done:,} / {total:,} 字节'
                    self._message(c['state'], text, ACCENT)
                elif event == 'error':
                    self._message(c['state'], value.split('\n')[0], RED)
                elif event == 'finished':
                    self._upgrade_finished(kind, value)
                    return
        except queue.Empty:
            pass

    def _upgrade_finished(self, kind, outcome):
        c = self.fw[kind]
        locked = self.upgrade_locked
        self.upgrade_kind, self.upgrade_locked = None, False
        self.upgrade_timer.stop()
        texts = {'probe_ok': ('连接检查通过；未擦除或写入 Flash', GREEN),
                 'verified': ('升级成功，完整读回校验通过。请断电重启相机后点击「刷新」', GREEN),
                 'prepared': ('已导出保留 SN 的镜像，未擦写相机（见日志目录）', GREEN),
                 'cancelled': ('已停止，未执行擦写', ORANGE),
                 'failed': ('操作失败' + ('；已进入擦写，请保持供电并查看日志' if locked else '，未进入擦写；请查看运行记录'), RED)}
        text, color = texts.get(outcome, texts['failed'])
        if outcome != 'failed' or c['state'].text() in ('', '正在打开相机…'):
            self._message(c['state'], text, color)
        else:
            self._message(c['state'], text + '：' + c['state'].text(), color)
        if outcome == 'verified':
            c['bar'].setValue(1000)
            ConfirmDialog(self, '升级成功', '完整读回校验通过。请断电重启相机，新固件在重新上电后生效。',
                          confirm='好').exec()
        self._update_buttons()

    def closeEvent(self, event):
        if self.upgrade_kind:
            ConfirmDialog(self, '升级进行中', '擦写或校验期间请保持程序运行和相机供电，完成后再关闭。'
                          if self.upgrade_locked else '请先点击「停止」并等待操作结束后再关闭。', confirm='好').exec()
            event.ignore()
            return
        helper, self.helper = self.helper, None
        if helper:
            helper.stop(timeout=5)
        super().closeEvent(event)


def main():
    if sys.platform == 'win32':
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('Cyperstereo.CyperstereoView')
    QtWidgets.QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setDesktopFileName('cyperstereo-view')
    app.setWindowIcon(QtGui.QIcon(asset('cyperstereo.ico')))
    app.setStyle('Fusion')
    app.setStyleSheet(STYLE)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == '__main__':
    sys.exit(main())
