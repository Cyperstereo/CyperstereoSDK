"""Linux uvcvideo transport. No libusb detach, stream start, or write retries.

ABI: linux/uvcvideo.h UVCIOC_CTRL_QUERY, asm-generic ioctl encoding.
Supported release targets: Linux x86_64 and aarch64, Python >= 3.8.
"""
import ctypes
import errno
import json
import os
from pathlib import Path
import platform
import re
import stat

SYS_CLASS = Path('/sys/class/video4linux')
DEV_ROOT = Path('/dev')
VID, PIDS = '04b4', ('00f8', '00f9')
IDENTITY_KEYS = ('node','sys_path','usb_path','busnum','devnum','vid','pid','serial','interface','dev')

class Query(ctypes.Structure):
    _fields_ = [('unit',ctypes.c_uint8),('selector',ctypes.c_uint8),
                ('query',ctypes.c_uint8),('size',ctypes.c_uint16),('data',ctypes.c_void_p)]

UVCIOC_CTRL_QUERY = (3<<30) | (ctypes.sizeof(Query)<<16) | (ord('u')<<8) | 0x21
VIDIOC_QUERYCAP = (2<<30) | (104<<16) | (ord('V')<<8)

def _read(path,default=None):
    try:return path.read_text(encoding='utf-8').strip()
    except FileNotFoundError:
        if default is not None:return default
        raise

def snapshot(node):
    node=Path(node).resolve(strict=True)
    if not re.fullmatch(r'video\d+',node.name) or node.parent!=DEV_ROOT:
        raise ValueError('请选择 /dev/videoN，或指向它的 /dev/v4l/by-id 链接。')
    entry=SYS_CLASS/node.name
    if _read(entry/'index')!='0':raise ValueError('请选择视频采集节点 index0，不能选择 metadata 节点。')
    location=(entry/'device').resolve(strict=True)
    parents=[location,*location.parents]
    usb=next((p for p in parents if (p/'idVendor').exists() and (p/'idProduct').exists()),None)
    interface=next((p for p in parents if (p/'bInterfaceNumber').exists()),None)
    if usb is None or interface is None:raise ValueError('不是 USB UVC 设备。')
    vid,pid=_read(usb/'idVendor').lower(),_read(usb/'idProduct').lower()
    if vid!=VID or pid not in PIDS:raise ValueError('仅支持 04B4:00F8 / 04B4:00F9 配套摄像头。')
    return dict(node=str(node),sys_path=str(location),usb_path=str(usb),
                busnum=_read(usb/'busnum'),devnum=_read(usb/'devnum'),vid=vid,pid=pid,
                serial=_read(usb/'serial',''),interface=_read(interface/'bInterfaceNumber'),
                dev=_read(entry/'dev'),name=_read(entry/'name','Cyper'))

def address(device):
    return 'linux:'+json.dumps({k:device[k] for k in IDENTITY_KEYS},separators=(',',':'))

def list_devices():
    devices=[];seen=set()
    for entry in sorted(SYS_CLASS.glob('video*'),key=lambda p:int(p.name[5:]) if p.name[5:].isdigit() else -1):
        try:d=snapshot(DEV_ROOT/entry.name)
        except (OSError,ValueError):continue
        # One physical camera may also expose metadata or secondary nodes.
        if d['usb_path'] in seen:continue
        seen.add(d['usb_path'])
        d.update(index=len(devices),platform='linux',link=d['node'],
                 writable=os.access(d['node'],os.R_OK|os.W_OK))
        d['address']=address(d);devices.append(d)
    return devices

def describe_error(error,node,selector=None):
    detail=f'{node}'+(f'，XU selector {selector}' if selector is not None else '')
    hints={errno.EACCES:'设备权限不足：安装随包 udev 规则，重新插拔，并确认当前用户有 video 组权限。',
           errno.EPERM:'访问被拒绝：检查 video 组、udev 权限及系统安全策略。',
           errno.EBUSY:'设备忙：关闭采集程序和其他升级工具。',
           errno.ENODEV:'USB 设备已断开；重新连接后刷新列表。',
           errno.ENOENT:'设备节点消失；请刷新设备列表。',
           errno.EPIPE:'UVC 控制请求被拒绝；确认 FX3 固件支持对应升级接口。',
           errno.EINVAL:'UVC 控制参数不被接受；确认配套固件、unit 3 和 selector 长度。',
           errno.ENOBUFS:'UVC 控制长度不匹配；请确认配套 FX3 固件。',
           errno.ETIMEDOUT:'USB 控制请求超时；若已开始擦写请保持供电。'}
    return RuntimeError(f'Linux UVC：{detail}：{hints.get(error.errno,"控制请求失败；不自动重试写命令。")} 原始错误：{error}')

class LinuxTransport:
    def __init__(self,device):
        import fcntl
        self.fd=None;self.controls=set()
        if platform.machine().lower() not in ('x86_64','amd64','aarch64','arm64') or ctypes.sizeof(ctypes.c_void_p)!=8:
            raise RuntimeError('此发布包的 Linux ioctl ABI 支持 x86_64 / aarch64。')
        expected=json.loads(device[6:]) if device.startswith('linux:') else snapshot(device)
        if not isinstance(expected,dict) or any(k not in expected for k in IDENTITY_KEYS):
            raise ValueError('设备标识不完整，请刷新设备列表。')
        self.node=expected['node'];self.identity={k:expected[k] for k in IDENTITY_KEYS}
        self._check_identity()
        try:
            self.fd=os.open(self.node,os.O_RDWR|os.O_NONBLOCK|os.O_CLOEXEC)
            # Advisory lock coordinates both of our updaters on the same node.
            fcntl.flock(self.fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            self._check_identity()
            info=os.fstat(self.fd)
            expected_dev=tuple(map(int,expected['dev'].split(':')))
            if not stat.S_ISCHR(info.st_mode) or (os.major(info.st_rdev),os.minor(info.st_rdev))!=expected_dev:
                raise RuntimeError('打开的文件不是所选视频设备，请刷新列表。')
            caps=bytearray(104);fcntl.ioctl(self.fd,VIDIOC_QUERYCAP,caps,True)
            capabilities=int.from_bytes(caps[84:88],'little')
            own=int.from_bytes(caps[88:92],'little') if capabilities & 0x80000000 else capabilities
            if bytes(caps[:16]).split(b'\0')[0]!=b'uvcvideo' or not own & (1|0x1000):
                raise RuntimeError('所选节点不是 uvcvideo 视频采集设备。')
        except Exception as e:
            self.close()
            if isinstance(e,OSError):raise describe_error(e,self.node) from e
            raise

    def _check_identity(self):
        current=snapshot(self.node)
        if any(current[k]!=self.identity[k] for k in IDENTITY_KEYS):
            raise RuntimeError('所选 USB 设备已变化或重新枚举；请刷新后重新选择，不自动切换设备。')

    def read_serial(self):
        from fx3_serial import read_device_serial
        self._check_identity()
        return read_device_serial(address(self.identity))

    def _raw(self,selector,request,size,data=None):
        import fcntl
        buf=(ctypes.c_uint8*size)()
        if data is not None:buf[:]=data
        q=Query(3,selector,request,size,ctypes.addressof(buf))
        try:
            # A single ioctl only. Never replay SET_CUR after an error.
            fcntl.ioctl(self.fd,UVCIOC_CTRL_QUERY,q)
        except OSError as e:raise describe_error(e,self.node,selector) from e
        return bytes(buf)

    def query(self,set_data=None,fast=False,selector=None):
        if self.fd is None:raise RuntimeError('Linux UVC 设备已关闭。')
        selected=selector if selector is not None else (6 if fast else 5)
        if selected not in (5,6,7):raise ValueError('Unsupported upgrade selector')
        size=32 if selected==5 else 288
        if set_data is not None and len(set_data)!=size:raise ValueError('Invalid USB packet length')
        # No reopen: the same fd owns the entire session. Detect unplug/replug
        # before each transfer, including reuse of the old /dev/videoN number.
        self._check_identity()
        if selected not in self.controls:
            length=int.from_bytes(self._raw(selected,0x85,2),'little')
            if length!=size:raise RuntimeError(f'Linux XU selector {selected} 长度 {length}，预期 {size}；未发出写请求。')
            info=self._raw(selected,0x86,1)[0]
            if info&3!=3:raise RuntimeError(f'Linux XU selector {selected} 不支持 GET/SET。')
            self.controls.add(selected)
        return self._raw(selected,0x01 if set_data is not None else 0x81,size,set_data)

    def close(self):
        if self.fd is not None:os.close(self.fd);self.fd=None
