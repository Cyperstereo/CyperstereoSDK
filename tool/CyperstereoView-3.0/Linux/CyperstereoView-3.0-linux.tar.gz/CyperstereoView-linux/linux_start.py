"""Linux entry point shared by GUI and headless shell launchers."""
import os
from pathlib import Path
import shutil
import subprocess
import sys

def main():
    if not sys.platform.startswith('linux'):raise SystemExit('This launcher runs on native Linux; use the .exe on Windows.')
    if sys.version_info < (3,8):raise SystemExit('Python 3.8 or newer is required.')
    if len(sys.argv)<2 or sys.argv[1] not in ('fpga','fx3'):raise SystemExit('Usage: linux_start.py fpga|fx3 [--cli ARGS]')
    kind=sys.argv[1];args=sys.argv[2:]
    manual='--no-inhibit' in args
    if manual:args.remove('--no-inhibit')
    # No root or driver changes. One systemd inhibitor covers the child lifetime.
    if not manual and os.environ.get('USB_UPGRADE_INHIBITED')!='1':
        inhibitor=shutil.which('systemd-inhibit')
        if inhibitor:
            env=dict(os.environ,USB_UPGRADE_INHIBITED='1')
            return subprocess.call([inhibitor,'--what=sleep:idle','--mode=block',
                '--who=USB Firmware Upgrader','--why=Keep power during flash update',
                sys.executable,str(Path(__file__).resolve()),kind,*args],env=env)
        print('systemd-inhibit unavailable; disable automatic sleep before updating.',file=sys.stderr)
    if args[:1]==['--cli']:
        import upgrade_cli
        return upgrade_cli.main(['--kind',kind,*args[1:]])
    if args:raise SystemExit('For command-line mode use --cli list / inspect / check / program.')
    try:
        import tkinter
    except ImportError:raise SystemExit('Tk is missing. On Ubuntu/Debian: sudo apt install python3-tk')
    try:
        if kind=='fpga':
            import fpga_upgrade_gui as gui
        else:
            import fx3_upgrade_gui as gui
        gui.main()
    except tkinter.TclError as e:
        raise SystemExit('Cannot open the graphical display. Use --cli over SSH, or run in a local desktop session. '+str(e))
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except (Exception,KeyboardInterrupt) as e:print('ERROR: '+(str(e) or 'Interrupted'),file=sys.stderr);sys.exit(1)
