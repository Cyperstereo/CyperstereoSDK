#!/usr/bin/env bash
# Cyperstereo View command line from source; needs only python3 (no Qt, no OpenCV).
#   ./linux/cyperstereo-cli.sh --help
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "$0")/.." && pwd)
exec python3 "$ROOT/cyperstereo_cli.py" "$@"
