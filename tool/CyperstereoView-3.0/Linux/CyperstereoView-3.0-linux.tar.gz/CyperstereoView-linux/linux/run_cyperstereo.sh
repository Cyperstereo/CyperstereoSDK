#!/usr/bin/env bash
# Run Cyperstereo View from source (after ./linux/build_linux.sh has built
# cyper_stream and the .venv-linux environment). Arguments such as
# `fpga check --device SN` run the command-line mode instead of the GUI.
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "$0")/.." && pwd)
PY="$ROOT/.venv-linux/bin/python"
[ -x "$PY" ] || PY=python3
[ -x "$ROOT/cyper_stream" ] || [ $# -gt 0 ] || { echo "cyper_stream missing: run ./linux/build_linux.sh first" >&2; exit 1; }
exec "$PY" "$ROOT/cyperstereo_gui.py" "$@"
