#!/usr/bin/env bash
# Cyperstereo View for Linux (x86_64 / aarch64; Ubuntu 20.04+ / Debian 11+).
#
#   ./linux/build_linux.sh            install build deps, build cyper_stream, run tests,
#                                     package dist-linux/cyperstereo-view (single file)
#   ./linux/build_linux.sh --install  also install the udev rule, ~/.local/bin/cyperstereo-view,
#                                     the icon and a desktop menu entry
#   ./linux/build_linux.sh --no-deps  skip apt-get (deps already installed)
#
# The same binary is the command-line tool: cyperstereo-view --help
# Run from source without packaging: ./linux/run_cyperstereo.sh (GUI) or
# ./linux/cyperstereo-cli.sh (CLI; needs only python3, no Qt / OpenCV).
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
INSTALL=0 DEPS=1
for arg in "$@"; do
    case $arg in
        --install) INSTALL=1 ;;
        --no-deps) DEPS=0 ;;
        *) echo "unknown option: $arg" >&2; exit 2 ;;
    esac
done

if [ "$DEPS" = 1 ]; then
    # libxcb-cursor0 is required by the Qt 6 xcb platform plugin.
    sudo apt-get update
    sudo apt-get install -y cmake g++ make libopencv-dev python3-venv python3-pip \
        libxcb-cursor0 libxkbcommon-x11-0 libegl1 fonts-noto-cjk
fi

cmake -S stream -B stream/build-linux -DCMAKE_BUILD_TYPE=Release
cmake --build stream/build-linux -j"$(nproc)"
cp stream/build-linux/cyper_stream ./cyper_stream

VENV="$ROOT/.venv-linux"
[ -x "$VENV/bin/python" ] || python3 -m venv "$VENV"
"$VENV/bin/pip" install --upgrade pip
"$VENV/bin/pip" install "PySide6-Essentials>=6.5" pyinstaller

"$VENV/bin/pyinstaller" --noconfirm --clean --onefile --windowed --name cyperstereo-view \
    --distpath dist-linux --workpath build-linux --specpath build-linux \
    --exclude-module tkinter --add-binary "$ROOT/cyper_stream:." --add-data "$ROOT/assets:assets" \
    cyperstereo_gui.py
echo "Built $ROOT/dist-linux/cyperstereo-view (needs the system OpenCV runtime: libopencv-dev or libopencv-*4xx)"

if [ "$INSTALL" = 1 ]; then
    sudo install -m 0644 linux/99-cyperstereo.rules /etc/udev/rules.d/99-cyperstereo.rules
    sudo udevadm control --reload-rules
    sudo udevadm trigger --subsystem-match=video4linux
    getent group video >/dev/null && sudo usermod -aG video "$USER"
    install -Dm 0755 dist-linux/cyperstereo-view "$HOME/.local/bin/cyperstereo-view"
    install -Dm 0644 assets/cyperstereo.png "$HOME/.local/share/icons/hicolor/512x512/apps/cyperstereo-view.png"
    install -Dm 0644 linux/cyperstereo-view.desktop "$HOME/.local/share/applications/cyperstereo-view.desktop"
    sed -i "s|^Exec=.*|Exec=$HOME/.local/bin/cyperstereo-view|" "$HOME/.local/share/applications/cyperstereo-view.desktop"
    rm -f "$HOME/.local/share/applications/cyperstereo.desktop" "$HOME/.local/bin/Cyperstereo"
    command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -q "$HOME/.local/share/icons/hicolor" || true
    echo "Installed. Re-plug the camera; log out and in once if you were just added to the video group."
fi
