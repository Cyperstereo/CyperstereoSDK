#!/usr/bin/env python3
"""Cyperstereo View command line: devices, max exposure / gain, FPGA and FX3 upgrades.

  cyperstereo-view list
  cyperstereo-view param info  [--device SN]
  cyperstereo-view param set   [--device SN] [--exposure-ms MS] [--gain X]
  cyperstereo-view param reset [--device SN]
  cyperstereo-view fpga inspect FILE.bit
  cyperstereo-view fpga check   --device SN
  cyperstereo-view fpga program --device SN FILE.bit --accept-single-image-risk
  cyperstereo-view fx3  inspect FILE.img
  cyperstereo-view fx3  check   --device SN
  cyperstereo-view fx3  prepare --device SN FILE.img [--force-overwrite]
  cyperstereo-view fx3  program --device SN FILE.img --accept-single-image-risk [--force-overwrite]

--device takes a camera SN (as shown by list) or a device address
(/dev/videoN, /dev/v4l/by-id/..., win:N, winlink:...). Upgrades keep the
system awake (Linux: systemd-inhibit; --no-inhibit to skip) and log to
~/Documents/Cyperstereo View/upgrade_logs unless --log-dir is given.
"""
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

APP_NAME, APP_VERSION = 'Cyperstereo View', '3.0'
COMMANDS = ('--cli', 'list', 'param', 'fpga', 'fx3', '--version', '-h', '--help', 'help')
LOG_DIR = Path.home() / 'Documents' / APP_NAME / 'upgrade_logs'
ADDRESS_PREFIXES = ('/dev/', 'win:', 'winlink:', 'linux:')


def scan():
    """[(serial, address, device)] for every camera; serial is '' if unreadable."""
    import fpga_upgrade as backend
    from fx3_serial import read_device_serial
    result = []
    for device in backend.list_devices():
        if not backend.is_target_device(device):
            continue
        address = backend.device_address(device)
        try:
            serial = read_device_serial(address)['serial']
        except Exception:
            serial = ''
        result.append((serial, address, device))
    return result


def resolve_device(value):
    """SN or address -> address. No value: the only connected camera."""
    if value and value.startswith(ADDRESS_PREFIXES):
        return value
    cameras = scan()
    if not value:
        if len(cameras) != 1:
            raise SystemExit(f'找到 {len(cameras)} 台相机，请用 --device 指定 SN（见 list）')
        return cameras[0][1]
    matches = [address for serial, address, _ in cameras if serial.upper() == value.upper()]
    if not matches:
        raise SystemExit(f'未找到 SN 为 {value} 的相机（见 list）')
    return matches[0]


def take_option(args, name, has_value=True):
    """Remove `name [value]` from args; returns the value, True, or None."""
    if name not in args:
        return None
    i = args.index(name)
    if not has_value:
        del args[i]
        return True
    if i + 1 >= len(args):
        raise SystemExit(f'{name} 需要参数')
    value = args[i + 1]
    del args[i:i + 2]
    return value


def inhibited(argv):
    """Re-run under systemd-inhibit on Linux for flash writes; returns an exit code or None."""
    if not sys.platform.startswith('linux') or os.environ.get('USB_UPGRADE_INHIBITED') == '1':
        return None
    inhibitor = shutil.which('systemd-inhibit')
    if not inhibitor:
        print('systemd-inhibit 不可用：请先关闭自动休眠；或加 --no-inhibit 跳过此检查。', file=sys.stderr)
        return 1
    command = [sys.executable] if getattr(sys, 'frozen', False) else [sys.executable, str(Path(__file__).resolve())]
    return subprocess.call([inhibitor, '--what=sleep:idle', '--mode=block', '--who=' + APP_NAME,
                            '--why=Keep power during flash update', *command, *argv],
                           env=dict(os.environ, USB_UPGRADE_INHIBITED='1'))


def cmd_list():
    cameras = scan()
    if not cameras:
        print('未找到相机（VID 04B4 / PID 00F8/00F9）')
        return 1
    for serial, address, device in cameras:
        print(f"{(serial or '未读取到 SN').upper():<12} {address}  {device.get('name', '')}")
    return 0


def cmd_param(args):
    import camera_param
    if not args or args[0] in ('-h', '--help'):
        return camera_param.main(['--help'])
    device = take_option(args, '--device')
    return camera_param.main(['--device', resolve_device(device), *args])


def cmd_upgrade(kind, argv, args):
    import upgrade_cli
    if not args or args[0] in ('-h', '--help'):
        return upgrade_cli.main(['--kind', kind, '--help'])
    no_inhibit = take_option(args, '--no-inhibit', has_value=False)
    if args[0] in ('check', 'program', 'prepare'):
        device = take_option(args, '--device')
        args[1:1] = ['--device', resolve_device(device)]
        if '--log-dir' not in args:
            args += ['--log-dir', str(LOG_DIR)]
    if args[0] == 'program' and not no_inhibit:
        code = inhibited(argv)
        if code is not None:
            return code
    return upgrade_cli.main(['--kind', kind, *args])


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ['--cli']:
        argv = argv[1:]
    if not argv or argv[0] in ('-h', '--help', 'help'):
        print(f'{APP_NAME} {APP_VERSION}\n' + __doc__)
        return 0
    command, args = argv[0], argv[1:]
    if command == '--version':
        print(f'{APP_NAME} {APP_VERSION}')
        return 0
    if command == 'list':
        return cmd_list()
    if command == 'param':
        return cmd_param(args)
    if command in ('fpga', 'fx3'):
        return cmd_upgrade(command, argv, args)
    raise SystemExit(f'未知命令 {command}；运行 --help 查看用法')


def run(argv=None):
    try:
        return main(argv) or 0
    except (RuntimeError, ValueError, TimeoutError, OSError) as error:
        print('错误:', error, file=sys.stderr)
        return 1


def split_command(line):
    """Split one interactive line the way the Windows command line does."""
    if os.name == 'nt':
        import ctypes
        count = ctypes.c_int()
        ctypes.windll.shell32.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)
        argv = ctypes.windll.shell32.CommandLineToArgvW(line, ctypes.byref(count))
        if not argv:
            raise ValueError('无法解析命令')
        try:
            return [argv[i] for i in range(count.value)]
        finally:
            ctypes.windll.kernel32.LocalFree(argv)
    return shlex.split(line)


def started_from_explorer():
    """True when Explorer opened this program, so the console would otherwise close at once."""
    if sys.platform != 'win32':
        return False
    import ctypes
    from ctypes import wintypes
    kernel32 = ctypes.windll.kernel32
    TH32CS_SNAPPROCESS = 0x00000002

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ('dwSize', wintypes.DWORD), ('cntUsage', wintypes.DWORD),
            ('th32ProcessID', wintypes.DWORD), ('th32DefaultHeapID', ctypes.c_void_p),
            ('th32ModuleID', wintypes.DWORD), ('cntThreads', wintypes.DWORD),
            ('th32ParentProcessID', wintypes.DWORD), ('pcPriClassBase', ctypes.c_long),
            ('dwFlags', wintypes.DWORD), ('szExeFile', wintypes.WCHAR * 260)]

    kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    kernel32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    kernel32.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
    kernel32.Process32FirstW.restype = wintypes.BOOL
    kernel32.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
    kernel32.Process32NextW.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snap == wintypes.HANDLE(-1).value:
        return False
    entry = PROCESSENTRY32W()
    entry.dwSize = ctypes.sizeof(entry)
    processes = {}
    ok = kernel32.Process32FirstW(snap, ctypes.byref(entry))
    while ok:
        processes[entry.th32ProcessID] = (entry.th32ParentProcessID, entry.szExeFile)
        ok = kernel32.Process32NextW(snap, ctypes.byref(entry))
    kernel32.CloseHandle(snap)
    pid = kernel32.GetCurrentProcessId()
    own = Path(sys.executable).name.lower()
    for _ in range(4):
        parent, name = processes.get(pid, (None, ''))
        if not parent or not name:
            return False
        if name.lower() != own:
            return name.lower() == 'explorer.exe'
        pid = parent
    return False


def interactive():
    print(f'''{APP_NAME} {APP_VERSION} 命令行

本程序是命令行工具。要看图像，请打开 CyperstereoView.exe。
输入下面这样的命令后回车。直接回车，或输入 exit，关闭窗口。

  list
  param info
  param set --exposure-ms 15 --gain 4
  param reset
  fpga check
  fpga program 固件.bit --accept-single-image-risk
  fx3 check
  fx3 program 固件.img --accept-single-image-risk
  fx3 prepare 固件.img
多台相机时在命令里加上 --device 序列号。
''')
    while True:
        try:
            line = input('cyperstereo-cli> ')
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if not line.strip() or line.strip().lower() in ('exit', 'quit'):
            return 0
        try:
            argv = split_command(line)
        except ValueError as error:
            print('错误:', error)
            continue
        try:
            code = run(argv)
        except SystemExit as error:
            code = error.code if isinstance(error.code, int) else 1
        print(f'(退出码 {code})\n')


def pause_if_explorer():
    if not started_from_explorer():
        return
    try:
        input('\n按回车键关闭窗口…')
    except EOFError:
        pass


if __name__ == '__main__':
    if len(sys.argv) == 1 and started_from_explorer():
        sys.exit(interactive())
    code = run()
    pause_if_explorer()
    sys.exit(code)
